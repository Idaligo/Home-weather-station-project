#include "openmeteo.h"
#include "weather_forecast.h"
#include "common.h"
#include "logger.h"
#include <ArduinoJson.h>    // ← добавить явно
#include "esp_heap_caps.h"  // ← для PSRAM

// ===== Кастомный аллокатор для PSRAM =====
struct SpiRamAllocator : ArduinoJson::Allocator {
  void* allocate(size_t size) override {
    return heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
  }
  void deallocate(void* pointer) override {
    heap_caps_free(pointer);
  }
  void* reallocate(void* ptr, size_t new_size) override {
    return heap_caps_realloc(ptr, new_size, MALLOC_CAP_SPIRAM);
  }
};

static SpiRamAllocator psramAllocator;

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ===================================================================
// ПОЛУЧЕНИЕ ДАННЫХ ОТ OPEN-METEO
// ===================================================================
bool fetchOpenMeteoData(float lat, float lon, OpenMeteoData& data) {
  if (WiFi.status() != WL_CONNECTED) {
    LOG_E("❌ Wi-Fi не подключён!");
    return false;
  }

  // ===== 1. URL =====
  String url = "http://api.open-meteo.com/v1/forecast?"
               "latitude="
               + String(lat, 6) + "&longitude=" + String(lon, 6) + "&current=temperature_2m,relative_humidity_2m,weather_code,pressure_msl" + "&hourly=temperature_2m,relative_humidity_2m,weather_code,pressure_msl" + "&forecast_hours=6" + "&timezone=Europe/Moscow";

  LOG_I("📤 Запрос к Open-Meteo: %s", url.c_str());

  // ===== 2. DNS-проверка (опционально) =====
  IPAddress ip;
  if (!WiFi.hostByName("api.open-meteo.com", ip)) {
    LOG_E("❌ DNS не резолвится");
    return false;
  }

  // ===== 3. Явный клиент =====
  WiFiClient client;
  HTTPClient http;
  http.begin(client, url);
  http.setTimeout(10000);

  int httpCode = http.GET();
  lastSession.httpCode = httpCode;

  if (httpCode != 200) {
    LOG_E("❌ Ошибка HTTP: %d", httpCode);
    http.end();
    client.stop();
    return false;
  }

  String payload = http.getString();
  lastSession.bytesRead = payload.length();
  http.end();
  client.stop();

  if (payload.length() == 0) {
    LOG_E("❌ Пустой ответ");
    return false;
  }
  LOG_I("📥 Получено %d байт", payload.length());

  // ===== 4. Парсинг (документ — глобальный/статический) =====
  static JsonDocument doc(&psramAllocator);
  DeserializationError error = deserializeJson(doc, payload);

  if (error) {
    LOG_E("❌ Ошибка JSON: %s", error.f_str());
    return false;
  }

  // ===== 5. Извлечение =====
  data.currentTemp = doc["current"]["temperature_2m"] | 0.0f;
  data.currentHumidity = doc["current"]["relative_humidity_2m"] | 0.0f;
  data.currentPressure = doc["current"]["pressure_msl"] | 0.0f;
  data.currentWeatherCode = doc["current"]["weather_code"] | 0;

  for (int i = 0; i < 6; i++) {
    data.forecastTemp[i] = doc["hourly"]["temperature_2m"][i] | 0.0f;
    data.forecastHumidity[i] = doc["hourly"]["relative_humidity_2m"][i] | 0.0f;
    data.forecastWeatherCode[i] = doc["hourly"]["weather_code"][i] | 0;
  }

  data.isValid = true;
  data.lastUpdate = millis();

  LOG_I("✅ Данные Open-Meteo получены");
  return true;
}

// ===================================================================
// ПРЕОБРАЗОВАНИЕ КОДА ПОГОДЫ В ОПИСАНИЕ
// ===================================================================
const char* getWeatherDescription(int code) {
  // ===== Ясно =====
  if (code == 0) return "Ясно";
  if (code == 1) return "Преимущественно ясно";

  // ===== Облачность =====
  if (code == 2) return "Переменная облачность";
  if (code == 3) return "Пасмурно";

  // ===== Туман =====
  if (code == 45) return "Туман";
  if (code == 48) return "Туман с изморозью";

  // ===== Морось =====
  if (code == 51) return "Слабая морось";
  if (code == 53) return "Морось";
  if (code == 55) return "Плотная морось";
  if (code == 56) return "Слабая ледяная морось";
  if (code == 57) return "Ледяная морось";

  // ===== Дождь =====
  if (code == 61) return "Небольшой дождь";
  if (code == 63) return "Дождь";

  // ===== Сильный дождь =====
  if (code == 65) return "Сильный дождь";
  if (code == 66) return "Слабый ледяной дождь";
  if (code == 67) return "Сильный ледяной дождь";

  // ===== Снег =====
  if (code == 71) return "Небольшой снег";
  if (code == 73) return "Снег";
  if (code == 75) return "Сильный снег";
  if (code == 77) return "Снежная крупа";

  // ===== Ливни =====
  if (code == 80) return "Слабый ливень";
  if (code == 81) return "Ливень";
  if (code == 82) return "Сильный ливень";

  // ===== Снегопады =====
  if (code == 85) return "Небольшой снегопад";
  if (code == 86) return "Снегопад";

  // ===== Гроза =====
  if (code == 95) return "Гроза";
  if (code == 96) return "Гроза с небольшим градом";
  if (code == 99) return "Гроза с сильным градом";

  return "Неизвестно";
}


// ===================================================================
// ПРЕОБРАЗОВАНИЕ КОДА OPEN-METEO В ТВОЙ ВНУТРЕННИЙ КОД
// ===================================================================
int mapOpenMeteoToWeatherCode(int openMeteoCode) {
  // ===== Ясно =====
  if (openMeteoCode == 0) return WEATHER_CLEAR;

  // ===== Малооблачно =====
  if (openMeteoCode == 1) return WEATHER_MOSTLY_CLEAR;

  // ===== Переменная облачность =====
  if (openMeteoCode == 2) return WEATHER_PARTLY_CLOUDY;

  // ===== Пасмурно =====
  if (openMeteoCode == 3) return WEATHER_CLOUDY;

  // ===== Туман =====
  if (openMeteoCode == 45 || openMeteoCode == 48) return WEATHER_FOG;

  // ===== Морось =====
  if (openMeteoCode >= 51 && openMeteoCode <= 57) return WEATHER_DRIZZLE;

  // ===== Дождь =====
  if (openMeteoCode == 61 || openMeteoCode == 63) return WEATHER_RAIN;

  // ===== Сильный дождь (65, 66, 67, 80, 81, 82) =====
  if (openMeteoCode == 65 || openMeteoCode == 66 || openMeteoCode == 67) return WEATHER_HEAVY_RAIN;
  if (openMeteoCode >= 80 && openMeteoCode <= 82) return WEATHER_HEAVY_RAIN;

  // ===== Небольшой снег =====
  if (openMeteoCode == 71 || openMeteoCode == 77) return WEATHER_LIGHT_SNOW;

  // ===== Снег =====
  if (openMeteoCode == 73 || openMeteoCode == 75) return WEATHER_SNOW;

  // ===== Снегопад =====
  if (openMeteoCode == 85 || openMeteoCode == 86) return WEATHER_SNOW_SHOWERS;

  // ===== Гроза =====
  if (openMeteoCode == 95 || openMeteoCode == 96 || openMeteoCode == 99) return WEATHER_THUNDER;

  return WEATHER_UNKNOWN;
}