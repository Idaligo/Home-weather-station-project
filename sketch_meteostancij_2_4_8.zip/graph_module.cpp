// graph_module.cpp
#include <SD.h>
#include "graph_module.h"
#include "common.h"
#include "sd_module.h"
#include "keypad_module.h"
#include "menu_module.h"
#include "rtc_module.h"
#include "logger.h"

extern TFT_eSPI tft;
extern AppMode currentMode;
extern RTCModule rtcClock;

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== ДАННЫЕ ====================
float tempHour[GRAPH_HOURS];
float humHour[GRAPH_HOURS];
float presHour[GRAPH_HOURS];
int hourIndex = 0;
bool hourFilled = false;

float tempWeek[GRAPH_WEEK];
float humWeek[GRAPH_WEEK];
float presWeek[GRAPH_WEEK];
int weekIndex = 0;
bool weekFilled = false;

float tempMonth[GRAPH_MONTH];
float humMonth[GRAPH_MONTH];
float presMonth[GRAPH_MONTH];
int monthIndex = 0;
bool monthFilled = false;

// ==================== СОСТОЯНИЕ НАВИГАЦИИ ====================
static int graphParam = 0;   // 0=T, 1=H, 2=P
static int graphPeriod = 0;  // 0=24ч, 1=7д, 2=30д
static unsigned long lastGraphActivity = 0;

// ==================== ЗАПОЛНЕНИЕ ====================
void graphAddHour(float t, float h, float p) {
  for (int i = 0; i < GRAPH_HOURS - 1; i++) {
    tempHour[i] = tempHour[i + 1];
    humHour[i] = humHour[i + 1];
    presHour[i] = presHour[i + 1];
  }
  tempHour[GRAPH_HOURS - 1] = t;
  humHour[GRAPH_HOURS - 1] = h;
  presHour[GRAPH_HOURS - 1] = p;
  hourFilled = true;
}

void graphAddDay(float t, float h, float p) {
  // Неделя
  if (weekIndex < GRAPH_WEEK) {
    tempWeek[weekIndex] = t;
    humWeek[weekIndex] = h;
    presWeek[weekIndex] = p;
    weekIndex++;
  } else {
    for (int i = 0; i < GRAPH_WEEK - 1; i++) {
      tempWeek[i] = tempWeek[i + 1];
      humWeek[i] = humWeek[i + 1];
      presWeek[i] = presWeek[i + 1];
    }
    tempWeek[GRAPH_WEEK - 1] = t;
    humWeek[GRAPH_WEEK - 1] = h;
    presWeek[GRAPH_WEEK - 1] = p;
  }
  weekFilled = (weekIndex >= GRAPH_WEEK);

  // Месяц
  if (monthIndex < GRAPH_MONTH) {
    tempMonth[monthIndex] = t;
    humMonth[monthIndex] = h;
    presMonth[monthIndex] = p;
    monthIndex++;
  } else {
    for (int i = 0; i < GRAPH_MONTH - 1; i++) {
      tempMonth[i] = tempMonth[i + 1];
      humMonth[i] = humMonth[i + 1];
      presMonth[i] = presMonth[i + 1];
    }
    tempMonth[GRAPH_MONTH - 1] = t;
    humMonth[GRAPH_MONTH - 1] = h;
    presMonth[GRAPH_MONTH - 1] = p;
  }
  monthFilled = (monthIndex >= GRAPH_MONTH);
}

// ==================== ЗАГРУЗКА С SD ====================
extern bool sdReady;
extern bool sdSafeToRemove;

// ===================================================================
// Парсер строки daily_*.csv
// Формат: "date;T_avg;T_min;T_max;H_avg;H_min;H_max;P_avg;P_min;P_max;count"
// Возвращает T_avg, H_avg, P_avg (средние за день) — их и кладём в графики.
// Отличие от parseCsvLine (для hourly_*.csv): 10 числовых полей после даты,
// и нужны 0-е, 3-е и 6-е (avg), а не 0-е, 1-е, 2-е.
// ===================================================================
static bool parseDailyLine(const char* line, float* t, float* h, float* p) {
  const char* s = strchr(line, ';');
  if (!s) return false;
  s++;  // пропустили дату

  float vals[10];
  int n = 0;
  char buf[16];

  while (*s && n < 10) {
    int i = 0;
    while (*s && *s != ';' && *s != '\n' && *s != '\r' && i < 15) {
      buf[i++] = (*s == ',') ? '.' : *s;
      s++;
    }
    buf[i] = '\0';
    vals[n++] = atof(buf);
    if (*s == ';') s++;
  }

  if (n < 9) return false;  // нужно минимум 9 числовых полей

  // vals[0]=T_avg, vals[1]=T_min, vals[2]=T_max
  // vals[3]=H_avg, vals[4]=H_min, vals[5]=H_max
  // vals[6]=P_avg, vals[7]=P_min, vals[8]=P_max
  *t = vals[0];
  *h = vals[3];
  *p = vals[6];
  return true;
}


// Чтение одного daily_*.csv в week/month
static void loadDailyFile(const char* fname) {
  File f = SD.open(fname, FILE_READ);
  if (!f) return;

  // Пропускаем заголовок (первая строка)
  {
    char hdr[80];
    f.readBytesUntil('\n', hdr, sizeof(hdr) - 1);
  }

  char line[120];  // daily-строки длиннее hourly (10 полей + дата)
  int loaded = 0;
  int skipped = 0;
  while (f.available()) {
    size_t len = f.readBytesUntil('\n', line, sizeof(line) - 1);
    if (len == 0) continue;
    line[len] = '\0';
    if (len > 0 && line[len - 1] == '\r') line[len - 1] = '\0';

    if (strlen(line) < 20) continue;  // daily-строка короче 20 символов — мусор

    float t, h, p;
    if (!parseDailyLine(line, &t, &h, &p)) {
      skipped++;
      continue;
    }

    // Диапазоны (теперь про правильные поля: T_avg, H_avg, P_avg)
    if (t < -50.0f || t > 60.0f) {
      skipped++;
      continue;
    }
    if (h < 0.0f || h > 100.0f) {
      skipped++;
      continue;
    }
    if (p < 600.0f || p > 850.0f) {
      skipped++;
      continue;
    }

    graphAddDay(t, h, p);
    loaded++;
  }
  f.close();

  if (skipped > 0) {
    LOG_D("loadDailyFile: %s — загружено %d, пропущено %d",
          fname, loaded, skipped);
  }
}

// ===================================================================
// Чтение hourly_*.csv с КОНЦА (последние 24 строки)
// ===================================================================
struct LoadHourlyCtx {
  float t[GRAPH_HOURS];
  float h[GRAPH_HOURS];
  float p[GRAPH_HOURS];
  int count;
  int skipped;
};

static bool loadHourlyCallback(const char* line, void* ctx) {
  LoadHourlyCtx* c = (LoadHourlyCtx*)ctx;
  if (c->count >= GRAPH_HOURS) return true;  // уже 24 — стоп

  if (strlen(line) < 10) return false;

  float t, h, p;
  if (!parseCsvLine(line, &t, &h, &p)) { c->skipped++; return false; }
  if (t < -50.0f || t > 60.0f)  { c->skipped++; return false; }
  if (h < 0.0f || h > 100.0f)   { c->skipped++; return false; }
  if (p < 600.0f || p > 850.0f) { c->skipped++; return false; }

  c->t[c->count] = t;
  c->h[c->count] = h;
  c->p[c->count] = p;
  c->count++;
  return false;
}

// append == false — перезаписать буфер (текущий файл)
// append == true  — дополнить спереди (прошлый файл, если в текущем < 24)
static void loadHourlyFile(const char* fname, bool append) {
  File f = SD.open(fname, FILE_READ);
  if (!f) return;

  LoadHourlyCtx ctx;
  ctx.count = 0;
  ctx.skipped = 0;

  readFileBackwards(f, loadHourlyCallback, &ctx, 256);
  f.close();

  if (!append) {
    // Перезапись: чистим буфер и кладём n последних строк в конец
    for (int i = 0; i < GRAPH_HOURS; i++) {
      tempHour[i] = 0; humHour[i] = 0; presHour[i] = 0;
    }
    int n = ctx.count;
    int offset = GRAPH_HOURS - n;
    for (int i = 0; i < n; i++) {
      tempHour[offset + i] = ctx.t[n - 1 - i];
      humHour[offset + i]  = ctx.h[n - 1 - i];
      presHour[offset + i] = ctx.p[n - 1 - i];
    }
    hourFilled = (n >= GRAPH_HOURS);
    hourIndex = n % GRAPH_HOURS;
  } else {
    // Дополнение спереди: сколько не хватает?
    int existing = 0;
    for (int i = 0; i < GRAPH_HOURS; i++) {
      if (tempHour[i] != 0) existing++;
    }
    int need = GRAPH_HOURS - existing;
    if (need > ctx.count) need = ctx.count;
    // Сдвигаем existing вправо на need
    for (int i = GRAPH_HOURS - 1; i >= need; i--) {
      tempHour[i] = tempHour[i - need];
      humHour[i]  = humHour[i - need];
      presHour[i] = presHour[i - need];
    }
    // Берём последние need строк из ctx (они ближе к концу прошлого файла),
    // ставим в начало (в прямом порядке: старое → новое).
    // ctx[count-1] — самая старая, ctx[0] — самая свежая (из прошлого файла).
    // Нам нужны последние need (ближайшие к концу файла) — это ctx[0..need-1],
    // но в прямом порядке (от старого к новому) → ставим в обратном:
    // начало буфера = ctx[need-1], ..., конец = ctx[0].
    for (int i = 0; i < need; i++) {
      tempHour[i] = ctx.t[need - 1 - i];
      humHour[i]  = ctx.h[need - 1 - i];
      presHour[i] = ctx.p[need - 1 - i];
    }
    hourFilled = (existing + need >= GRAPH_HOURS);
    hourIndex = (existing + need) % GRAPH_HOURS;
  }

  if (ctx.skipped > 0) {
    LOG_D("loadHourlyFile: %s — загружено %d, пропущено %d",
          fname, ctx.count, ctx.skipped);
  }
}

// ==================== ГЛАВНАЯ: ЗАГРУЗКА ====================
void loadGraphsFromArchive() {
  if (!sdReady || sdSafeToRemove) {
    LOG_D("loadGraphs: SD не готова");
    return;
  }

    LOG_D("loadGraphs: сканирование SD...");

  // Сброс массивов
  for (int i = 0; i < GRAPH_HOURS; i++) {
    tempHour[i] = 0;
    humHour[i] = 0;
    presHour[i] = 0;
  }
  for (int i = 0; i < GRAPH_WEEK; i++) {
    tempWeek[i] = 0;
    humWeek[i] = 0;
    presWeek[i] = 0;
  }
  for (int i = 0; i < GRAPH_MONTH; i++) {
    tempMonth[i] = 0;
    humMonth[i] = 0;
    presMonth[i] = 0;
  }
  hourFilled = weekFilled = monthFilled = false;
  weekIndex = monthIndex = 0;

  // Сканируем корень
  File root = SD.open("/");
  if (!root) {
    LOG_E("loadGraphs: FAIL open /");
    return;
  }

  // Собираем список daily_*.csv (для week/month) и hourly_*.csv (для hour)
  // Важно: daily_*.csv могут быть за разные месяцы — читаем ВСЕ, накапливаем graphAddDay
  // (graphAddDay сам сдвигает и ведёт week/month)
  // Но нам нужны ПОСЛЕДНИЕ 30 дней — значит, надо собрать все записи, отсортировать, взять 30.
  // Проще: читаем все daily_*.csv в порядке имён (YYYY-MM), graphAddDay добавляет по одной.
  // graphAddDay уже сдвигает week/month — значит, если файлов > 30 дней, старые уйдут в сдвиг. ✅

  int dailyCount = 0;
  int hourlyCount = 0;

  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    if (entry.isDirectory()) {
      entry.close();
      continue;
    }
    char name[32];
    strncpy(name, entry.name(), sizeof(name) - 1);
    name[sizeof(name) - 1] = '\0';
    entry.close();

    if (strncmp(name, "daily_", 6) == 0 && strstr(name, ".csv") != nullptr && strcmp(name, "daily_temp.csv") != 0) {
      dailyCount++;
      char path[48];
      snprintf(path, sizeof(path), "/%s", name);
      loadDailyFile(path);
    } else if (strncmp(name, "hourly_", 7) == 0 && strstr(name, ".csv") != nullptr) {
      hourlyCount++;
    }
  }
  root.close();

  // Hourly — читаем ДВА последних hourly_*.csv (текущий + прошлый месяц),
  // в хронологическом порядке (старый → новый). Это закрывает баг
  // 1-го числа: в новом файле ещё нет 24 записей, а старый не читался.
  // loadHourlyFile сдвигает кольцевой буфер на каждую строку, поэтому
  // после чтения старого (24 строки) и нового (0–N) в буфере останутся
  // последние 24 записи в правильном порядке.
  if (hourlyCount > 0) {
    // Собираем имена всех hourly_*.csv
    const int MAX_HOURLY = 24;         // запас на 2 года
    char hourlyNames[MAX_HOURLY][24];  // "hourly_YYYY-MM.csv" = 19 символов + запас
    int hourlyNamesCount = 0;

    root = SD.open("/");
    if (root) {
      while (true) {
        File entry = root.openNextFile();
        if (!entry) break;
        if (entry.isDirectory()) {
          entry.close();
          continue;
        }
        char name[24];
        strncpy(name, entry.name(), sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
        entry.close();
        if (strncmp(name, "hourly_", 7) == 0 && strstr(name, ".csv") != nullptr) {
          if (hourlyNamesCount < MAX_HOURLY) {
            strncpy(hourlyNames[hourlyNamesCount], name, sizeof(hourlyNames[0]) - 1);
            hourlyNames[hourlyNamesCount][sizeof(hourlyNames[0]) - 1] = '\0';
            hourlyNamesCount++;
          }
        }
      }
      root.close();
    }

    // Сортируем по имени (YYYY-MM) — лексикографически = хронологически
    for (int i = 0; i < hourlyNamesCount - 1; i++) {
      for (int j = 0; j < hourlyNamesCount - i - 1; j++) {
        if (strcmp(hourlyNames[j], hourlyNames[j + 1]) > 0) {
          char tmp[24];
          strncpy(tmp, hourlyNames[j], sizeof(tmp) - 1);
          tmp[sizeof(tmp) - 1] = '\0';
          strncpy(hourlyNames[j], hourlyNames[j + 1], sizeof(hourlyNames[0]) - 1);
          hourlyNames[j][sizeof(hourlyNames[0]) - 1] = '\0';
          strncpy(hourlyNames[j + 1], tmp, sizeof(hourlyNames[0]) - 1);
          hourlyNames[j + 1][sizeof(hourlyNames[0]) - 1] = '\0';
        }
      }
    }

        // Читаем ТЕКУЩИЙ (последний по имени) с конца (append=false).
    // Если в нём < 24 строк — добираем с ПРОШЛОГО (append=true).
    int startIdx = (hourlyNamesCount >= 2) ? (hourlyNamesCount - 2) : 0;
    for (int i = hourlyNamesCount - 1; i >= startIdx; i--) {
      char path[48];
      snprintf(path, sizeof(path), "/%s", hourlyNames[i]);
      LOG_D("loadGraphs: hourly -> %s", path);
      bool isCurrent = (i == hourlyNamesCount - 1);
      loadHourlyFile(path, !isCurrent);
      if (isCurrent) {
        int cnt = 0;
        for (int k = 0; k < GRAPH_HOURS; k++) if (tempHour[k] != 0) cnt++;
        if (cnt >= GRAPH_HOURS) break;  // текущего хватило
      }
    }
  }

  LOG_D("loadGraphs: daily=%d, hourly=%d, week=%d, month=%d",
        dailyCount, hourlyCount,
        weekFilled ? GRAPH_WEEK : weekIndex,
        monthFilled ? GRAPH_MONTH : monthIndex);
}

// ==================== ОТРИСОВКА: ГРАФИК ====================

// ==================== ОТРИСОВКА: ГРАФИК ====================
static void drawGraphFixed(float data[], int size, const char* label,
                           float minVal, float maxVal, float midVal,
                           const char* timeLabels[], int timeCount) {
  tft.fillScreen(TFT_BLACK);

  // Заголовок
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print(label);

  // Область графика (расширенная)
  int startX = 30;
  int endX = 475;
  int topY = 45;
  int bottomY = 250;

  // Сетка (5 линий) + подписи значений по Y (все 5)
  tft.drawLine(startX, topY, startX, bottomY, TFT_DARKGREY);
  tft.drawLine(startX, bottomY, endX, bottomY, TFT_DARKGREY);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(1);
  char yBuf[16];
  for (int i = 0; i <= 4; i++) {
    int y = bottomY - (bottomY - topY) * i / 4;
    tft.drawLine(startX, y, endX, y, TFT_DARKGREY);
    float val = minVal + (maxVal - minVal) * i / 4.0f;
    snprintf(yBuf, sizeof(yBuf), "%.0f", val);
    tft.setCursor(5, y - 4);
    tft.print(yBuf);
  }

  // Вертикальная сетка по временным меткам (пунктир, справа от оси Y)
  // (количество меток зависит от периода, мы передадим его позже, а пока заглушка)
  // Сетку будем рисовать после того, как добавим метки, чтобы знать их координаты.
  // Пока оставим место.

  // Средняя линия (пунктир)
  int midY = bottomY - (bottomY - topY) * (midVal - minVal) / (maxVal - minVal);
  for (int x = startX; x < endX; x += 4) {
    tft.drawPixel(x, midY, TFT_DARKGREY);
  }

  // График
  int validCount = 0;
  for (int i = 0; i < size; i++)
    if (data[i] != 0) validCount++;

  if (validCount < 2) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(180, 140);
    tft.print("Нет данных");
    return;
  }

  int lastX = -1, lastY = -1;
  for (int i = 0; i < size; i++) {
    if (data[i] == 0) continue;
    int x = startX + (endX - startX) * i / (size - 1);
    int y = bottomY - (bottomY - topY) * (data[i] - minVal) / (maxVal - minVal);
    if (y < topY) y = topY;
    if (y > bottomY) y = bottomY;

    if (lastX != -1) tft.drawLine(lastX, lastY, x, y, TFT_GREEN);
    tft.fillCircle(x, y, 2, TFT_YELLOW);
    lastX = x;
    lastY = y;
  }

  // ===== ВЕРТИКАЛЬНАЯ СЕТКА И ВРЕМЕННЫЕ МЕТКИ =====
  if (timeCount > 0) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);

    for (int i = 0; i < timeCount; i++) {
      int x = startX + (endX - startX) * i / (timeCount - 1);

      // 1. Вертикальная линия (NAVY, пунктир, кроме левого края i=0)
      if (i > 0) {
        for (int y = topY; y <= bottomY; y += 4) {
          tft.drawPixel(x, y, TFT_NAVY);
        }
      }

      // 2. Подпись времени (выравниваем по центру, крайние — по краю)
      int textX = x - 15;  // По центру для средних
      if (i == 0) {
        textX = x;  // Левая — от линии вправо
      } else if (i == timeCount - 1) {
        // Правая — динамический сдвиг в зависимости от длины текста
        int textLen = strlen(timeLabels[i]);
        int textWidth = textLen * 6;  // Примерная ширина символа size 1 = 6px
        textX = x - textWidth;
      }
      tft.setCursor(textX, bottomY + 10);
      tft.print(timeLabels[i]);
    }
  }
}

// ==================== ОТРИСОВКА: ТОЧКИ-ИНДИКАТОР ====================
static void drawGraphDots() {
  // 3 группы по 3 точки: T: ● ● ●   H: ● ● ●   P: ● ● ●
  const int dotR = 4;
  const int groupGap = 20;
  const int dotGap = 12;
  const int y = 300;
  const char* labels[3] = { "T:", "H:", "P:" };

  int x = 140;
  for (int g = 0; g < 3; g++) {
    // Подпись группы
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(x, y - 10);
    tft.print(labels[g]);
    x += 30;

    for (int p = 0; p < 3; p++) {
      bool active = (g == graphParam && p == graphPeriod);
      uint16_t color = active ? TFT_GREEN : TFT_DARKGREY;
      tft.fillCircle(x, y, dotR, color);
      x += dotGap;
    }
    x += groupGap;
  }
}

// ==================== ОТРИСОВКА ЭКРАНА ====================
void drawGraphScreen() {
  // Заголовок: "Температура · 24ч"
  const char* paramNames[3] = { "Температура", "Влажность", "Давление" };
  const char* periodNames[3] = { "24ч", "7д", "30д" };
  char title[48];
  snprintf(title, sizeof(title), "%s · %s", paramNames[graphParam], periodNames[graphPeriod]);

  // Выбор данных
  float* data = nullptr;
  int size = 0;
  bool filled = false;
  float minVal, maxVal, midVal;

  if (graphParam == 0) {
    minVal = -35;
    maxVal = 45;
    midVal = 0;
    if (graphPeriod == 0) {
      data = tempHour;
      size = GRAPH_HOURS;
      filled = hourFilled;
    } else if (graphPeriod == 1) {
      data = tempWeek;
      size = GRAPH_WEEK;
      filled = weekFilled;
    } else {
      data = tempMonth;
      size = GRAPH_MONTH;
      filled = monthFilled;
    }
  } else if (graphParam == 1) {
    minVal = 20;
    maxVal = 100;
    midVal = 60;
    if (graphPeriod == 0) {
      data = humHour;
      size = GRAPH_HOURS;
      filled = hourFilled;
    } else if (graphPeriod == 1) {
      data = humWeek;
      size = GRAPH_WEEK;
      filled = weekFilled;
    } else {
      data = humMonth;
      size = GRAPH_MONTH;
      filled = monthFilled;
    }
  } else {
    minVal = 725;
    maxVal = 775;
    midVal = 750;
    if (graphPeriod == 0) {
      data = presHour;
      size = GRAPH_HOURS;
      filled = hourFilled;
    } else if (graphPeriod == 1) {
      data = presWeek;
      size = GRAPH_WEEK;
      filled = weekFilled;
    } else {
      data = presMonth;
      size = GRAPH_MONTH;
      filled = monthFilled;
    }
  }

  // ===== ФОРМИРУЕМ ВРЕМЕННЫЕ МЕТКИ (Подход А: скользящие) =====
  static char tLabels[10][8];  // Увеличили до 10 (с запасом на 8 меток)
  const char* tLabelPtrs[15];
  int tCount = 0;

  // Получаем текущее время
  DateTime now = rtcClock.getTime();

  if (graphPeriod == 0) {
    // 24 часа (8 меток с шагом 3 часа)
    tCount = 8;
    for (int i = 0; i < 8; i++) {
      int h = (now.hour() - 21 + (i * 3) + 24) % 24;
      snprintf(tLabels[i], 8, "%02d:00", h);
      tLabelPtrs[i] = tLabels[i];
    }
  } else if (graphPeriod == 1) {
    // 7 дней (7 меток: дни недели)
    tCount = 7;
    // В RTClib dayOfTheWeek() возвращает 0=Вс, 1=Пн, ... 6=Сб
    // Приведем к массиву, где 0=Пн, 1=Вт, ... 6=Вс
    int todayDow = (now.dayOfTheWeek() + 6) % 7;
    const char* dowNames[7] = { "Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс" };

    for (int i = 0; i < 7; i++) {
      // Сдвиг назад на 6 дней (самый старый) + i (текущий шаг)
      int d = (todayDow - 6 + i + 7) % 7;
      // Копируем строку в наш буфер
      snprintf(tLabels[i], 8, "%s", dowNames[d]);
      tLabelPtrs[i] = tLabels[i];
    }
  } else {
    // 30 дней (11 меток с шагом 3 дня)
    // i=0 — 30 дней назад (самая старая точка), i=10 — сегодня.
    // Используем DateTime - TimeSpan, чтобы корректно перейти через границу месяца.
    tCount = 11;
    for (int i = 0; i < 11; i++) {
      int daysAgo = 30 - (i * 3);  // 30, 27, 24, ..., 0
      DateTime dt = now - TimeSpan(daysAgo, 0, 0, 0);
      snprintf(tLabels[i], 8, "%d", dt.day());
      tLabelPtrs[i] = tLabels[i];
    }
  }

  // Передаем метки в функцию отрисовки
  drawGraphFixed(data, size, title, minVal, maxVal, midVal, tLabelPtrs, tCount);
  drawGraphDots();
}

// ==================== НАВИГАЦИЯ ====================
void enterGraphsMode() {
  currentMode = MODE_GRAPHS;
  graphParam = 0;
  graphPeriod = 0;
  lastGraphActivity = millis();
  drawGraphScreen();
  LOG_D("📊 MODE_GRAPHS");
}

void exitGraphsMode() {
  currentMode = MODE_MAIN;
  needFullRedraw = true;
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();  // сброс таймаута сигнала (пока были в графиках, пакеты не принимались)
  tft.fillScreen(TFT_BLACK);
  redrawMainScreen();  // полная перерисовка главного экрана
  LOG_D("🏠 Выход из MODE_GRAPHS");
}

void handleGraphsNavigation() {
  // Таймаут
  if (millis() - lastGraphActivity > GRAPH_TIMEOUT_MS) {
    exitGraphsMode();
    return;
  }

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) {
    delay(50);
    return;
  }
  lastGraphActivity = millis();

  switch (key) {
    case KEY_LEFT:
      graphPeriod = (graphPeriod + 2) % 3;
      drawGraphScreen();
      break;
    case KEY_RIGHT:
      graphPeriod = (graphPeriod + 1) % 3;
      drawGraphScreen();
      break;
    case KEY_UP:
      graphParam = (graphParam + 2) % 3;
      drawGraphScreen();
      break;
    case KEY_DOWN:
      graphParam = (graphParam + 1) % 3;
      drawGraphScreen();
      break;
    case KEY_OK:
      exitGraphsMode();
      break;
  }
}