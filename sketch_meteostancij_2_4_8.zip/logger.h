// logger.h
#ifndef LOGGER_H
#define LOGGER_H

#include <Arduino.h>

#if ARDUINO_USB_CDC_ON_BOOT
#define LOG_SERIAL Serial0
#else
#define LOG_SERIAL Serial
#endif

// ==================== УРОВНИ ====================
#define LOG_LEVEL_NONE   0
#define LOG_LEVEL_ERROR  1
#define LOG_LEVEL_WARN   2
#define LOG_LEVEL_INFO   3
#define LOG_LEVEL_DEBUG  4

// ==================== ТЕКУЩИЙ УРОВЕНЬ ====================
// По умолчанию — только ошибки. Переключается командой 'd' в Serial.
extern int g_logLevel;

void loggerInit();
void loggerSetLevel(int level);
int  loggerGetLevel();
void loggerToggleDebug();

// ==================== МАКРОСЫ ====================
#define LOG_E(fmt, ...) do { if (g_logLevel >= LOG_LEVEL_ERROR) LOG_SERIAL.printf("[E] " fmt "\n", ##__VA_ARGS__); } while (0)
#define LOG_W(fmt, ...) do { if (g_logLevel >= LOG_LEVEL_WARN)  LOG_SERIAL.printf("[W] " fmt "\n", ##__VA_ARGS__); } while (0)
#define LOG_I(fmt, ...) do { if (g_logLevel >= LOG_LEVEL_INFO)  LOG_SERIAL.printf("[I] " fmt "\n", ##__VA_ARGS__); } while (0)
#define LOG_D(fmt, ...) do { if (g_logLevel >= LOG_LEVEL_DEBUG) LOG_SERIAL.printf("[D] " fmt "\n", ##__VA_ARGS__); } while (0)

// Быстрые варианты (без форматирования, для простых строк)
#define LOG_E_RAW(s) do { if (g_logLevel >= LOG_LEVEL_ERROR) LOG_SERIAL.println(s); } while (0)
#define LOG_I_RAW(s) do { if (g_logLevel >= LOG_LEVEL_INFO)  LOG_SERIAL.println(s); } while (0)
#define LOG_D_RAW(s) do { if (g_logLevel >= LOG_LEVEL_DEBUG) LOG_SERIAL.println(s); } while (0)

#endif  // LOGGER_H