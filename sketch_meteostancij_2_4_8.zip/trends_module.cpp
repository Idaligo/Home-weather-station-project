#include "trends_module.h"
#include "logger.h"

// ==================== СТАТИЧЕСКИЕ ПОРОГИ ====================
static const TrendThresholds TEMP_THRESHOLDS = {
  .fastUp = 0.0022f,   // было 0.0040, делим на ~1.8
  .slowUp = 0.0005f,   // было 0.0010, делим на 2
  .fastDown = -0.0022f,
  .slowDown = -0.0005f
};

static const TrendThresholds HUM_THRESHOLDS = {
  .fastUp = 0.0047f,   // было 0.0085
  .slowUp = 0.0008f,   // было 0.0015
  .fastDown = -0.0047f,
  .slowDown = -0.0008f
};

static const TrendThresholds PRES_THRESHOLDS = {
  .fastUp = 0.0003f,   // было 0.0006
  .slowUp = 0.0001f,   // было 0.0002
  .fastDown = -0.0003f,
  .slowDown = -0.0001f
};

// ==================== КОНСТРУКТОР ====================
Trends::Trends() {
  tempHistoryIndex = 0;
  humHistoryIndex = 0;
  presHistoryIndex = 0;

  lastTempTrend = 0;
  lastHumTrend = 0;
  lastPresTrend = 0;

  lastTempSpeed = 0;
  lastHumSpeed = 0;
  lastPresSpeed = 0;

  tempValid = false;
  humValid = false;
  presValid = false;

  tempTrendChanged = false;
  humTrendChanged = false;
  presTrendChanged = false;

  lastTrendUpdate = 0;

  // Инициализация порогов
  initThresholds();

  // Инициализация буферов нулями
  for (int i = 0; i < HISTORY_BUFFER_SIZE; i++) {
    tempHistory[i].timestamp = 0;
    tempHistory[i].value = 0;
    humHistory[i].timestamp = 0;
    humHistory[i].value = 0;
    presHistory[i].timestamp = 0;
    presHistory[i].value = 0;
  }
}

// ==================== ИНИЦИАЛИЗАЦИЯ ПОРОГОВ ====================
void Trends::initThresholds() {
  tempTh = TEMP_THRESHOLDS;
  humTh = HUM_THRESHOLDS;
  presTh = PRES_THRESHOLDS;
}

// ==================== ДОБАВЛЕНИЕ ДАННЫХ В ИСТОРИЮ ====================
void Trends::addData(float temperature, float humidity, float pressure) {
  pushToHistory(tempHistory, tempHistoryIndex, temperature);
  pushToHistory(humHistory, humHistoryIndex, humidity);
  pushToHistory(presHistory, presHistoryIndex, pressure);
}

// ==================== ОБНОВЛЕНИЕ ТРЕНДОВ ====================
void Trends::updateTrends() {
  unsigned long now = millis();

  // Обновляем тренды раз в 45 секунд
  if (now - lastTrendUpdate < 65000) {
    return;
  }
  lastTrendUpdate = now;

  int newTempTrend = lastTempTrend;
  int newHumTrend = lastHumTrend;
  int newPresTrend = lastPresTrend;

  // === ТЕМПЕРАТУРА ===
  tempValid = linearRegression(tempHistory, HISTORY_BUFFER_SIZE, &lastTempSpeed, NULL, MAX_DATA_AGE_SEC);
  if (tempValid) {
    newTempTrend = calculateTrend(lastTempSpeed, tempTh, lastTempTrend);
  }

  // === ВЛАЖНОСТЬ ===
  humValid = linearRegression(humHistory, HISTORY_BUFFER_SIZE, &lastHumSpeed, NULL, MAX_DATA_AGE_SEC);
  if (humValid) {
    newHumTrend = calculateTrend(lastHumSpeed, humTh, lastHumTrend);
  }

  // === ДАВЛЕНИЕ ===
  presValid = linearRegression(presHistory, HISTORY_BUFFER_SIZE, &lastPresSpeed, NULL, MAX_DATA_AGE_SEC);
  if (presValid) {
    newPresTrend = calculateTrend(lastPresSpeed, presTh, lastPresTrend);
  }

  // ========== ПРОВЕРКА ИЗМЕНЕНИЙ ==========
  tempTrendChanged = (newTempTrend != lastTempTrend);
  humTrendChanged = (newHumTrend != lastHumTrend);
  presTrendChanged = (newPresTrend != lastPresTrend);

  // Обновляем изменившиеся тренды
  if (tempTrendChanged) {
    lastTempTrend = newTempTrend;
  }

  if (humTrendChanged) {
    lastHumTrend = newHumTrend;
  }

  if (presTrendChanged) {
    lastPresTrend = newPresTrend;
  }

  // Выводим отладку только если есть изменения
  if (tempTrendChanged || humTrendChanged || presTrendChanged) {
    printDebug();
  }
}

// ==================== СБРОС ФЛАГОВ ИЗМЕНЕНИЙ ====================
void Trends::resetTrendChangedFlags() {
  tempTrendChanged = false;
  humTrendChanged = false;
  presTrendChanged = false;
}

// ==================== РАСЧЁТ ТРЕНДА С ГИСТЕРЕЗИСОМ ====================
int Trends::calculateTrend(float speed, const TrendThresholds& thresholds, int lastTrend) {
  int newTrend = 0;

  // Выбор коэффициентов гистерезиса
  float fastOffRatio, slowOffRatio;

  if (&thresholds == &tempTh) {
    fastOffRatio = FAST_OFF_RATIO_TEMP;
    slowOffRatio = SLOW_OFF_RATIO_TEMP;
  } else if (&thresholds == &humTh) {
    fastOffRatio = FAST_OFF_RATIO_HUM;
    slowOffRatio = SLOW_OFF_RATIO_HUM;
  } else {
    fastOffRatio = FAST_OFF_RATIO_PRES;
    slowOffRatio = SLOW_OFF_RATIO_PRES;
  }

  if (lastTrend == 0) {
    // Включение нового тренда (полные пороги)
    if (speed > thresholds.fastUp) {
      newTrend = 2;
    } else if (speed > thresholds.slowUp) {
      newTrend = 1;
    } else if (speed < thresholds.fastDown) {
      newTrend = -2;
    } else if (speed < thresholds.slowDown) {
      newTrend = -1;
    } else {
      newTrend = 0;
    }
  } else {
    // Уже в тренде - проверяем по сниженным порогам
    if (lastTrend == 2) {
      if (speed > thresholds.fastUp * fastOffRatio) {
        newTrend = 2;
      } else if (speed > thresholds.slowUp) {
        newTrend = 1;
      } else {
        newTrend = 0;
      }
    } else if (lastTrend == 1) {
      if (speed > thresholds.fastUp) {
        newTrend = 2;
      } else if (speed > thresholds.slowUp * slowOffRatio) {
        newTrend = 1;
      } else {
        newTrend = 0;
      }
    } else if (lastTrend == -2) {
      if (speed < thresholds.fastDown * fastOffRatio) {
        newTrend = -2;
      } else if (speed < thresholds.slowDown) {
        newTrend = -1;
      } else {
        newTrend = 0;
      }
    } else if (lastTrend == -1) {
      if (speed < thresholds.fastDown) {
        newTrend = -2;
      } else if (speed < thresholds.slowDown * slowOffRatio) {
        newTrend = -1;
      } else {
        newTrend = 0;
      }
    }
  }

  return newTrend;
}

// ==================== ДОБАВЛЕНИЕ ТОЧКИ В ИСТОРИЮ ====================
void Trends::pushToHistory(HistoryPoint* buffer, int& index, float value) {
  unsigned long currentTime = millis();
  buffer[index].timestamp = currentTime;
  buffer[index].value = value;
  index = (index + 1) % HISTORY_BUFFER_SIZE;
}

// ==================== ЛИНЕЙНАЯ РЕГРЕССИЯ ====================
bool Trends::linearRegression(const HistoryPoint* points, int numPoints, float* slope, float* offset, float maxDataAgeSec) {
  if (points == NULL || slope == NULL || numPoints < 3) return false;

  float sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  int validPoints = 0;
  unsigned long currentTime = millis();

  unsigned long baseTime = 0;
  for (int i = 0; i < numPoints; i++) {
    if (points[i].timestamp > 0 && (currentTime - points[i].timestamp) <= (unsigned long)(maxDataAgeSec * 1000)) {
      if (baseTime == 0 || points[i].timestamp < baseTime) {
        baseTime = points[i].timestamp;
      }
    }
  }
  if (baseTime == 0) return false;

  for (int i = 0; i < numPoints; i++) {
    if (points[i].timestamp == 0) continue;

    unsigned long age = currentTime - points[i].timestamp;
    if (age > (unsigned long)(maxDataAgeSec * 1000)) continue;

    float x = (float)(points[i].timestamp - baseTime) / 1000.0f;
    float y = points[i].value;

    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumXX += x * x;
    validPoints++;
  }

  if (validPoints < 3) return false;

  float denominator = validPoints * sumXX - sumX * sumX;
  if (fabs(denominator) < 0.0001f) return false;

  *slope = (validPoints * sumXY - sumX * sumY) / denominator;

  if (offset != NULL) {
    *offset = (sumY - (*slope) * sumX) / validPoints;
  }

  return true;
}

// ==================== ПРИМЕНЕНИЕ ПОРОГОВ ИЗ МЕНЮ ====================
void Trends::setThresholds(const TrendThresholds& t, const TrendThresholds& h, const TrendThresholds& p,
                           float tempFastOff, float tempSlowOff,
                           float humFastOff, float humSlowOff,
                           float presFastOff, float presSlowOff) {
  tempTh = t;
  humTh = h;
  presTh = p;

  FAST_OFF_RATIO_TEMP = tempFastOff;
  SLOW_OFF_RATIO_TEMP = tempSlowOff;
  FAST_OFF_RATIO_HUM  = humFastOff;
  SLOW_OFF_RATIO_HUM  = humSlowOff;
  FAST_OFF_RATIO_PRES = presFastOff;
  SLOW_OFF_RATIO_PRES = presSlowOff;
}

// ==================== ОТЛАДОЧНАЯ ПЕЧАТЬ ====================
void Trends::printDebug() {
  if (tempTrendChanged) {
    LOG_D("📊 T тренд: %d (скорость %.4f)", lastTempTrend, lastTempSpeed);
  }
  if (humTrendChanged) {
    LOG_D("📊 H тренд: %d (скорость %.4f)", lastHumTrend, lastHumSpeed);
  }
  if (presTrendChanged) {
    LOG_D("📊 P тренд: %d (скорость %.4f)", lastPresTrend, lastPresSpeed);
  }
}