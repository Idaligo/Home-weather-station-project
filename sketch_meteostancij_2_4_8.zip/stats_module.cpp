// stats_module.cpp
#include "stats_module.h"
#include "common.h"
#include "keypad_module.h"
#include "graph_module.h"
#include "menu_module.h"
#include "rtc_module.h"
#include "temperature_module.h"
#include "humidity_module.h"
#include "pressure_module.h"
#include "logger.h"

extern TFT_eSPI tft;
extern AppMode currentMode;
extern RTCModule rtcClock;

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== СОСТОЯНИЕ ====================
static int statsScreen = 0;  // 0=День, 1=Неделя, 2=Месяц
static unsigned long lastStatsActivity = 0;

// ==================== ВНЕШНИЕ ДАННЫЕ ИЗ main.ino (дневные накопители) ====================
extern float daySumTemp, dayMinTemp, dayMaxTemp;
extern float daySumHum, dayMinHum, dayMaxHum;
extern float daySumPres, dayMinPres, dayMaxPres;
extern int dayMeasCount;

// ==================== ОТРИСОВКА: ТОЧКИ-ИНДИКАТОР ====================
static void drawStatsDots() {
  // 4 точки с подписями: С Д Н М (Сравнение, День, Неделя, Месяц)
  const int dotR = 4;
  const int dotGap = 20;
  const int y = 300;
  const char* labels[4] = { "С", "Д", "Н", "М" };

  int x = 140;
  for (int i = 0; i < 4; i++) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(x, y - 10);
    tft.print(labels[i]);
    x += 25;

    bool active = (i == statsScreen);
    uint16_t color = active ? TFT_GREEN : TFT_DARKGREY;
    tft.fillCircle(x, y, dotR, color);
    x += dotGap;
  }
}

// ==================== ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ 3 КОЛОНОК ====================
// Рисует строку с данными в 3 колонки
static void drawStatsRow(int y,
                         const char* label1, float val1, bool isInt1,
                         const char* label2, float val2, bool isInt2,
                         const char* label3, float val3, bool isInt3) {
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);

  // Колонка 1 (Температура)
  tft.setCursor(20, y);
  if (isInt1) tft.printf("%s %d", label1, (int)val1);
  else tft.printf("%s %.1f", label1, val1);

  // Колонка 2 (Влажность)
  tft.setCursor(180, y);
  if (isInt2) tft.printf("%s %d", label2, (int)val2);
  else tft.printf("%s %.1f", label2, val2);

  // Колонка 3 (Давление)
  tft.setCursor(340, y);
  if (isInt3) tft.printf("%s %d", label3, (int)val3);
  else tft.printf("%s %.1f", label3, val3);
}

// ==================== ОТРИСОВКА: ЭКРАН "СРАВНЕНИЕ" (0) ====================
extern bool loadHourlyForCompare(uint8_t hour, float* t, float* h, float* p);
extern TemperatureModule tempBlock;
extern HumidityModule humBlock;
extern PressureModule presBlock;

static void drawCompareStats() {
  tft.fillScreen(TFT_BLACK);

  // Заголовок с текущим часом
  DateTime now = rtcClock.getTime();
  char title[40];
  snprintf(title, sizeof(title), "vs вчера %02d:00", now.hour());

  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print(title);
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // Вчера в тот же час
  float yT = 0, yH = 0, yP = 0;
  bool found = loadHourlyForCompare(now.hour(), &yT, &yH, &yP);

  if (!found) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(150, 140);
    tft.print("Нет данных");
    tft.setTextSize(1);
    tft.setCursor(150, 170);
    tft.print("(вчера в этот час)");
    return;
  }

  // Текущие значения (напрямую из датчиков)
  float cT = tempBlock.getTemperature();
  float cH = humBlock.getHumidity();
  float cP = presBlock.getPressure();

  // Заголовки колонок
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(20, 70);
  tft.print("Температура");
  tft.setCursor(180, 70);
  tft.print("Влажность");
  tft.setCursor(340, 70);
  tft.print("Давление");

  // Строка 1: Сейчас
  drawStatsRow(110, "Сейчас:", cT, false, "Сейчас:", cH, false, "Сейчас:", cP, true);

  // Строка 2: Вчера
  drawStatsRow(150, "Вчера:", yT, false, "Вчера:", yH, false, "Вчера:", yP, true);

  // Строка 3: Разница
  float dT = cT - yT;
  float dH = cH - yH;
  float dP = cP - yP;

  tft.setTextSize(2);

  // Температура
  tft.setCursor(20, 190);
  tft.setTextColor(dT > 0 ? TFT_CYAN : (dT < 0 ? TFT_ORANGE : TFT_DARKGREY), TFT_BLACK);
  tft.printf("Разн: %+.1f", dT);
  // Треугольник
  int tx = tft.getCursorX() + 5;
  int ty = 190 + 8;
  if (dT > 0) tft.fillTriangle(tx, ty + 6, tx + 8, ty + 6, tx + 4, ty, TFT_CYAN);     // ▲
  else if (dT < 0) tft.fillTriangle(tx, ty, tx + 8, ty, tx + 4, ty + 6, TFT_ORANGE);  // ▼

  // Влажность
  tft.setCursor(180, 190);
  tft.setTextColor(dH > 0 ? TFT_CYAN : (dH < 0 ? TFT_ORANGE : TFT_DARKGREY), TFT_BLACK);
  tft.printf("Разн: %+.1f", dH);
  tx = tft.getCursorX() + 5;
  if (dH > 0) tft.fillTriangle(tx, ty + 6, tx + 8, ty + 6, tx + 4, ty, TFT_CYAN);
  else if (dH < 0) tft.fillTriangle(tx, ty, tx + 8, ty, tx + 4, ty + 6, TFT_ORANGE);

  // Давление (целым)
  tft.setCursor(340, 190);
  tft.setTextColor(dP > 0 ? TFT_CYAN : (dP < 0 ? TFT_ORANGE : TFT_DARKGREY), TFT_BLACK);
  tft.printf("Разн: %+d", (int)dP);
  tx = tft.getCursorX() + 5;
  if (dP > 0) tft.fillTriangle(tx, ty + 6, tx + 8, ty + 6, tx + 4, ty, TFT_CYAN);
  else if (dP < 0) tft.fillTriangle(tx, ty, tx + 8, ty, tx + 4, ty + 6, TFT_ORANGE);
}

// ==================== ОТРИСОВКА: ЭКРАН "ДЕНЬ" (1) ====================
static void drawDayStats() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Статистика дня");
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  if (dayMeasCount == 0) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(150, 140);
    tft.print("Нет данных");
    return;
  }

  float avgT = daySumTemp / dayMeasCount;
  float avgH = daySumHum / dayMeasCount;
  float avgP = daySumPres / dayMeasCount;

  // Заголовки колонок
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(20, 70);
  tft.print("Температура");
  tft.setCursor(180, 70);
  tft.print("Влажность");
  tft.setCursor(340, 70);
  tft.print("Давление");

  // Строки данных
  drawStatsRow(110, "Сред:", avgT, false, "Сред:", avgH, false, "Сред:", avgP, true);
  drawStatsRow(150, "Мин: ", dayMinTemp, false, "Мин: ", dayMinHum, false, "Мин: ", dayMinPres, true);
  drawStatsRow(190, "Макс:", dayMaxTemp, false, "Макс:", dayMaxHum, false, "Макс:", dayMaxPres, true);

  // Счётчик внизу
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(20, 260);
  tft.printf("Измерений: %d", dayMeasCount);
}

// ==================== ОТРИСОВКА: ЭКРАН "НЕДЕЛЯ" (2) ====================
static void drawWeekStats() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Статистика недели");
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  int count = 0;
  float sumT = 0, minT = 999, maxT = -999;
  float sumH = 0, minH = 999, maxH = -999;
  float sumP = 0, minP = 9999, maxP = -999;

  for (int i = 0; i < GRAPH_WEEK; i++) {
    if (tempWeek[i] != 0) {
      count++;
      sumT += tempWeek[i];
      if (tempWeek[i] < minT) minT = tempWeek[i];
      if (tempWeek[i] > maxT) maxT = tempWeek[i];
      sumH += humWeek[i];
      if (humWeek[i] < minH) minH = humWeek[i];
      if (humWeek[i] > maxH) maxH = humWeek[i];
      sumP += presWeek[i];
      if (presWeek[i] < minP) minP = presWeek[i];
      if (presWeek[i] > maxP) maxP = presWeek[i];
    }
  }

  if (count == 0) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(150, 140);
    tft.print("Нет данных");
    return;
  }

  // Заголовки колонок
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(20, 70);
  tft.print("Температура");
  tft.setCursor(180, 70);
  tft.print("Влажность");
  tft.setCursor(340, 70);
  tft.print("Давление");

  // Строки данных
  drawStatsRow(110, "Сред:", sumT / count, false, "Сред:", sumH / count, false, "Сред:", sumP / count, true);
  drawStatsRow(150, "Мин: ", minT, false, "Мин: ", minH, false, "Мин: ", minP, true);
  drawStatsRow(190, "Макс:", maxT, false, "Макс:", maxH, false, "Макс:", maxP, true);

  // Счётчик внизу
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(20, 260);
  tft.printf("Дней: %d", count);
}

// ==================== ОТРИСОВКА: ЭКРАН "МЕСЯЦ" (3) ====================
static void drawMonthStats() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Статистика месяца");
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  int count = 0;
  float sumT = 0, minT = 999, maxT = -999;
  float sumH = 0, minH = 999, maxH = -999;
  float sumP = 0, minP = 9999, maxP = -999;

  for (int i = 0; i < GRAPH_MONTH; i++) {
    if (tempMonth[i] != 0) {
      count++;
      sumT += tempMonth[i];
      if (tempMonth[i] < minT) minT = tempMonth[i];
      if (tempMonth[i] > maxT) maxT = tempMonth[i];
      sumH += humMonth[i];
      if (humMonth[i] < minH) minH = humMonth[i];
      if (humMonth[i] > maxH) maxH = humMonth[i];
      sumP += presMonth[i];
      if (presMonth[i] < minP) minP = presMonth[i];
      if (presMonth[i] > maxP) maxP = presMonth[i];
    }
  }

  if (count == 0) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(150, 140);
    tft.print("Нет данных");
    return;
  }

  // Заголовки колонок
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(20, 70);
  tft.print("Температура");
  tft.setCursor(180, 70);
  tft.print("Влажность");
  tft.setCursor(340, 70);
  tft.print("Давление");

  // Строки данных
  drawStatsRow(110, "Сред:", sumT / count, false, "Сред:", sumH / count, false, "Сред:", sumP / count, true);
  drawStatsRow(150, "Мин: ", minT, false, "Мин: ", minH, false, "Мин: ", minP, true);
  drawStatsRow(190, "Макс:", maxT, false, "Макс:", maxH, false, "Макс:", maxP, true);

  // Счётчик внизу
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(20, 260);
  tft.printf("Дней: %d", count);
}

// ==================== ОТРИСОВКА ЭКРАНА ====================
void drawStatsScreen() {
  switch (statsScreen) {
    case 0: drawCompareStats(); break;  // Сравнение первым
    case 1: drawDayStats(); break;
    case 2: drawWeekStats(); break;
    case 3: drawMonthStats(); break;
  }
  drawStatsDots();
}

// ==================== НАВИГАЦИЯ ====================
void enterStatsMode() {
  currentMode = MODE_STATS;
  statsScreen = 0;
  lastStatsActivity = millis();
  drawStatsScreen();
  LOG_D("📊 MODE_STATS");
}

void exitStatsMode() {
  currentMode = MODE_MAIN;
  needFullRedraw = true;
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();  // сброс таймаута сигнала (пока были в статистике, пакеты не принимались)
  tft.fillScreen(TFT_BLACK);
  redrawMainScreen();  // полная перерисовка главного экрана
  LOG_D("🏠 Выход из MODE_STATS");
}

void handleStatsNavigation() {
  if (millis() - lastStatsActivity > STATS_TIMEOUT_MS) {
    exitStatsMode();
    return;
  }

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) {
    delay(50);
    return;
  }
  lastStatsActivity = millis();

  switch (key) {
    case KEY_LEFT:
      statsScreen = (statsScreen + STATS_TOTAL - 1) % STATS_TOTAL;
      drawStatsScreen();
      break;
    case KEY_RIGHT:
      statsScreen = (statsScreen + 1) % STATS_TOTAL;
      drawStatsScreen();
      break;
    case KEY_OK:
      exitStatsMode();
      break;
  }
}