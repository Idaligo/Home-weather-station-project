// stats_module.h
#ifndef STATS_MODULE_H
#define STATS_MODULE_H

#include <Arduino.h>
#include <TFT_eSPI.h>

// ==================== КОНСТАНТЫ ====================
#define STATS_TOTAL 4  // День, Неделя, Месяц (Сравнение — позже)
#define STATS_TIMEOUT_MS 60000

// ==================== ФУНКЦИИ ====================
void enterStatsMode();
void exitStatsMode();
void handleStatsNavigation();
void drawStatsScreen();

#endif  // STATS_MODULE_H