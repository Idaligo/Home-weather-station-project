// openmeteo.h
#ifndef OPENMETEO_H
#define OPENMETEO_H

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ==================== КООРДИНАТЫ ====================
#define OPEN_METEO_LAT 47.267002
#define OPEN_METEO_LON 39.667836

// ===== СТРУКТУРА ДЛЯ ДАННЫХ OPEN-METEO =====
struct OpenMeteoData {
  bool isValid = false;
  unsigned long lastUpdate = 0;

  // Текущие данные
  float currentTemp = 0;
  float currentHumidity = 0;
  float currentPressure = 0;
  int currentWeatherCode = 0;

  // Прогноз на 6 часов
  float forecastTemp[6];
  float forecastHumidity[6];
  int forecastWeatherCode[6];
};

// ===== ФУНКЦИИ =====
bool fetchOpenMeteoData(float lat, float lon, OpenMeteoData& data);
const char* getWeatherDescription(int code);
int mapOpenMeteoToWeatherCode(int openMeteoCode);

#endif  // OPENMETEO_H