// debug_commands.h
#ifndef DEBUG_COMMANDS_H
#define DEBUG_COMMANDS_H

#include <Arduino.h>
#include "rtc_module.h"
#include "temperature_module.h"
#include "humidity_module.h"
#include "pressure_module.h"
#include "BME280_Module.h"
#include "weather_forecast.h"

// ==================== ОБЪЯВЛЕНИЯ ПЕРЕМЕННЫХ (extern) ====================
extern bool isDebugMode;     // только логи в Serial
extern bool isDataFake;      // подмена данных (только для отладки без радио!)
extern float debugTemp;
extern float debugHum;
extern float debugPres;
extern bool isNoSignalWarningActive;
extern bool noDataMessageShown;
extern bool hasFirstPacket;
extern int lastWeatherCode;
extern int lastForecastCode;
extern char lastForecastText[64];

// Переменные яркости
extern bool isBrightnessPendingSave;
extern unsigned long lastBrightnessChangeTime;

// ==================== ОБЪЯВЛЕНИЯ ФУНКЦИЙ ====================
void handleHWSerialCommands(RTCModule &rtcClock,
                            TemperatureModule &tempBlock,
                            HumidityModule &humBlock,
                            PressureModule &presBlock,
                            BME280Module &bmeModule,
                            WeatherForecast &forecast,
                            TFT_eSPI &tft);

void printAllCalibrations(TemperatureModule &tempBlock,
                          HumidityModule &humBlock,
                          PressureModule &presBlock,
                          BME280Module &bmeModule);

void printHelp();

// Эти функции объявлены как extern — они реализованы в основном файле
extern void showNoSignalWarning();
extern void clearWarningArea();

#endif  // DEBUG_COMMANDS_H