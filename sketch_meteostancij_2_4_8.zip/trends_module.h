#ifndef TRENDS_MODULE_H
#define TRENDS_MODULE_H

#include <Arduino.h>

// ==================== СТРУКТУРА ДЛЯ ПОРОГОВ ====================
struct TrendThresholds {
  float fastUp;
  float slowUp;
  float fastDown;
  float slowDown;
};

// ==================== СТРУКТУРА ДЛЯ ИСТОРИИ ТРЕНДОВ ====================
#define HISTORY_BUFFER_SIZE 10

struct HistoryPoint {
  unsigned long timestamp;
  float value;
};

// ==================== КЛАСС ТРЕНДОВ ====================
class Trends {
public:
  Trends();

  // Добавление новых данных
  void addData(float temperature, float humidity, float pressure);

  // Получение текущих трендов (возвращает -2, -1, 0, 1, 2)
  int getTempTrend() const {
    return lastTempTrend;
  }
  int getHumTrend() const {
    return lastHumTrend;
  }
  int getPresTrend() const {
    return lastPresTrend;
  }

  // Получение скоростей изменения
  float getTempSpeed() const {
    return lastTempSpeed;
  }
  float getHumSpeed() const {
    return lastHumSpeed;
  }
  float getPresSpeed() const {
    return lastPresSpeed;
  }

  // Проверка валидности данных
  bool isTempValid() const {
    return tempValid;
  }
  bool isHumValid() const {
    return humValid;
  }
  bool isPresValid() const {
    return presValid;
  }

  // Проверка, изменился ли тренд с прошлого обновления
  bool isTempTrendChanged() const {
    return tempTrendChanged;
  }
  bool isHumTrendChanged() const {
    return humTrendChanged;
  }
  bool isPresTrendChanged() const {
    return presTrendChanged;
  }

  // Сброс флагов изменений (вызывать после отрисовки)
  void resetTrendChangedFlags();

  // Принудительное обновление трендов (вызывать раз в N секунд)
  void updateTrends();

  // Отладка (выводит только если были изменения)
  void printDebug();

    // Применение новых порогов и гистерезиса из меню
  void setThresholds(const TrendThresholds& t, const TrendThresholds& h, const TrendThresholds& p,
                     float tempFastOff, float tempSlowOff,
                     float humFastOff, float humSlowOff,
                     float presFastOff, float presSlowOff);

private:
  // Пороги
  TrendThresholds tempTh;
  TrendThresholds humTh;
  TrendThresholds presTh;

  // Буферы истории
  HistoryPoint tempHistory[HISTORY_BUFFER_SIZE];
  HistoryPoint humHistory[HISTORY_BUFFER_SIZE];
  HistoryPoint presHistory[HISTORY_BUFFER_SIZE];

  int tempHistoryIndex;
  int humHistoryIndex;
  int presHistoryIndex;

  // Текущие тренды (кэш)
  int lastTempTrend;
  int lastHumTrend;
  int lastPresTrend;

  float lastTempSpeed;
  float lastHumSpeed;
  float lastPresSpeed;

  bool tempValid;
  bool humValid;
  bool presValid;

  // Флаги изменений
  bool tempTrendChanged;
  bool humTrendChanged;
  bool presTrendChanged;

  // Время последнего обновления трендов
  unsigned long lastTrendUpdate;

  // Внутренние методы
  void initThresholds();
  void pushToHistory(HistoryPoint* buffer, int& index, float value);
  bool linearRegression(const HistoryPoint* points, int numPoints, float* slope, float* offset, float maxDataAgeSec);
  int calculateTrend(float speed, const TrendThresholds& thresholds, int lastTrend);

    // Коэффициенты гистерезиса
  float FAST_OFF_RATIO_TEMP = 0.4f;
  float SLOW_OFF_RATIO_TEMP = 0.3f;
  float FAST_OFF_RATIO_HUM = 0.6f;
  float SLOW_OFF_RATIO_HUM = 0.4f;
  float FAST_OFF_RATIO_PRES = 0.4f;
  float SLOW_OFF_RATIO_PRES = 0.2f;

  const float MAX_DATA_AGE_SEC = 720.0f;  // 10.7 минут (20 точек)
};

#endif