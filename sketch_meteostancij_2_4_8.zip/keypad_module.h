// keypad_module.h
#ifndef KEYPAD_MODULE_H
#define KEYPAD_MODULE_H

#include <Arduino.h>

// ==================== НАСТРОЙКИ ====================
#define KEYPAD_PIN 5  // Аналоговый пин (ADC1)

// ==================== КОНСТАНТЫ ====================
// Используем #ifndef для защиты от повторного определения
#ifndef DEBOUNCE_DELAY
#define DEBOUNCE_DELAY 50  // Задержка антидребезга (мс)
#endif

// Коды кнопок (ваши значения ADC)
#define BTN_UP_MIN 0
#define BTN_UP_MAX 30

#define BTN_RIGHT_MIN 500
#define BTN_RIGHT_MAX 540

#define BTN_LEFT_MIN 1200
#define BTN_LEFT_MAX 1250

#define BTN_DOWN_MIN 1890
#define BTN_DOWN_MAX 1950

#define BTN_OK_MIN 2810
#define BTN_OK_MAX 2890

#define BTN_NONE_MIN 4000
#define BTN_NONE_MAX 4095

// Идентификаторы кнопок
#define KEY_UP 1
#define KEY_RIGHT 2
#define KEY_LEFT 3
#define KEY_DOWN 4
#define KEY_OK 5
#define KEY_NONE 0

// ==================== НАСТРОЙКИ АВТОПОВТОРА ====================
#define REPEAT_DELAY 500     // Задержка перед первым повтором (мс)
#define REPEAT_INTERVAL 200  // Интервал между повторами (мс)

// ==================== ОТЛАДКА ====================
// Раскомментируйте для включения отладки
#define KEYPAD_DEBUG

// ==================== ФУНКЦИИ ====================
int readKeypad();
void waitKeyRelease();
bool isKeyPressed(int expectedKey);
int waitForKey(unsigned long timeout = 5000);
int readKeypadWithRepeat();

// ==================== ОТЛАДОЧНЫЕ ФУНКЦИИ ====================
#ifdef KEYPAD_DEBUG
void printKeypadDebug();
void printKeypadValue();
#else
#define printKeypadDebug()
#define printKeypadValue()
#endif

#endif