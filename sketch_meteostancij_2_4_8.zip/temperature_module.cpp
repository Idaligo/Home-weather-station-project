#include <cstdint>
#include <Arduino.h>
#include <EEPROM.h>
#include <LittleFS.h>
#include "temperature_module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

uint16_t getTempColor(float temp);

const int TEMP_X = 290;
const int TEMP_Y = 92;

TemperatureModule::TemperatureModule(TFT_eSPI& tft_ref)
  : tft(tft_ref),
    spriteTemp(&tft_ref) {
  isFirstDraw = true;
  spritesInitialized = false;
  temperature = 20.0;
  calibrationOffset = 0.0;
  lastTempColor = TFT_WHITE;
}

// ========== МЕТОДЫ КАЛИБРОВКИ ==========
void TemperatureModule::setCalibration(float offset) {
  calibrationOffset = offset;
  forceUpdate();
}

float TemperatureModule::getCalibration() const {
  return calibrationOffset;
}

void TemperatureModule::resetCalibration() {
  calibrationOffset = 0.0;
  forceUpdate();
}

void TemperatureModule::saveCalibration() {
  EEPROM.put(EEPROM_ADDR_TEMP, calibrationOffset);
  EEPROM.commit();
  LOG_I("💾 Калибровка температуры сохранена: %.1f°C", calibrationOffset);
}

void TemperatureModule::loadCalibration() {
  float savedOffset;
  EEPROM.get(EEPROM_ADDR_TEMP, savedOffset);

  // Проверяем, есть ли валидные данные в EEPROM
  if (savedOffset >= -10.0 && savedOffset <= 10.0 && savedOffset != 0.0) {
    calibrationOffset = savedOffset;
    LOG_I("📥 Калибровка температуры загружена: %.1f°C", calibrationOffset);
  } else {
    calibrationOffset = 0.0;
    LOG_I("📥 Калибровка температуры: используется значение по умолчанию (0.0)");
  }
  forceUpdate();
}

// ========== ПОЛУЧЕНИЕ ОТКАЛИБРОВАННОГО ЗНАЧЕНИЯ ==========
float TemperatureModule::getCalibratedTemperature() const {
  return temperature + calibrationOffset;
}

// ========== ОСТАЛЬНЫЕ МЕТОДЫ ==========

void TemperatureModule::initSprite() {
  if (spritesInitialized) return;

  tft.loadFont("cambriai48", LittleFS);
  String maxStr = "-99.9°C";
  int textWidth = tft.textWidth(maxStr);
  tft.unloadFont();

  spriteTemp.setColorDepth(16);
  spriteTemp.createSprite(textWidth + 5, 37);
  spriteTemp.setSwapBytes(true);
  spriteTemp.loadFont("cambriai48");

  spritesInitialized = true;
}

void TemperatureModule::drawTemperature() {
  // Используем ОТКАЛИБРОВАННОЕ значение для отображения
  float displayedTemp = getCalibratedTemperature();

  char tempStr[16];
  snprintf(tempStr, sizeof(tempStr), "%.1f", displayedTemp);
  const char* unitStr = "°C";
  uint16_t newColor = getTempColor(displayedTemp);

  char newStr[24];
  snprintf(newStr, sizeof(newStr), "%s%s", tempStr, unitStr);

  if (!isFirstDraw && strcmp(newStr, lastDrawnTempStr) == 0 && newColor == lastTempColor) {
    return;
  }

  spriteTemp.fillSprite(TFT_BLACK);
  spriteTemp.setTextColor(newColor, TFT_BLACK);
  spriteTemp.setCursor(0, 0);
  spriteTemp.print(tempStr);

  int tempWidth = spriteTemp.textWidth(tempStr);
  spriteTemp.setCursor(tempWidth + 3, 0);
  spriteTemp.print(unitStr);

  spriteTemp.pushSprite(TEMP_X, TEMP_Y);

  strncpy(lastDrawnTempStr, newStr, sizeof(lastDrawnTempStr) - 1);
  lastDrawnTempStr[sizeof(lastDrawnTempStr) - 1] = '\0';
  lastTempColor = newColor;
}

void TemperatureModule::draw() {
  initSprite();
  drawTemperature();
  isFirstDraw = false;
}

void TemperatureModule::begin(float initialTemp) {
  temperature = initialTemp;
  isFirstDraw = true;
  lastDrawnTempStr[0] = '\0';
  lastTempColor = TFT_WHITE;
}

void TemperatureModule::update(float newTemp) {
  temperature = newTemp;
}

void TemperatureModule::forceUpdate() {
  isFirstDraw = true;
  lastDrawnTempStr[0] = '\0';
  lastTempColor = TFT_WHITE;
}

float TemperatureModule::getTemperature() {
  // Возвращаем ОТКАЛИБРОВАННОЕ значение для прогноза и трендов
  return getCalibratedTemperature();
}