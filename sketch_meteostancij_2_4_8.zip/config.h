// config.h
#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "logger.h"

// ===================================================================
// ПИНЫ
// ===================================================================

// Пины для дисплея (HSPI)
#define TFT_CS 10
#define TFT_DC 9
#define TFT_RST 8
#define TFT_BL 7
#define LED_PWM_PIN TFT_BL

// Пины для nRF24L01 (HSPI — отдельная шина)
#define NRF_CE 15
#define NRF_CSN 14
#define NRF_SCK 16
#define NRF_MOSI 17
#define NRF_MISO 18

// Пины для индикации
#define LED_PIN 38
#define LIGHT_SENSOR_PIN 4

// ===================================================================
// ТАЙМИНГИ / ИНТЕРВАЛЫ
// ===================================================================
const unsigned long DISPLAY_UPDATE_INTERVAL = 5000;
const unsigned long SERIAL_PRINT_INTERVAL = 10000;
const unsigned long AUTO_UPDATE_INTERVAL = 2000;
const unsigned long INDICATOR_HIDE_DELAY = 5000;
const unsigned long STEP_DELAY = 500;
const unsigned long REPEAT_INIT_DELAY = 300;
const unsigned long PACKET_TIMEOUT = 500;
const unsigned long SIGNAL_TIMEOUT = 180000;
const unsigned long FADE_INTERVAL = 15;
const unsigned long LOOP_INTERVAL = 100;

// ===================================================================
// ПОДСВЕТКА
// ===================================================================
#define LUX_BUFFER_SIZE 10
#define BRIGHTNESS_EEPROM_ADDR 0

const float LUX_DARK = 1;
const float LUX_TWILIGHT = 30;
const float LUX_ROOM = 100;
const float LUX_BRIGHT = 255;

const int BRIGHT_DARK = 5;
const int BRIGHT_TWILIGHT = 100;
const int BRIGHT_ROOM = 200;
const int BRIGHT_BRIGHT = 255;

// ===================================================================
// ФИЗИКА / ПОГОДА
// ===================================================================
const float GRAVITY = 9.80665;
const float M_AIR = 0.0289644;
const float GAS_CONSTANT = 8.314462618;
const int SEA_LEVEL_HEIGHT = 0;

const float DEFAULT_TEMP = 20.0f;
const float DEFAULT_HUM = 50.0f;
const float DEFAULT_PRES = 760.0f;

// ===================================================================
// ИНДИКАТОР / ПРЕДУПРЕЖДЕНИЕ / БАТАРЕЯ
// ===================================================================
const int INDICATOR_WIDTH = 5;
const int INDICATOR_COLOR = TFT_YELLOW;
const int INDICATOR_X = 1;
const int INDICATOR_Y = 195;
const int INDICATOR_HEIGHT = 120;

const int WARNING_X = 394;
const int WARNING_Y = 1;
const int WARNING_WIDTH = 37;
const int WARNING_HEIGHT = 20;

const int BATTERY_X = 438;
const int BATTERY_Y = 1;

// ===================================================================
// ФИЛЬТРАЦИЯ
// ===================================================================
#define BUFFER_SIZE 10

// ===================================================================
// ПРОЧЕЕ
// ===================================================================
#define ICON_SIZE 104

#endif  // CONFIG_H