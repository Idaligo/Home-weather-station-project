#ifndef BME280_MODULE_H
#define BME280_MODULE_H

#include <TFT_eSPI.h>
#include <Adafruit_BME280.h>

class BME280Module {
public:
  BME280Module(Adafruit_BME280& bmeSensor, TFT_eSPI& tft);

  void begin();
  void update();
  void draw();
  void forceUpdate();

  float getTemperature();  // Возвращает откалиброванное значение
  float getHumidity();     // Возвращает откалиброванное значение

  // ========== МЕТОДЫ КАЛИБРОВКИ ==========
  void setTempCalibration(float offset);
  float getTempCalibration() const;
  void setHumCalibration(float offset);
  float getHumCalibration() const;
  void resetTempCalibration();
  void resetHumCalibration();
  void resetAllCalibrations();

  void saveTempCalibration();  // Сохранить калибровку температуры в EEPROM
  void loadTempCalibration();  // Загрузить калибровку температуры из EEPROM
  void saveHumCalibration();   // Сохранить калибровку влажности в EEPROM
  void loadHumCalibration();   // Загрузить калибровку влажности из EEPROM
  void saveAllCalibrations();  // Сохранить обе калибровки
  void loadAllCalibrations();  // Загрузить обе калибровки

  bool isNewDataAvailable;

private:
  Adafruit_BME280& bme;
  TFT_eSPI& tft;

  float temperature;      // Сырое значение с датчика
  float humidity;         // Сырое значение с датчика
  float tempCalibration;  // Смещение калибровки температуры
  float humCalibration;   // Смещение калибровки влажности

  // Кэширование
  char lastDrawnTempStr[24];  // было String
  char lastDrawnHumStr[24];   // было String
  uint16_t lastTempColor;
  uint16_t lastHumColor;
  bool isFirstDraw;

  // Таймер
  unsigned long lastDrawTime;
  const unsigned long DRAW_INTERVAL = 60000;

  // ========== СПРАЙТЫ ==========
  TFT_eSprite spriteTemp;  // Цифры + "°C"
  TFT_eSprite spriteHum;   // Цифры + "%"
  bool spritesInitialized;

  // Фильтр
  static const int FILTER_SIZE = 5;
  float tempBuffer[FILTER_SIZE];
  float humBuffer[FILTER_SIZE];
  int filterIndex;

  // Константы позиционирования
  const int TEMP_X = 10;
  const int TEMP_Y = 92;
  const int HUM_X = 10;
  const int HUM_Y = 164;

  // Адреса в EEPROM
  const int EEPROM_ADDR_TEMP_CAL = 40;  // Для калибровки температуры BME280
  const int EEPROM_ADDR_HUM_CAL = 41;   // Для калибровки влажности BME280 (следующий адрес)

  void initSprites();
  void drawTemperature();
  void drawHumidity();
  float getCalibratedTemperature() const;
  float getCalibratedHumidity() const;

  void addTempSample(float sample);
  void addHumSample(float sample);
  float calculateTempAverage();
  float calculateHumAverage();
};

#endif