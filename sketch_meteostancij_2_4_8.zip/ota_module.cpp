#include "ota_module.h"
#include "common.h"
#include "keypad_module.h"
#include "menu_module.h"
#include "logger.h"

#include <WiFi.h>
#include <ArduinoOTA.h>
#include <ESPmDNS.h>
#include <TFT_eSPI.h>

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

extern TFT_eSPI tft;

static bool otaInitialized = false;
static bool otaInProgress = false;
static unsigned long otaStartTime = 0;
static unsigned long lastKeyCheck = 0;

// ==================== OTA BEGIN ====================
void otaBegin() {
  LOG_I("═══════════════════════════════════════");
  LOG_I("📡 OTA: ВХОД В РЕЖИМ");

  otaInitialized = false;
  otaInProgress = false;
  otaStartTime = millis();

  // ===== ЭКРАН ЗАГРУЗКИ =====
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("OTA режим");
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 60);
  tft.print("Подключение к Wi-Fi...");

  // ===== ВКЛЮЧАЕМ WI-FI =====
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin();

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt) < 15000) {
    delay(250);
    if (g_logLevel >= LOG_LEVEL_INFO) LOG_SERIAL.print(".");
  }
  if (g_logLevel >= LOG_LEVEL_INFO) LOG_SERIAL.println();

  if (WiFi.status() != WL_CONNECTED) {
    LOG_E("❌ OTA: не удалось подключиться");
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Ошибка Wi-Fi");
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setCursor(10, 60);
    tft.print("OK — выход");
    return;
  }

  // ===== IP =====
  IPAddress ip = WiFi.localIP();
  LOG_I("✅ OTA: IP = %s", ip.toString().c_str());

  // ===== ЭКРАН OTA =====
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("OTA режим");

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 60);
  tft.print("IP:");
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setTextSize(3);
  tft.setCursor(10, 90);
  tft.print(ip.toString());

  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 140);
  tft.print("Host:");
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setCursor(10, 170);
  tft.print("meteostancija");

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(10, 210);
  tft.print("В Arduino IDE:");
  tft.setCursor(10, 230);
  tft.print("Инструменты -> Порт ->");
  tft.setCursor(10, 250);
  tft.print("meteostancija (сетевой)");

  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 280);
  tft.print("OK — выход");

  // ===== mDNS =====
  MDNS.begin("meteostancija");
  MDNS.addService("arduino", "tcp", 3232);

  // ===== OTA НАСТРОЙКИ =====
  ArduinoOTA.setHostname("meteostancija");
  ArduinoOTA.setPassword("meteo123");  // ← поменяй при желании

  ArduinoOTA.onStart([]() {
    otaInProgress = true;
    LOG_I("🔧 OTA: начало");
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Обновление...");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    static unsigned int lastPct = 0;
    unsigned int pct = (total > 0) ? (progress * 100 / total) : 0;
    if (pct != lastPct) {
      lastPct = pct;
      tft.setTextSize(4);
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      tft.setCursor(10, 60);
      tft.printf("%u%%   ", pct);
    }
  });

  ArduinoOTA.onEnd([]() {
    otaInProgress = false;
    LOG_I("");
    LOG_I("✅ OTA: завершено");
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 120);
    tft.print("Готово!");
  });

  ArduinoOTA.onError([](ota_error_t error) {
    otaInProgress = false;
    LOG_E("❌ OTA error[%u]", error);
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 120);
    tft.print("Ошибка!");
  });

  ArduinoOTA.begin();
  otaInitialized = true;
  LOG_I("📡 OTA: готов (OK — выход)");
}

// ==================== OTA LOOP ====================
void otaLoop() {
  // Первый вызов — инициализация
  if (!otaInitialized) {
    otaBegin();
    return;
  }

  // Если Wi-Fi не подключился — ждём OK
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastKeyCheck2 = 0;
    if (millis() - lastKeyCheck2 > 200) {
      lastKeyCheck2 = millis();
      if (readKeypad() == KEY_OK) {
        otaEnd();
      }
    }
    return;
  }

  // Автовыход через 10 минут
  if (!otaInProgress && (millis() - otaStartTime > 600000)) {
    LOG_I("⏱️ OTA: таймаут");
    otaEnd();
    return;
  }

  // Обработка OTA
  ArduinoOTA.handle();

  // Кнопки
  if (millis() - lastKeyCheck > 200) {
    lastKeyCheck = millis();
    int key = readKeypad();

    if (key == KEY_OK) {
      if (!otaInProgress) {
        LOG_I("⏹️ OTA: выход по OK");
        otaEnd();
      } else {
        // Длинное нажатие — принудительный выход
        unsigned long pressStart = millis();
        while (readKeypad() == KEY_OK) {
          if (millis() - pressStart > 3000) {
            LOG_I("⏹️ OTA: ПРИНУДИТЕЛЬНЫЙ выход");
            otaEnd();
            return;
          }
          ArduinoOTA.handle();
          delay(10);
        }
      }
    }
  }

  delay(10);
}

// ==================== OTA END ====================
void otaEnd() {
  LOG_I("📴 OTA: выход из режима");

  ArduinoOTA.end();
  MDNS.end();

  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);

  otaInitialized = false;
  otaInProgress = false;

  currentMode = MODE_MAIN;
  needFullRedraw = true;

  // ===== ПРИНУДИТЕЛЬНАЯ ПЕРЕРИСОВКА ГЛАВНОГО ЭКРАНА =====
  tft.fillScreen(TFT_BLACK);
  redrawMainScreen();
}

// ==================== OTA IS IN PROGRESS ====================
bool otaIsInProgress() {
  return otaInProgress;
}