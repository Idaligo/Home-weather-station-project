#ifndef TEMPERATURE_MODULE_H
#define TEMPERATURE_MODULE_H

#include <TFT_eSPI.h>

class TemperatureModule {
public:
  TemperatureModule(TFT_eSPI& tft);
  void begin(float initialTemp = 20.0);
  void update(float newTemp);
  void draw();
  void forceUpdate();
  float getTemperature();  // Возвращает откалиброванное значение

  // ========== МЕТОДЫ КАЛИБРОВКИ ==========
  void setCalibration(float offset);
  float getCalibration() const;
  void resetCalibration();
  void saveCalibration();  // Сохранить калибровку в EEPROM
  void loadCalibration();  // Загрузить калибровку из EEPROM

private:
  TFT_eSPI& tft;
  float temperature;        // Сырое значение с датчика
  float calibrationOffset;  // Смещение калибровки

  char lastDrawnTempStr[24];  // было String
  uint16_t lastTempColor;
  bool isFirstDraw;

  TFT_eSprite spriteTemp;
  bool spritesInitialized;

  void initSprite();
  void drawTemperature();
  float getCalibratedTemperature() const;  // Вспомогательный метод

  const int TEMP_X = 290;
  const int TEMP_Y = 92;

  // ========== АДРЕС В EEPROM ==========
  const int EEPROM_ADDR_TEMP = 10;  // Адрес 10 (чтобы не конфликтовать с яркостью на адресе 0)
};

#endif  // TEMPERATURE_MODULE_H