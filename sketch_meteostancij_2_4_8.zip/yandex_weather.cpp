// yandex_weather.cpp
#include "yandex_weather.h"
#include "common.h"
#include "weather_forecast.h"
#include "logger.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
//#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "esp_heap_caps.h"

// ===== Кастомный аллокатор для PSRAM =====
struct SpiRamAllocator : ArduinoJson::Allocator {
  void* allocate(size_t size) override {
    return heap_caps_malloc(size, MALLOC_CAP_SPIRAM);
  }
  void deallocate(void* pointer) override {
    heap_caps_free(pointer);
  }
  void* reallocate(void* ptr, size_t new_size) override {
    return heap_caps_realloc(ptr, new_size, MALLOC_CAP_SPIRAM);
  }
};

// Глобальный аллокатор
static SpiRamAllocator psramAllocator;

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ===================================================================
// РУЧНОЙ HTTP ЧЕРЕЗ WiFiClientSecure (обходит баг HTTPClient в Core 3.x)
// ===================================================================

bool fetchYandexDataManual(float lat, float lon, const char* apiKey,
                           bool includeHours, uint8_t yandexFormat,
                           YandexData& data) {
  // ===== 1. ПРОВЕРКИ =====
  if (WiFi.status() != WL_CONNECTED) {
    LOG_E("❌ Wi-Fi не подключён!");
    snprintf(lastSession.error, sizeof(lastSession.error), "WiFi not connected");
    return false;
  }
  if (apiKey == nullptr || strlen(apiKey) == 0) {
    LOG_E("❌ API-ключ Яндекса не задан!");
    snprintf(lastSession.error, sizeof(lastSession.error), "No API key");
    return false;
  }

  // ===== 2. ФОРМИРУЕМ URL =====
  String url = "/v2/forecast?lat=" + String(lat, 6) + "&lon=" + String(lon, 6) + "&limit=1";
  if (includeHours) {
    url += "&hours=true";
  } else {
    url += "&hours=false";
  }
  url += "&extra=true";

  LOG_I("📤 Запрос (ручной) (%s): %s",
        (yandexFormat == 0) ? "Часы" : "Сутки", url.c_str());

  // ===== 3. ПОДКЛЮЧЕНИЕ =====
  WiFiClientSecure client;
  client.setInsecure();
  client.setTimeout(30);

  LOG_I("🔍 Свободно RAM: %d байт", ESP.getFreeHeap());

  if (!client.connect("api.weather.yandex.ru", 443)) {
    LOG_E("❌ Не удалось подключиться к api.weather.yandex.ru:443");
    snprintf(lastSession.error, sizeof(lastSession.error), "Connect failed");
    return false;
  }
    LOG_I("🔗 TCP-соединение установлено");

  // ===== 4. ОТПРАВЛЯЕМ HTTP-ЗАПРОС =====
  client.print("GET ");
  client.print(url);
  client.println(" HTTP/1.1");
  client.println("Host: api.weather.yandex.ru");
  client.print("X-Yandex-Weather-Key: ");
  client.println(apiKey);
  client.println("Accept: application/json");
  client.println("Connection: close");
  client.println("User-Agent: ESP32-MeteoStation/1.0");
  client.println();

  // ===== 5. ЧИТАЕМ ЗАГОЛОВКИ ОТВЕТА =====
  unsigned long startWait = millis();
  while (!client.available() && (millis() - startWait) < 10000) {
    delay(10);
  }
  if (!client.available()) {
    LOG_E("❌ Таймаут ожидания заголовков");
    snprintf(lastSession.error, sizeof(lastSession.error), "Headers timeout");
    client.stop();
    return false;
  }

  String statusLine = client.readStringUntil('\n');
  statusLine.trim();
    LOG_I("📥 Статус: %s", statusLine.c_str());

  // ===== ПАРСИМ HTTP-КОД =====
  int code = 0;
  if (statusLine.indexOf("200") != -1) {
    code = 200;
  } else {
    int sp1 = statusLine.indexOf(' ');
    if (sp1 > 0) {
      code = statusLine.substring(sp1 + 1, sp1 + 4).toInt();
    }
  }
  lastSession.httpCode = code;

  if (statusLine.indexOf("200") == -1) {
    LOG_E("❌ HTTP-код не 200 (%d)", code);
    while (client.available()) {
      String line = client.readStringUntil('\n');
      if (line == "\r" || line.length() == 0) break;
    }
    String errBody = client.readString();
        LOG_E("📄 Ответ: %.200s", errBody.c_str());
    lastSession.bytesRead = errBody.length();
    snprintf(lastSession.error, sizeof(lastSession.error), "HTTP %d", code);
    client.stop();
    return false;
  }

  int contentLength = -1;
  while (client.available()) {
    String line = client.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) break;

    if (line.startsWith("Content-Length:")) {
      contentLength = line.substring(15).toInt();
    }
  }

    LOG_I("📦 Content-Length: %d", contentLength);

  // ===== ЖДЁМ ТЕЛО =====
  unsigned long startBody = millis();
  while (!client.available() && (millis() - startBody) < 10000) {
    delay(10);
  }
  if (!client.available()) {
        LOG_E("❌ Таймаут ожидания тела");
    snprintf(lastSession.error, sizeof(lastSession.error), "Body timeout");
    client.stop();
    return false;
  }

  // ===== ЧИТАЕМ ТЕЛО (CHUNKED) =====
  String payload = "";
  unsigned long lastData = millis();

  while (client.connected() || client.available()) {
    if (client.available()) {
      String chunkSizeLine = client.readStringUntil('\n');
      chunkSizeLine.trim();
      if (chunkSizeLine.length() == 0) continue;

      long chunkSize = strtol(chunkSizeLine.c_str(), NULL, 16);
      if (chunkSize == 0) break;

      long bytesRead = 0;
      while (bytesRead < chunkSize && (client.connected() || client.available())) {
        if (client.available()) {
          payload += (char)client.read();
          bytesRead++;
          lastData = millis();
        } else {
          if (millis() - lastData > 5000) break;
          delay(1);
        }
      }
      client.readStringUntil('\n');
    } else {
      if (millis() - lastData > 5000) break;
      delay(1);
    }
  }

  client.stop();

  LOG_I("📦 Прочитано: %d байт", payload.length());
  lastSession.bytesRead = payload.length();

  if (payload.length() < 100) {
    LOG_W("⚠️ Ответ пустой или слишком короткий!");
    LOG_W("📄 Содержимое: %.200s", payload.c_str());
    snprintf(lastSession.error, sizeof(lastSession.error), "Short payload: %d", payload.length());
    return false;
  }

  // ===== ПАРСИМ JSON =====
  JsonDocument doc(&psramAllocator);
  DeserializationError error = deserializeJson(doc, payload);

  if (error) {
    LOG_E("❌ Ошибка парсинга JSON: %s", error.f_str());
    LOG_E("📄 Первые 200 байт: %.200s", payload.c_str());
    LOG_E("📄 Последние 200 байт: %.200s",
          payload.substring(payload.length() > 200 ? payload.length() - 200 : 0).c_str());
    snprintf(lastSession.error, sizeof(lastSession.error), "JSON: %s", error.c_str());
    return false;
  }

  LOG_I("✅ JSON распарсен");

  // ===== 7. ИЗВЛЕКАЕМ FACT =====
  JsonObject fact = doc["fact"];
  if (fact.isNull()) {
    LOG_E("❌ Нет объекта 'fact'");
    snprintf(lastSession.error, sizeof(lastSession.error), "No 'fact' object");
    return false;
  }

  data.currentTemp = fact["temp"] | 0;
  data.currentHumidity = fact["humidity"] | 0;
  data.currentPressure = fact["pressure_mm"] | 0;

  const char* condStr = fact["condition"] | "";
  strncpy(data.currentCondition, condStr, sizeof(data.currentCondition) - 1);
  data.currentCondition[sizeof(data.currentCondition) - 1] = '\0';

  const char* phenomStr = fact["phenom_condition"] | "";
  strncpy(data.currentPhenom, phenomStr, sizeof(data.currentPhenom) - 1);
  data.currentPhenom[sizeof(data.currentPhenom) - 1] = '\0';

  const char* daytime = fact["daytime"] | "d";
  data.isDaytime = (strcmp(daytime, "d") == 0);

  // ===== 8. ПОЧАСОВОЙ ПРОГНОЗ =====
  JsonArray forecasts = doc["forecasts"];
  if (forecasts.isNull() || forecasts.size() == 0) {
    LOG_E("❌ Нет массива 'forecasts'");
    snprintf(lastSession.error, sizeof(lastSession.error), "No 'forecasts' array");
    return false;
  }

  if (includeHours) {
    JsonArray hours = forecasts[0]["hours"];
    if (!hours.isNull()) {
      int n = min((int)hours.size(), 24);
      for (int i = 0; i < n; i++) {
        JsonObject h = hours[i];
        data.forecastTemp[i] = h["temp"] | 0;
        data.forecastHumidity[i] = h["humidity"] | 0;

        const char* condStr = h["condition"] | "";
        strncpy(data.forecastCondition[i], condStr, sizeof(data.forecastCondition[i]) - 1);
        data.forecastCondition[i][sizeof(data.forecastCondition[i]) - 1] = '\0';

        data.forecastPrecProb[i] = h["prec_prob"] | 0;
        const char* icon = h["icon"] | "";
        data.forecastIsDay[i] = (strstr(icon, "_n") == nullptr);
      }
      for (int i = n; i < 24; i++) {
        data.forecastTemp[i] = data.forecastTemp[n - 1];
        data.forecastHumidity[i] = data.forecastHumidity[n - 1];
        strncpy(data.forecastCondition[i], data.forecastCondition[n - 1],
                sizeof(data.forecastCondition[i]) - 1);
        data.forecastCondition[i][sizeof(data.forecastCondition[i]) - 1] = '\0';
        data.forecastPrecProb[i] = data.forecastPrecProb[n - 1];
        data.forecastIsDay[i] = data.forecastIsDay[n - 1];
      }
      LOG_I("📊 Загружено %d часов", n);
    }
  }

  // ===== 9. ЧАСТИ СУТОК =====
  JsonObject parts = forecasts[0]["parts"];
  if (!parts.isNull()) {
    const char* partNames[4] = { "night", "morning", "day", "evening" };

    for (int i = 0; i < 4; i++) {
      JsonObject p = parts[partNames[i]];
      if (!p.isNull()) {
        data.partTemp[i] = p["temp_avg"] | 0;
        data.partHumidity[i] = p["humidity"] | 0;

        const char* partCondStr = p["condition"] | "";
        strncpy(data.partCondition[i], partCondStr, sizeof(data.partCondition[i]) - 1);
        data.partCondition[i][sizeof(data.partCondition[i]) - 1] = '\0';

        uint8_t fallbackProb = p["prec_prob"] | 0;

        const int partHours[4][8] = {
          { 23, 0, 1, 2, 3, 4, 5, -1 },
          { 6, 7, 8, 9, 10, 11, -1, -1 },
          { 12, 13, 14, 15, 16, 17, -1, -1 },
          { 18, 19, 20, 21, -1, -1, -1, -1 }
        };

        int sum = 0;
        int count = 0;
        for (int j = 0; j < 8; j++) {
          int h = partHours[i][j];
          if (h < 0) break;
          sum += data.forecastPrecProb[h];
          count++;
        }

        data.partPrecProb[i] = (count > 0) ? (sum / count) : fallbackProb;

        const char* src = p["_source"] | "";
        const char* comma = strchr(src, ',');
        if (comma) {
          data.partStartHour[i] = atoi(src);
        } else {
          data.partStartHour[i] = 0;
        }
      }
    }
  }

  data.isValid = true;
  data.lastUpdate = millis();

  // ===== 10. ВЫВОД =====
  LOG_I("");
  LOG_I("✅ Данные Яндекса получены (ручной HTTP)!");
  LOG_I("📍 СЕЙЧАС: %.0f°C, %.0f%%, %s",
        data.currentTemp, data.currentHumidity, data.currentCondition);

  if (data.currentPhenom[0] != '\0') {
    LOG_I("   🌫️ Явление: %s", data.currentPhenom);
  }

  if (includeHours) {
    LOG_I("🔮 ПРОГНОЗ (часы 00:00–05:00):");
    for (int i = 0; i < 6; i++) {
      LOG_I("  %02d:00: %s, %.0f°C, %.0f%%, осадки: %d%%",
            i, data.forecastCondition[i], data.forecastTemp[i],
            data.forecastHumidity[i], data.forecastPrecProb[i]);
    }
  }

  LOG_I("🌓 ЧАСТИ СУТОК:");
  const char* partNamesRu[4] = { "Ночь", "Утро", "День", "Вечер" };
  for (int i = 0; i < 4; i++) {
    LOG_I("  %s (с %d:00): %s, %.0f°C, %.0f%%, осадки: %d%%",
          partNamesRu[i], data.partStartHour[i],
          data.partCondition[i], data.partTemp[i],
          data.partHumidity[i], data.partPrecProb[i]);
  }

  return true;
}

// ===================================================================
// ТЕКСТОВОЕ ОПИСАНИЕ ПО КОДУ ЯНДЕКСА
// ===================================================================
const char* getYandexDescription(const char* condition) {
  if (condition == nullptr) return "Неизвестно";

  // ===== Ясно =====
  if (strcmp(condition, "clear") == 0) return "Ясно";

  // ===== Облачность =====
  if (strcmp(condition, "partly-cloudy") == 0) return "Малооблачно";
  if (strcmp(condition, "cloudy") == 0) return "Облачно";
  if (strcmp(condition, "overcast") == 0) return "Пасмурно";

  // ===== Дождь =====
  if (strcmp(condition, "drizzle") == 0) return "Морось";
  if (strcmp(condition, "light-rain") == 0) return "Небольшой дождь";
  if (strcmp(condition, "rain") == 0) return "Дождь";
  if (strcmp(condition, "moderate-rain") == 0) return "Умеренный дождь";
  if (strcmp(condition, "heavy-rain") == 0) return "Сильный дождь";
  if (strcmp(condition, "continuous-heavy-rain") == 0) return "Сильный дождь";
  if (strcmp(condition, "showers") == 0) return "Ливень";

  // ===== Снег =====
  if (strcmp(condition, "wet-snow") == 0) return "Дождь со снегом";
  if (strcmp(condition, "light-snow") == 0) return "Небольшой снег";
  if (strcmp(condition, "snow") == 0) return "Снег";
  if (strcmp(condition, "snow-showers") == 0) return "Снегопад";

  // ===== Гроза / Град =====
  if (strcmp(condition, "hail") == 0) return "Град";
  if (strcmp(condition, "thunderstorm") == 0) return "Гроза";
  if (strcmp(condition, "thunderstorm-with-rain") == 0) return "Дождь с грозой";
  if (strcmp(condition, "thunderstorm-with-hail") == 0) return "Гроза с градом";

  // ===== Туман =====
  if (strcmp(condition, "fog") == 0) return "Туман";
  if (strcmp(condition, "mist") == 0) return "Дымка";

  return "Неизвестно";
}

// ===================================================================
// МАППИНГ КОДА ЯНДЕКСА ВО ВНУТРЕННИЙ КОД
// ===================================================================
int mapYandexToWeatherCode(const char* condition) {
  if (condition == nullptr) return WEATHER_UNKNOWN;

  if (strcmp(condition, "clear") == 0) return WEATHER_CLEAR;
  if (strcmp(condition, "partly-cloudy") == 0) return WEATHER_MOSTLY_CLEAR;
  if (strcmp(condition, "cloudy") == 0) return WEATHER_PARTLY_CLOUDY;
  if (strcmp(condition, "overcast") == 0) return WEATHER_CLOUDY;
  if (strcmp(condition, "drizzle") == 0) return WEATHER_DRIZZLE;
  if (strcmp(condition, "light-rain") == 0) return WEATHER_RAIN;
  if (strcmp(condition, "rain") == 0) return WEATHER_RAIN;
  if (strcmp(condition, "moderate-rain") == 0) return WEATHER_RAIN;
  if (strcmp(condition, "heavy-rain") == 0) return WEATHER_HEAVY_RAIN;
  if (strcmp(condition, "continuous-heavy-rain") == 0) return WEATHER_HEAVY_RAIN;
  if (strcmp(condition, "showers") == 0) return WEATHER_HEAVY_RAIN;
  if (strcmp(condition, "wet-snow") == 0) return WEATHER_SLEET;
  if (strcmp(condition, "light-snow") == 0) return WEATHER_LIGHT_SNOW;
  if (strcmp(condition, "snow") == 0) return WEATHER_SNOW;
  if (strcmp(condition, "snow-showers") == 0) return WEATHER_SNOW_SHOWERS;
  if (strcmp(condition, "hail") == 0) return WEATHER_HAIL;
  if (strcmp(condition, "thunderstorm") == 0) return WEATHER_THUNDER;
  if (strcmp(condition, "thunderstorm-with-rain") == 0) return WEATHER_THUNDER;
  if (strcmp(condition, "thunderstorm-with-hail") == 0) return WEATHER_THUNDER;
  if (strcmp(condition, "fog") == 0) return WEATHER_FOG;
  if (strcmp(condition, "mist") == 0) return WEATHER_FOG;
  return WEATHER_UNKNOWN;
}