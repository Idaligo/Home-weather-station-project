#include "weather_forecast.h"
#include "weather_icons.h"
#include "rtc_module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ===== ВНЕШНЯЯ ССЫЛКА НА RTC =====
extern RTCModule rtcClock;

// ==================== ОПРЕДЕЛЕНИЕ НОЧИ ====================
bool WeatherForecast::isNightTime() {
  const DateTime& now = rtcClock.getTime();  // ← ссылка
  int hour = now.hour();
  return (hour >= 22 || hour < 6);
}

int WeatherForecast::getSeason() {
  const DateTime& now = rtcClock.getTime();  // ← ссылка
  int month = now.month();

  if (month >= 3 && month <= 5) return 1;
  if (month >= 6 && month <= 8) return 2;
  if (month >= 9 && month <= 11) return 3;
  return 0;
}

// ==================== ТОЧКА РОСЫ ====================
float WeatherForecast::getDewPoint(float temp, float humidity) {
  // Формула Magnus
  float a = 17.27;
  float b = 237.7;
  float alpha = (a * temp) / (b + temp) + log(humidity / 100.0);
  return (b * alpha) / (a - alpha);
}
// ==================== КОНСТРУКТОР ====================
WeatherForecast::WeatherForecast() {
  currentIndex = 0;
  recordCount = 0;
  lastStableForecast = WEATHER_UNKNOWN;
  forecastStableSince = 0;
  memset(records, 0, sizeof(records));
  LOG_I("WeatherForecast initialized");
}

// ==================== ГИБРИДНЫЙ ПРОГНОЗ (ФИНАЛЬНАЯ ВЕРСИЯ) ====================
int WeatherForecast::getHybridForecast() {
  if (recordCount < 12) return WEATHER_UNKNOWN;

  // ===== 1. ПОЛУЧАЕМ ДАННЫЕ =====
  WeatherRecord last = getRecord(recordCount - 1);
  float pressure = last.pressure;
  float humidity = last.humidity;
  float temp = last.temperature;

  float pressureTrend1h = getPressureTrend(1);
  float pressureTrend3h = getPressureTrend(3);
  float humidityTrend1h = getHumidityTrend(1);  // ← НОВЫЙ МЕТОД

  int season = getSeason();

  // ===== 2. СЕЗОННЫЕ КОРРЕКТИРОВКИ =====
  // Лето (6-8): пороги ниже, осень (9-11): пороги выше
  int rainThreshold;
  int cloudyThreshold;
  int clearThreshold;

  if (season == 2) {  // Лето
    rainThreshold = 70;
    cloudyThreshold = 60;
    clearThreshold = 50;
  } else if (season == 3) {  // Осень
    rainThreshold = 75;
    cloudyThreshold = 65;
    clearThreshold = 55;
  } else {  // Зима/Весна
    rainThreshold = 75;
    cloudyThreshold = 65;
    clearThreshold = 50;
  }

  // ===== 3. ОПРЕДЕЛЯЕМ ПОГОДУ (ПО ПРИОРИТЕТУ) =====

  // --- 3.1. ЭКСТРЕМАЛЬНЫЕ СЛУЧАИ ---
  if (temp < 2 && humidity > 80 && pressure < 754) {
    return WEATHER_SNOW;
  }
  if (season == 2 && temp > 25 && humidity > 75 && pressureTrend1h < -0.5) {
    return WEATHER_THUNDER;
  }
  if (humidity > 80 && pressure < 748 && pressureTrend1h < -0.8) {
    return WEATHER_THUNDER;
  }

  // --- 3.2. СИЛЬНЫЙ ДОЖДЬ (влажность > 90%) ---
  // ТОЛЬКО если влажность растёт или стабильна
  if (humidity > 90 && humidityTrend1h >= -0.1) {
    return WEATHER_RAIN;
  }

  // --- 3.3. ДОЖДЬ ---
  // Основной порог с учётом сезона
  if (humidity > rainThreshold && pressure < 755) {
    return WEATHER_RAIN;
  }
  // Падение давления + влажность
  if (humidity > 70 && pressureTrend1h < -0.2) {
    return WEATHER_RAIN;
  }

  // --- 3.4. ДОЖДЬ ЗАКАНЧИВАЕТСЯ (влажность падает) ---
  if (humidity > 75 && humidityTrend1h < -0.3) {
    return WEATHER_CLOUDY;
  }

  // --- 3.5. ТУМАН ---
  if (humidity > 88 && abs(pressureTrend1h) < 0.2 && temp < 15) {
    return WEATHER_FOG;
  }
  if (humidity > 85 && temp < -3 && abs(pressureTrend1h) < 0.2) {
    return WEATHER_FOG;
  }

  // --- 3.6. ОБЛАЧНОСТЬ ---
  if (humidity > cloudyThreshold && pressure < 755) {
    return WEATHER_CLOUDY;
  }

  // --- 3.7. ПЕРЕМЕННАЯ ОБЛАЧНОСТЬ ---
  if (humidity > clearThreshold && pressure > 752 && pressure < 757) {
    return WEATHER_PARTLY_CLOUDY;
  }
  if (humidity > 55 && pressure > 753 && pressure < 759) {
    return WEATHER_PARTLY_CLOUDY;
  }

  // --- 3.8. ЯСНО ---
  if (humidity < clearThreshold && pressure > 753) {
    return WEATHER_CLEAR;
  }
  if (humidity < 55 && pressure > 756) {
    return WEATHER_CLEAR;
  }
  if (pressure > 760) {
    return WEATHER_CLEAR;
  }

  return WEATHER_PARTLY_CLOUDY;
}

// ==================== ПРЕДУПРЕЖДЕНИЯ ====================
const char* WeatherForecast::getWeatherWarning() {
  if (recordCount < 12) {
    _warningBuf[0] = '\0';
    return _warningBuf;
  }

  WeatherRecord last = getRecord(recordCount - 1);
  float temp = last.temperature;
  float humidity = last.humidity;
  float pressureTrend = getPressureTrend(3);

  _warningBuf[0] = '\0';

  // Гололёд (температура около нуля, высокая влажность, падение давления)
  if (temp > -3 && temp < 2 && humidity > 70 && pressureTrend < -0.2) {
    strcpy(_warningBuf, "ГОЛОЛЁД!");
  }
  // Сильный мороз
  else if (temp < -15) {
    strcpy(_warningBuf, "Сильный мороз!");
  }
  // Сильная жара
  else if (temp >= 31.6) {
    strcpy(_warningBuf, "Сильная жара!");
  }
  // Душно (высокая влажность + жара)
  else if (temp > 26.6 && humidity > 70) {
    strcpy(_warningBuf, "Душно");
  }
  // Сильный дождь (влажность > 90%)
  else if (humidity > 90 && temp > 5) {
    strcpy(_warningBuf, "Сильный дождь!");
  }

  return _warningBuf;
}
// ==================== ДОБАВЛЕНИЕ ИЗМЕРЕНИЯ ====================
void WeatherForecast::addMeasurement(float temp, float hum, float pressure) {
  records[currentIndex].timestamp = millis();
  records[currentIndex].temperature = temp;
  records[currentIndex].humidity = hum;
  records[currentIndex].pressure = pressure;

  currentIndex = (currentIndex + 1) % HISTORY_SIZE;
  if (recordCount < HISTORY_SIZE) {
    recordCount++;
  }

  // ========== ВЫВОД ДИАГНОСТИКИ КАЖДЫЕ 12 ЗАПИСЕЙ ==========
  static int lastPrintedRecordCount = 0;

  // Каждые 12 новых записей (12, 24, 36, 48...)
  if (recordCount >= 12 && (recordCount - lastPrintedRecordCount >= 12)) {
    printHistory();
    lastPrintedRecordCount = recordCount;
  }
}

// ==================== ПОЛУЧЕНИЕ ЗАПИСИ ====================
WeatherRecord WeatherForecast::getRecord(int offset) const {
  WeatherRecord empty = { 0 };
  if (offset < 0 || offset >= recordCount) {
    return empty;
  }

  int realIndex;
  if (recordCount < HISTORY_SIZE) {
    realIndex = offset;
  } else {
    realIndex = (currentIndex + offset) % HISTORY_SIZE;
  }
  return records[realIndex];
}
//=============================================================
float WeatherForecast::getHumidityTrend(int hoursBack) {
  if (recordCount < 4) return 0;

  int recordsBack = hoursBack * 2;
  if (recordsBack >= recordCount) recordsBack = recordCount - 1;

  float oldSum = 0, newSum = 0;
  int oldCount = 0, newCount = 0;

  for (int offset = -1; offset <= 1; offset++) {
    int oldIdx = recordCount - 1 - recordsBack + offset;
    int newIdx = recordCount - 1 + offset;

    if (oldIdx >= 0 && oldIdx < recordCount) {
      WeatherRecord r = getRecord(oldIdx);
      oldSum += r.humidity;
      oldCount++;
    }

    if (newIdx >= 0 && newIdx < recordCount) {
      WeatherRecord r = getRecord(newIdx);
      newSum += r.humidity;
      newCount++;
    }
  }

  if (oldCount == 0 || newCount == 0) return 0;

  float oldHum = oldSum / oldCount;
  float newHum = newSum / newCount;
  float deltaHum = newHum - oldHum;
  float deltaHours = hoursBack;

  return (deltaHours > 0) ? deltaHum / deltaHours : 0;
}

// ==================== РАСЧЁТ ТРЕНДОВ (СГЛАЖЕННЫЙ) ====================
float WeatherForecast::getPressureTrend(int hoursBack) {
  if (recordCount < 4) return 0;  // Нужно минимум 4 записи для сглаживания

  int recordsBack = hoursBack * 2;
  if (recordsBack >= recordCount) recordsBack = recordCount - 1;

  // Берём среднее из 3 точек для сглаживания (убирает выбросы)
  float oldSum = 0, newSum = 0;
  int oldCount = 0, newCount = 0;

  for (int offset = -1; offset <= 1; offset++) {
    int oldIdx = recordCount - 1 - recordsBack + offset;
    int newIdx = recordCount - 1 + offset;

    if (oldIdx >= 0 && oldIdx < recordCount) {
      WeatherRecord r = getRecord(oldIdx);
      oldSum += r.pressure;
      oldCount++;
    }

    if (newIdx >= 0 && newIdx < recordCount) {
      WeatherRecord r = getRecord(newIdx);
      newSum += r.pressure;
      newCount++;
    }
  }

  if (oldCount == 0 || newCount == 0) return 0;

  float oldPressure = oldSum / oldCount;
  float newPressure = newSum / newCount;

  float deltaPressure = newPressure - oldPressure;
  float deltaHours = hoursBack;

  return (deltaHours > 0) ? deltaPressure / deltaHours : 0;
}

float WeatherForecast::getTemperatureTrend(int hoursBack) {
  if (recordCount < 4) return 0;

  int recordsBack = hoursBack * 2;
  if (recordsBack >= recordCount) recordsBack = recordCount - 1;

  float oldSum = 0, newSum = 0;
  int oldCount = 0, newCount = 0;

  for (int offset = -1; offset <= 1; offset++) {
    int oldIdx = recordCount - 1 - recordsBack + offset;
    int newIdx = recordCount - 1 + offset;

    if (oldIdx >= 0 && oldIdx < recordCount) {
      WeatherRecord r = getRecord(oldIdx);
      oldSum += r.temperature;
      oldCount++;
    }

    if (newIdx >= 0 && newIdx < recordCount) {
      WeatherRecord r = getRecord(newIdx);
      newSum += r.temperature;
      newCount++;
    }
  }

  if (oldCount == 0 || newCount == 0) return 0;

  float oldTemp = oldSum / oldCount;
  float newTemp = newSum / newCount;
  float deltaTemp = newTemp - oldTemp;
  float deltaHours = hoursBack;

  return (deltaHours > 0) ? deltaTemp / deltaHours : 0;
}

// ==================== ВЕРОЯТНОСТЬ ДОЖДЯ ====================
int WeatherForecast::getRainProbability() {
  if (recordCount < 8) return 0;

  float pressureTrend = getPressureTrend(3);
  float humidity = getRecord(recordCount - 1).humidity;
  float pressure = getRecord(recordCount - 1).pressure;
  int season = getSeason();

  // ===== ОСНОВНОЙ ФАКТОР — ВЛАЖНОСТЬ (С СЕЗОННОЙ КОРРЕКТИРОВКОЙ) =====
  float probability = 0;

  // Сезонная корректировка: летом вероятность выше при той же влажности
  float seasonBoost = (season == 2) ? 0.10 : (season == 3 ? -0.05 : 0);

  if (humidity > 90) {
    probability += 0.80 + seasonBoost;
  } else if (humidity > 80) {
    probability += 0.60 + seasonBoost;
  } else if (humidity > 75) {
    probability += 0.45 + seasonBoost;
  } else if (humidity > 70) {
    probability += 0.30 + seasonBoost;
  } else if (humidity > 60) {
    probability += 0.15 + seasonBoost;
  }

  // Давление — вторичный фактор
  if (pressure < 752) {
    probability += 0.20;
  } else if (pressure < 754) {
    probability += 0.10;
  }

  // Тренд давления
  if (pressureTrend < -0.3) {
    probability += 0.20;
  } else if (pressureTrend < -0.1) {
    probability += 0.10;
  }

  // Бонус: если уже идёт дождь сейчас
  int currentWeather = getHybridForecast();
  if (currentWeather == WEATHER_RAIN || currentWeather == WEATHER_THUNDER) {
    probability += 0.15;
  }

  return constrain(probability * 100, 0, 100);
}

// ==================== ОПРЕДЕЛЕНИЕ ПОГОДЫ (ДЛЯ РОСТОВА-НА-ДОНУ) ====================
int WeatherForecast::determineWeather(float pressure, float humidity, float temp, float pressureTrend1h) {

  // ========== ОТЛАДОЧНАЯ ПЕЧАТЬ ВХОДНЫХ ДАННЫХ ==========
  LOG_D("🔍 [WEATHER DEBUG] =================================");
  LOG_D("   Давление:     %.1f мм рт.ст.", pressure);
  LOG_D("   Влажность:    %.0f %%", humidity);
  LOG_D("   Температура:  %.1f °C", temp);
  LOG_D("   Тренд (1ч):   %.2f мм рт.ст./ч", pressureTrend1h);
  LOG_D("=================================================");

  //int result = WEATHER_PARTLY_CLOUDY;

  // ========== 1. ЭКСТРЕННЫЕ СЛУЧАИ (Приоритет реальности) ==========
  // Если влажность запредельная - это 100% дождь, игнорируем давление
  if (humidity > 85) {
    LOG_D("✅ [RULE 1] Влажность > 85%% (%d) → ДОЖДЬ", (int)humidity);
    return WEATHER_RAIN;
  }
  // Если холодно и сыро - снег
  if (temp < 2 && humidity > 80 && pressure < 752) {
    LOG_D("✅ [RULE 1] Снег: temp=%.1f (<2), hum=%.0f (>80), pres=%.1f (<752) → СНЕГ", temp, humidity, pressure);
    return WEATHER_SNOW;
  }

  // ========== 2. ГРОЗА (учитываем динамику, а не только статику) ==========
  if (humidity > 80 && pressureTrend1h < -0.5) {
    LOG_D("✅ [RULE 2] Гроза: влажность >80%% (%.0f) И тренд <-0.5 (%.2f) → ГРОЗА", humidity, pressureTrend1h);
    return WEATHER_THUNDER;
  }
  if (humidity > 78 && pressure < 746 && pressureTrend1h < -0.8) {
    LOG_D("✅ [RULE 2] Гроза (классика): влажность >78%% (%.0f), давление <746 (%.1f), тренд <-0.8 (%.2f) → ГРОЗА", humidity, pressure, pressureTrend1h);
    return WEATHER_THUNDER;
  }

  // ========== 3. ДОЖДЬ (Смягченные условия) ==========
  // Случай 1: Стабильно сыро и давление не высокое
  if (humidity > 78 && pressure < 755) {
    LOG_D("✅ [RULE 3a] Дождь: влажность >78%% (%.0f) И давление <755 (%.1f) → ДОЖДЬ", humidity, pressure);
    return WEATHER_RAIN;
  }
  if (humidity > 80 && pressureTrend1h < -0.4) {
    LOG_D("✅ [RULE 3b] Дождь: влажность >80%% (%.0f) И тренд <-0.4 (%.2f) → ДОЖДЬ", humidity, pressureTrend1h);
    return WEATHER_RAIN;
  }
  if (humidity > 75 && pressure < 749) {
    LOG_D("✅ [RULE 3c] Дождь: влажность >75%% (%.0f) И давление <749 (%.1f) → ДОЖДЬ", humidity, pressure);
    return WEATHER_RAIN;
  }

  // Морось / слабый дождь
  if (humidity > 75 && pressure < 756 && pressureTrend1h > -0.2) {
    LOG_D("✅ [RULE 3d] Морось: влажность >75%% (%.0f), давление <756 (%.1f), тренд >-0.2 (%.2f) → ДОЖДЬ", humidity, pressure, pressureTrend1h);
    return WEATHER_RAIN;
  }

  // ========== 4. ТУМАН ==========
  if (humidity > 88 && abs(pressureTrend1h) < 0.3 && temp < 10) {
    LOG_D("✅ [RULE 4] Туман: влажность >88%% (%.0f), тренд стабильный (%.2f), temp <10 (%.1f) → ТУМАН", humidity, pressureTrend1h, temp);
    return WEATHER_FOG;
  }

  // ========== 5. ОБЛАЧНОСТЬ ==========
  // Пасмурно (даже если давление высокое, но сыро)
  if (humidity > 70) {
    LOG_D("✅ [RULE 5a] Пасмурно: влажность >70%% (%.0f) → ПАСМУРНО", humidity);
    return WEATHER_CLOUDY;
  }
  if (pressure < 752) {
    LOG_D("✅ [RULE 5b] Пасмурно: давление <752 (%.1f) → ПАСМУРНО", pressure);
    return WEATHER_CLOUDY;
  }

  // Переменная облачность
  if (humidity > 58) {
    LOG_D("✅ [RULE 6a] Переменная облачность: влажность >58%% (%.0f) → ПЕРЕМЕННАЯ ОБЛАЧНОСТЬ", humidity);
    return WEATHER_PARTLY_CLOUDY;
  }
  if (pressure > 752 && pressure < 759 && humidity > 48) {
    LOG_D("✅ [RULE 6b] Переменная облачность: давление 752-759 (%.1f), влажность >48%% (%.0f) → ПЕРЕМЕННАЯ ОБЛАЧНОСТЬ", pressure, humidity);
    return WEATHER_PARTLY_CLOUDY;
  }

  // ========== 6. ЯСНО ==========
  // Только если совсем сухо и давление высокое
  if (pressure > 756 && humidity < 55) {
    LOG_D("✅ [RULE 7a] Ясно: давление >756 (%.1f) И влажность <55%% (%.0f) → ЯСНО", pressure, humidity);
    return WEATHER_CLEAR;
  }
  if (pressure > 760) {
    LOG_D("✅ [RULE 7b] Ясно: давление >760 (%.1f) → ЯСНО", pressure);
    return WEATHER_CLEAR;
  }

  // ========== 7. ПО УМОЛЧАНИЮ ==========
  LOG_D("⚠️ [DEFAULT] Ни одно условие не сработало → ПЕРЕМЕННАЯ ОБЛАЧНОСТЬ");
  return WEATHER_PARTLY_CLOUDY;
}

// ==================== ТЕКУЩАЯ ПОГОДА ====================
int WeatherForecast::getCurrentWeatherCode() {
  if (recordCount == 0) return WEATHER_UNKNOWN;

  WeatherRecord last = getRecord(recordCount - 1);
  float pressureTrend1h = getPressureTrend(1);

  return determineWeather(last.pressure, last.humidity, last.temperature, pressureTrend1h);
}

String WeatherForecast::getCurrentWeatherText() {
  int weather = getHybridForecast();

  switch (weather) {
    case WEATHER_CLEAR: return "Солнечно";
    case WEATHER_PARTLY_CLOUDY: return "Переменная облачность";
    case WEATHER_CLOUDY: return "Пасмурно";
    case WEATHER_RAIN: return "Дождь";
    case WEATHER_THUNDER: return "Гроза";
    case WEATHER_SNOW: return "Снег";
    case WEATHER_FOG: return "Туман";
    default: return "Не понятно";
  }
}

String WeatherForecast::getCurrentWeatherEmoji() {
  return getCurrentWeatherText();
}

// ==================== ПРОГНОЗ (НА ОСНОВЕ ДАННЫХ) ====================
int WeatherForecast::getForecastCode() {
  if (recordCount < 12) return WEATHER_UNKNOWN;

  float pressureTrend = getPressureTrend(6);
  float pressure = getRecord(recordCount - 1).pressure;
  float humidity = getRecord(recordCount - 1).humidity;
  float temp = getRecord(recordCount - 1).temperature;

  int rawForecast;

  // ===== БЫСТРОЕ ОПРЕДЕЛЕНИЕ =====

  // --- УХУДШЕНИЕ ПОГОДЫ (тренд вниз) ---
  if (pressureTrend < -0.5 && humidity > 70) {
    rawForecast = WEATHER_RAIN;
  } else if (pressureTrend < -0.3 && humidity > 75) {
    rawForecast = WEATHER_RAIN;
  } else if (pressureTrend < -0.2 && humidity > 80) {
    rawForecast = WEATHER_RAIN;
  }

  // --- УЛУЧШЕНИЕ ПОГОДЫ (тренд вверх) ---
  else if (pressureTrend > 0.3 && humidity < 60) {
    rawForecast = WEATHER_CLEAR;
  } else if (pressureTrend > 0.1 && humidity < 50) {
    rawForecast = WEATHER_CLEAR;
  }

  // --- СТАБИЛЬНАЯ ПОГОДА ---
  else if (abs(pressureTrend) < 0.2) {
    // По текущей влажности
    if (humidity > 80) rawForecast = WEATHER_RAIN;
    else if (humidity > 70) rawForecast = WEATHER_CLOUDY;
    else if (humidity > 55) rawForecast = WEATHER_PARTLY_CLOUDY;
    else rawForecast = WEATHER_CLEAR;
  }

  // --- НЕБОЛЬШОЕ ПАДЕНИЕ ---
  else if (pressureTrend < -0.1) {
    if (humidity > 65) rawForecast = WEATHER_CLOUDY;
    else if (humidity > 50) rawForecast = WEATHER_PARTLY_CLOUDY;
    else rawForecast = WEATHER_CLEAR;
  }

  // --- НЕБОЛЬШОЙ РОСТ ---
  else if (pressureTrend > 0.1) {
    if (humidity < 55) rawForecast = WEATHER_CLEAR;
    else if (humidity < 70) rawForecast = WEATHER_PARTLY_CLOUDY;
    else rawForecast = WEATHER_CLOUDY;
  }

  // --- ПО УМОЛЧАНИЮ ---
  else {
    rawForecast = WEATHER_PARTLY_CLOUDY;
  }

  // === ИНЕРЦИЯ С УЛУЧШЕНИЕМ ===
  static int lastReturnedForecast = WEATHER_UNKNOWN;
  static unsigned long lastChangeTime = 0;

  if (rawForecast == lastReturnedForecast) {
    return rawForecast;
  }

  unsigned long now = millis();

  // Улучшение (ближе к CLEAR) — сразу
  if (rawForecast < lastReturnedForecast) {
    lastReturnedForecast = rawForecast;
    lastChangeTime = now;
    return rawForecast;
  }

  // Ухудшение — ждём 30 минут
  if (now - lastChangeTime < 1800000) {
    return lastReturnedForecast;
  }

  lastChangeTime = now;
  lastReturnedForecast = rawForecast;
  return rawForecast;
}

// ==================== ТЕКСТ ПРОГНОЗА (УЛУЧШЕННЫЙ) ====================
const char* WeatherForecast::getForecastText() {
  if (recordCount < 10) {
    strcpy(_forecastTextBuf, "Сбор данных");
    return _forecastTextBuf;
  }

  int weather = getForecastCode();
  int rainProb = getRainProbability();
  float temp = getRecord(recordCount - 1).temperature;
  float humidity = getRecord(recordCount - 1).humidity;
  bool isNight = isNightTime();

  // ===== ОСНОВНОЙ ТЕКСТ С УЧЁТОМ ПОГОДЫ И ТЕМПЕРАТУРЫ =====
  switch (weather) {
    case WEATHER_CLEAR:
      if (isNight) {
        if (temp < -10) strcpy(_forecastTextBuf, "Морозная ночь, ясно");
        else if (temp < -5) strcpy(_forecastTextBuf, "Холодная ночь, ясно");
        else strcpy(_forecastTextBuf, "Ясная ночь");
      } else {
        if (temp > 30) strcpy(_forecastTextBuf, "Жарко, ясно");
        else if (temp > 25) strcpy(_forecastTextBuf, "Тепло, ясно");
        else if (temp < -10) strcpy(_forecastTextBuf, "Морозно, ясно");
        else if (temp < -5) strcpy(_forecastTextBuf, "Холодно, ясно");
        else strcpy(_forecastTextBuf, "Ясно");
      }
      break;

    case WEATHER_PARTLY_CLOUDY:
      if (isNight) {
        if (temp < -5) strcpy(_forecastTextBuf, "Морозно, перем. облач.");
        else strcpy(_forecastTextBuf, "Перем. облачность, ночь");
      } else {
        if (temp > 28) strcpy(_forecastTextBuf, "Жарко, перем. облачность");
        else if (temp < -5) strcpy(_forecastTextBuf, "Морозно, перем. облач.");
        else strcpy(_forecastTextBuf, "Переменная облачность");
      }
      break;

    case WEATHER_CLOUDY:
      if (isNight) {
        if (temp < -5) strcpy(_forecastTextBuf, "Пасмурно, морозно");
        else strcpy(_forecastTextBuf, "Пасмурно, ночь");
      } else {
        if (humidity > 80 && temp < 5) strcpy(_forecastTextBuf, "Пасмурно, сыро и холодно");
        else if (humidity > 80) strcpy(_forecastTextBuf, "Пасмурно, сыро");
        else if (temp < -5) strcpy(_forecastTextBuf, "Пасмурно, морозно");
        else strcpy(_forecastTextBuf, "Пасмурно");
      }
      break;

    case WEATHER_RAIN:
      if (isNight) {
        if (temp < 2) strcpy(_forecastTextBuf, "Холодный дождь, ночь");
        else if (rainProb > 80) strcpy(_forecastTextBuf, "Сильный дождь, ночь");
        else if (rainProb > 60) strcpy(_forecastTextBuf, "Дождь, ночь");
        else strcpy(_forecastTextBuf, "Небольшой дождь, ночь");
      } else {
        if (temp < 2) strcpy(_forecastTextBuf, "Холодный дождь, возможно гололёд");
        else if (rainProb > 80) strcpy(_forecastTextBuf, "Сильный дождь");
        else if (rainProb > 60) strcpy(_forecastTextBuf, "Дождь");
        else strcpy(_forecastTextBuf, "Небольшой дождь");
      }
      break;

    case WEATHER_THUNDER:
      if (isNight) {
        if (temp > 25) strcpy(_forecastTextBuf, "Гроза, душная ночь");
        else strcpy(_forecastTextBuf, "Гроза, ночь");
      } else {
        if (temp > 30) strcpy(_forecastTextBuf, "Гроза, очень жарко");
        else if (temp > 25) strcpy(_forecastTextBuf, "Гроза, жарко");
        else strcpy(_forecastTextBuf, "Гроза");
      }
      break;

    case WEATHER_SNOW:
      if (isNight) {
        if (rainProb > 70) strcpy(_forecastTextBuf, "Снегопад, ночь");
        else if (temp > -2) strcpy(_forecastTextBuf, "Мокрый снег, ночь");
        else strcpy(_forecastTextBuf, "Снег, ночь");
      } else {
        if (rainProb > 70) strcpy(_forecastTextBuf, "Снегопад");
        else if (temp > -2) strcpy(_forecastTextBuf, "Мокрый снег, опасно");
        else strcpy(_forecastTextBuf, "Снег");
      }
      break;

    case WEATHER_FOG:
      if (isNight) {
        if (temp < -5) strcpy(_forecastTextBuf, "Морозный туман");
        else strcpy(_forecastTextBuf, "Туман, ночь");
      } else {
        if (temp < -5) strcpy(_forecastTextBuf, "Морозный туман");
        else if (temp < 5) strcpy(_forecastTextBuf, "Туман, холодно");
        else strcpy(_forecastTextBuf, "Туман");
      }
      break;

    default:
      strcpy(_forecastTextBuf, "Облачно");
      break;
  }

  return _forecastTextBuf;
}

// ==================== ПОЛУЧЕНИЕ ВЕРОЯТНОСТИ ДОЖДЯ (ОТДЕЛЬНАЯ СТРОКА) ====================
const char* WeatherForecast::getRainProbText() {
  _rainProbBuf[0] = '\0';

  if (recordCount < 10) return _rainProbBuf;

  int weather = getForecastCode();
  int rainProb = getRainProbability();

  // ===== ВЕРОЯТНОСТЬ ДОЖДЯ =====
  if (rainProb > 50 && weather != WEATHER_RAIN && weather != WEATHER_SNOW && weather != WEATHER_THUNDER) {
    snprintf(_rainProbBuf, sizeof(_rainProbBuf), "(%d%% дождь)", rainProb);
  } else if (rainProb > 35 && weather == WEATHER_CLOUDY) {
    snprintf(_rainProbBuf, sizeof(_rainProbBuf), "(%d%%)", rainProb);
  }

  return _rainProbBuf;
}

// ==================== ГРАФИЧЕСКИЕ МЕТОДЫ ====================
void WeatherForecast::drawCurrentWeatherIcon(TFT_eSPI& tft, int x, int y) {
  int weather = getHybridForecast();  // ← ИСПРАВЛЕНО (было getCurrentWeatherCode)
  bool isNight = isNightTime();
  const uint16_t* icon = getWeatherIcon(weather, isNight);
  tft.pushImage(x, y, ICON_SIZE, ICON_SIZE, icon);
}

void WeatherForecast::drawForecastIcon(TFT_eSPI& tft, int x, int y) {
  int weather = getHybridForecast();  // ← ИСПРАВЛЕНО
  bool isNight = isNightTime();
  const uint16_t* icon = getWeatherIcon(weather, isNight);
  tft.pushImage(x, y, ICON_SIZE, ICON_SIZE, icon);
}

// ==================== ОТЛАДОЧНАЯ ПЕЧАТЬ (УЛУЧШЕННАЯ) ====================
void WeatherForecast::printHistory() {
  LOG_D_RAW("=== ДИАГНОСТИКА ПРОГНОЗА ПОГОДЫ ===");

  // ========== ИНФОРМАЦИЯ О КОЛИЧЕСТВЕ ДАННЫХ ==========
  LOG_D("📊 Записей: %d / %d (нужно 12 для прогноза, 36 для точности)", recordCount, HISTORY_SIZE);

  if (recordCount < 12) {
    int needRecords = 12 - recordCount;
    int needSeconds = needRecords * 10;  // Предполагаем интервал 10 секунд
    int needMinutes = needSeconds / 60;
    LOG_D("⚠️ Недостаточно данных! Нужно ещё %d измерений (~%d мин)", needRecords, needMinutes);
    LOG_D_RAW("============================================");
    return;
  }

  // ========== КАЧЕСТВО ПРОГНОЗА ==========
  int quality = 0;
  const char* qualityText = "";
  if (recordCount >= 72) {  // 72 записи = 12 часов
    quality = 100;
    qualityText = "Отличное ★★★★★";
  } else if (recordCount >= 48) {  // 48 записей = 8 часов
    quality = 85;
    qualityText = "Хорошее ★★★★☆";
  } else if (recordCount >= 36) {  // 36 записей = 6 часов
    quality = 70;
    qualityText = "Среднее ★★★☆☆";
  } else if (recordCount >= 24) {  // 24 записи = 4 часа
    quality = 50;
    qualityText = "Плохое ★★☆☆☆";
  } else {  // 12-23 записи = 2-4 часа
    quality = 30;
    qualityText = "Очень плохое ★☆☆☆☆";
  }
  LOG_D("📈 Качество прогноза: %d%% (%s)", quality, qualityText);

  // ========== ТЕКУЩИЕ ПОКАЗАНИЯ ==========
  WeatherRecord last = getRecord(recordCount - 1);
  LOG_D_RAW("");
  LOG_D_RAW("📍 ТЕКУЩИЕ ПОКАЗАНИЯ:");
  LOG_D("   Температура: %.1f°C", last.temperature);
  LOG_D("   Влажность:   %.0f%%", last.humidity);
  LOG_D("   Давление:    %.1f мм рт.ст. (%.1f гПа)", last.pressure, last.pressure * 1.33322);

  // ========== ТРЕНДЫ (С РАЗНЫМИ ПЕРИОДАМИ) ==========
  float trend1h = getPressureTrend(1);
  float trend3h = getPressureTrend(3);
  float trend6h = getPressureTrend(6);

  LOG_D_RAW("");
  LOG_D_RAW("📉 ТРЕНДЫ ДАВЛЕНИЯ:");

  // Функция для стрелки тренда
  auto getTrendArrow = [](float trend) -> const char* {
    if (trend < -1.0) return "↓↓↓ (резкое падение)";
    if (trend < -0.3) return "↓↓ (падение)";
    if (trend < -0.1) return "↓ (лёгкое падение)";
    if (trend > 1.0) return "↑↑↑ (резкий рост)";
    if (trend > 0.3) return "↑↑ (рост)";
    if (trend > 0.1) return "↑ (лёгкий рост)";
    return "→ (стабильно)";
  };

  LOG_D("   За 1 час:  %+.2f мм рт.ст./ч %s", trend1h, getTrendArrow(trend1h));
  LOG_D("   За 3 часа: %+.2f мм рт.ст./ч %s", trend3h, getTrendArrow(trend3h));
  LOG_D("   За 6 часа: %+.2f мм рт.ст./ч %s", trend6h, getTrendArrow(trend6h));

  // ========== ВЕРОЯТНОСТЬ ДОЖДЯ ==========
  int rainProb = getRainProbability();
  const char* rainIcon = "";
  const char* rainDesc = "";
  if (rainProb > 80) {
    rainIcon = "🌧️🌧️🌧️";
    rainDesc = "Очень высокая";
  } else if (rainProb > 60) {
    rainIcon = "🌧️🌧️";
    rainDesc = "Высокая";
  } else if (rainProb > 40) {
    rainIcon = "🌧️";
    rainDesc = "Средняя";
  } else if (rainProb > 20) {
    rainIcon = "🌦️";
    rainDesc = "Низкая";
  } else {
    rainIcon = "☀️";
    rainDesc = "Очень низкая";
  }
  LOG_D_RAW("");
  LOG_D("💧 ВЕРОЯТНОСТЬ ДОЖДЯ: %d%% %s (%s)", rainProb, rainIcon, rainDesc);

  // ========== ТЕКУЩАЯ ПОГОДА ==========
  int current = getHybridForecast();
  const char* currentIcon = "";
  switch (current) {
    case WEATHER_CLEAR: currentIcon = "☀️"; break;
    case WEATHER_PARTLY_CLOUDY: currentIcon = "⛅"; break;
    case WEATHER_CLOUDY: currentIcon = "☁️"; break;
    case WEATHER_RAIN: currentIcon = "🌧️"; break;
    case WEATHER_THUNDER: currentIcon = "⛈️"; break;
    case WEATHER_SNOW: currentIcon = "❄️"; break;
    case WEATHER_FOG: currentIcon = "🌫️"; break;
    default: currentIcon = "❓"; break;
  }
  LOG_D_RAW("");
  LOG_D("🪟 СЕЙЧАС: %s %s", currentIcon, getCurrentWeatherText().c_str());

  // ========== ПРОГНОЗ ==========
  int forecast = getHybridForecast();
  const char* forecastIcon = "";
  switch (forecast) {
    case WEATHER_CLEAR: forecastIcon = "☀️"; break;
    case WEATHER_PARTLY_CLOUDY: forecastIcon = "⛅"; break;
    case WEATHER_CLOUDY: forecastIcon = "☁️"; break;
    case WEATHER_RAIN: forecastIcon = "🌧️"; break;
    case WEATHER_THUNDER: forecastIcon = "⛈️"; break;
    case WEATHER_SNOW: forecastIcon = "❄️"; break;
    default: forecastIcon = "❓"; break;
  }
  LOG_D_RAW("");
  LOG_D("🔮 ПРОГНОЗ (на 6 ч): %s %s", forecastIcon, getForecastText());

  // ========== ДИАГНОСТИКА ПОРОГОВ ==========
  LOG_D_RAW("");
  LOG_D_RAW("🔧 ДИАГНОСТИКА ПОРОГОВ:");
  LOG_D("   Давление: %.1f мм рт.ст.", last.pressure);
  LOG_D("   Влажность: %.0f%%", last.humidity);
  LOG_D("   Температура: %.1f°C", last.temperature);
  LOG_D("   Тренд за 6ч: %.2f мм рт.ст./ч", trend6h);

  // Определяем, какой порог сработал бы
  LOG_D_RAW("   Активные пороги: ");
  bool hasActive = false;
  if (last.pressure > 756 && last.humidity < 65) {
    LOG_D_RAW("[ВЫСОКОЕ ДАВЛЕНИЕ] ");
    hasActive = true;
  }
  if (last.pressure < 750 && last.humidity > 70) {
    LOG_D_RAW("[НИЗКОЕ ДАВЛЕНИЕ+ДОЖДЬ] ");
    hasActive = true;
  }
  if (trend6h < -1.0) {
    LOG_D_RAW("[РЕЗКОЕ ПАДЕНИЕ] ");
    hasActive = true;
  }
  if (trend6h > 0.5) {
    LOG_D_RAW("[РЕЗКИЙ РОСТ] ");
    hasActive = true;
  }
  if (last.humidity > 75) {
    LOG_D_RAW("[ВЫСОКАЯ ВЛАЖНОСТЬ] ");
    hasActive = true;
  }
  if (last.humidity < 45) {
    LOG_D_RAW("[НИЗКАЯ ВЛАЖНОСТЬ] ");
    hasActive = true;
  }
  if (trend6h == 0.00 && recordCount < 36) {
    LOG_D_RAW("[НЕДОСТАТОЧНО ДАННЫХ] ");
    hasActive = true;
  }
  if (!hasActive) {
    LOG_D_RAW("[СТАНДАРТНЫЙ РЕЖИМ]");
  }
  LOG_D_RAW("");

  // ========== РЕКОМЕНДАЦИИ ==========
  LOG_D_RAW("");
  LOG_D_RAW("💡 РЕКОМЕНДАЦИИ:");
  if (recordCount < 36) {
    int hoursNeeded = (36 - recordCount) * 10 / 3600 + 1;
    LOG_D("   ⏳ Подождите %d час(а) для точного прогноза", hoursNeeded);
  }
  if (rainProb > 60) {
    LOG_D_RAW("   ☔ Возьмите зонт!");
  }
  if (current == WEATHER_CLEAR && forecast == WEATHER_RAIN) {
    LOG_D_RAW("   🌧️ Погода скоро ухудшится");
  }
  if (forecast == WEATHER_CLEAR && current != WEATHER_CLEAR) {
    LOG_D_RAW("   ☀️ Ожидается улучшение погоды");
  }
  if (trend6h < -1.5) {
    LOG_D_RAW("   ⚠️ Давление резко падает - возможен шторм");
  }
  if (last.humidity > 85 && last.temperature < 5) {
    LOG_D_RAW("   ❄️ Возможен гололёд!");
  }
  if (quality < 50) {
    LOG_D_RAW("   📊 Прогноз неточный из-за недостатка данных");
  }

  LOG_D_RAW("");
  LOG_D_RAW("============================================");
}

// ==================== ДОПОЛНИТЕЛЬНЫЕ МЕТОДЫ ====================
bool WeatherForecast::isDataAvailable() {
  return (recordCount >= 12);
}

int WeatherForecast::getRecordCount() {
  return recordCount;
}