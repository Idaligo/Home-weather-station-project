#ifndef OTA_MODULE_H
#define OTA_MODULE_H

#include <Arduino.h>

// Инициализация OTA (включает Wi-Fi, показывает IP)
void otaBegin();

// Основной цикл OTA (вызывается из loop() при currentMode == MODE_OTA)
void otaLoop();

// Выход из OTA (выключает Wi-Fi, возврат в MODE_MAIN)
void otaEnd();

// Идёт ли обновление (для блокировки выхода)
bool otaIsInProgress();

#endif