// web_module.cpp
#include "web_module.h"
#include "common.h"
#include "menu_module.h"
#include "sd_module.h"
#include "keypad_module.h"
#include "rtc_module.h"
#include "logger.h"

#include <WiFi.h>
#include <WebServer.h>
#include <SD.h>
#include <TFT_eSPI.h>

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== ВНЕШНИЕ ПЕРЕМЕННЫЕ ====================
extern TFT_eSPI tft;
extern RTCModule rtcClock;

extern WiFiConfig wifiConfig;
extern LocationConfig locationConfig;
extern ForecastConfig forecastConfig;
extern bool lastSessionFailed;
extern bool wifiSessionInProgress;

extern bool sdReady;
extern bool sdLoggingEnabled;

extern bool menuChanged;
extern bool needFullRedraw;

// Внешние функции из menu_module
extern void drawMenu();
extern void handleMenuNavigation();
extern bool checkMenuTimeout();
extern void exitMenuMode();
extern void drawUpDownArrows(int x, int y, int size, uint16_t color);
extern void drawWebStatus();
extern int8_t lastApDrawn;
extern unsigned long lastSignalTime;
extern unsigned long lastMenuActivity;   // ← должен быть БЕЗ static в menu_module.cpp

// ==================== СОСТОЯНИЕ ====================
WebServer logServer(80);
bool webLogsActive = false;
unsigned long webLogsStartTime = 0;

// ==================== МЕНЮ «СКАЧАТЬ ЛОГИ» ====================
bool inLogsSubmenu = false;
int logsSubmenuItem = 0;
int lastLogsItem = -1;

const char* logsSubmenuItems[] = {
  "С подсказками",
  "Без подсказок",
  "Назад"
};

// ===================================================================
// СИСТЕМНЫЕ ФАЙЛЫ (не показываем, не трогаем)
// ===================================================================
static bool isSystemFile(const String& name) {
  if (name.length() == 0) return true;
  if (name.startsWith(".")) return true;  // .Trashes, ._*, .Spotlight-V100
  if (name.startsWith("System Volume Information")) return true;
  return false;
}

// ===================================================================
// КОРЕНЬ: СПИСОК ФАЙЛОВ (две секции: CSV / прочие)
// ===================================================================
void handleLogRoot() {
  const int MAX_FILES = 64;
  String csvNames[MAX_FILES];
  size_t csvSizes[MAX_FILES];
  int csvCount = 0;

  String otherNames[MAX_FILES];
  size_t otherSizes[MAX_FILES];
  int otherCount = 0;

  File root = SD.open("/");
  bool sdOk = (bool)root;
  if (sdOk) {
    while (true) {
      File entry = root.openNextFile();
      if (!entry) break;
      if (entry.isDirectory()) {
        entry.close();
        continue;
      }
      String name = entry.name();
      if (name.startsWith("/")) name = name.substring(1);

      if (isSystemFile(name)) {
        entry.close();
        continue;
      }

      size_t sz = entry.size();
      entry.close();

      if (name.endsWith(".csv")) {
        if (csvCount < MAX_FILES) {
          csvNames[csvCount] = name;
          csvSizes[csvCount] = sz;
          csvCount++;
        }
      } else {
        if (otherCount < MAX_FILES) {
          otherNames[otherCount] = name;
          otherSizes[otherCount] = sz;
          otherCount++;
        }
      }
    }
    root.close();
  }

  // ===== HTML =====
  String html = "<!DOCTYPE html><html><head><meta charset='UTF-8'>";
  html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<title>Meteo Logs</title>";
  html += "<style>";
  html += "body{font-family:Arial;background:#1a1a2e;color:#eee;padding:20px;margin:0}";
  html += "h1{color:#00d4ff;text-align:center;margin:10px 0 20px}";
  html += "h2{color:#00d4ff;font-size:18px;margin:20px 0 10px;border-bottom:1px solid #333;padding-bottom:4px}";
  html += ".file{background:#16213e;padding:12px;margin:8px 0;border-radius:8px;";
  html += "display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}";
  html += ".file .name{flex:1;min-width:200px;word-break:break-all}";
  html += ".file .actions{display:flex;gap:8px;flex-shrink:0}";
  html += ".file a{color:#00d4ff;text-decoration:none;padding:6px 12px;border:1px solid #00d4ff;";
  html += "border-radius:4px;font-size:14px;white-space:nowrap}";
  html += ".file a:hover{background:#00d4ff;color:#1a1a2e}";
  html += ".file a.del{color:#ff5555;border-color:#ff5555}";
  html += ".file a.del:hover{background:#ff5555;color:#1a1a2e}";
  html += ".empty{text-align:center;color:#888;padding:20px;font-style:italic}";
  html += ".info{text-align:center;color:#888;margin:20px 0;font-size:14px}";
  html += "</style></head><body>";
  html += "<h1>📁 Файлы на SD</h1>";

  if (!sdOk) {
    html += "<div class='empty'>❌ Ошибка чтения SD</div>";
  } else {
    // Секция 1: Логи (CSV)
    html += "<h2>📊 Логи (CSV) — " + String(csvCount) + "</h2>";
    if (csvCount == 0) {
      html += "<div class='empty'>Нет CSV-файлов</div>";
    } else {
      for (int i = 0; i < csvCount; i++) {
        html += "<div class='file'>";
        html += "<span class='name'>📄 " + csvNames[i] + " (" + String(csvSizes[i]) + " байт)</span>";
        html += "<span class='actions'>";
        html += "<a href='/download?file=" + csvNames[i] + "'>⬇ Скачать</a>";
        html += "<a class='del' href='/delete?file=" + csvNames[i] + "' ";
        html += "onclick=\"return confirm('Удалить " + csvNames[i] + "?');\">🗑 Удалить</a>";
        html += "</span></div>";
      }
    }

    // Секция 2: Прочие файлы
    html += "<h2>📦 Прочие файлы — " + String(otherCount) + "</h2>";
    if (otherCount == 0) {
      html += "<div class='empty'>Нет прочих файлов</div>";
    } else {
      for (int i = 0; i < otherCount; i++) {
        html += "<div class='file'>";
        html += "<span class='name'>📄 " + otherNames[i] + " (" + String(otherSizes[i]) + " байт)</span>";
        html += "<span class='actions'>";
        html += "<a href='/download?file=" + otherNames[i] + "'>⬇ Скачать</a>";
        html += "<a class='del' href='/delete?file=" + otherNames[i] + "' ";
        html += "onclick=\"return confirm('Удалить " + otherNames[i] + "?');\">🗑 Удалить</a>";
        html += "</span></div>";
      }
    }
  }

  html += "<div class='info'>Wi-Fi отключится через 5 минут<br>";
  html += "<a href='/' style='color:#00d4ff'>🔄 Обновить</a></div>";
  html += "</body></html>";
  logServer.send(200, "text/html", html);
}

// ===================================================================
// СКАЧИВАНИЕ ФАЙЛА С SD (через веб-сервер)
// ===================================================================
void handleLogDownload() {
  if (!logServer.hasArg("file")) {
    logServer.send(400, "text/plain", "Missing file parameter");
    return;
  }
  String fileName = logServer.arg("file");

  if (fileName.indexOf('/') >= 0 || fileName.indexOf("..") >= 0) {
    logServer.send(400, "text/plain", "Invalid file name");
    return;
  }
  if (isSystemFile(fileName)) {
    logServer.send(403, "text/plain", "System files are not accessible");
    return;
  }

  String fullPath = "/" + fileName;
  if (!SD.exists(fullPath)) {
    logServer.send(404, "text/plain", "File not found");
    return;
  }
  File file = SD.open(fullPath, FILE_READ);
  if (!file) {
    logServer.send(500, "text/plain", "Failed to open file");
    return;
  }

  String headerValue = "attachment; filename=" + fileName;
  logServer.sendHeader("Content-Disposition", headerValue);
  logServer.streamFile(file, "application/octet-stream");
  file.close();
}

// ===================================================================
// УДАЛЕНИЕ ФАЙЛА С SD (через веб-сервер)
// ===================================================================
void handleLogDelete() {
  if (!logServer.hasArg("file")) {
    logServer.send(400, "text/plain", "Missing file parameter");
    return;
  }

  String fileName = logServer.arg("file");

  if (fileName.indexOf('/') >= 0 || fileName.indexOf("..") >= 0) {
    logServer.send(400, "text/plain", "Invalid file name");
    return;
  }
  if (isSystemFile(fileName)) {
    logServer.send(403, "text/plain", "System files cannot be deleted");
    return;
  }

  String fullPath = "/" + fileName;
  if (!SD.exists(fullPath)) {
    logServer.send(404, "text/plain", "File not found");
    return;
  }

  if (SD.remove(fullPath)) {
    LOG_I("🗑️ Удалён файл: %s", fullPath.c_str());
    logServer.sendHeader("Location", "/");
    logServer.send(303, "text/plain", "");
  } else {
    LOG_W("⚠️ Не удалось удалить: %s", fullPath.c_str());
    logServer.send(500, "text/plain", "Failed to delete file");
  }
}

// ===================================================================
// ЛОГИ: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawLogsMenuItem(int itemIndex, bool selected) {
  if (itemIndex < 0 || itemIndex >= LOGS_ITEMS_COUNT) return;

  int startY = 60;
  int stepY = 45;
  int y = startY + itemIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  }

  // Динамический текст для пункта 1: «Остановить», если сервер работает
  if (itemIndex == 1 && webLogsActive) {
    tft.print("Остановить");
  } else {
    tft.print(logsSubmenuItems[itemIndex]);
  }
}

// ===================================================================
// ЛОГИ: навигация (2 строки, без скролла)
// ===================================================================
void drawLogsMenuNav() {
  if (!inLogsSubmenu) return;
  if (!menuChanged) return;

  if (lastLogsItem >= 0 && lastLogsItem != logsSubmenuItem) {
    drawLogsMenuItem(lastLogsItem, false);
  }
  drawLogsMenuItem(logsSubmenuItem, true);

  lastLogsItem = logsSubmenuItem;
  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: СКАЧАТЬ ЛОГИ
// ===================================================================
void drawLogsMenu() {
  if (!inLogsSubmenu) return;

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Скачать логи");
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  int startY = 60;
  int stepY = 45;

  for (int i = 0; i < LOGS_ITEMS_COUNT; i++) {
    int y = startY + i * stepY;
    if (i == logsSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }
    // Динамический текст для пункта 1: «Остановить», если сервер работает
    if (i == 1 && webLogsActive) {
      tft.print("Остановить");
    } else {
      tft.print(logsSubmenuItems[i]);
    }
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    OK - вход");

  lastLogsItem = logsSubmenuItem;
  menuChanged = false;
}

void handleLogsMenu() {
  if (!inLogsSubmenu) return;
  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;
  lastMenuActivity = millis();

  switch (key) {
    case KEY_UP:
      logsSubmenuItem--;
      if (logsSubmenuItem < 0) logsSubmenuItem = LOGS_ITEMS_COUNT - 1;
      menuChanged = true;
      drawLogsMenuNav();
      break;

    case KEY_DOWN:
      logsSubmenuItem++;
      if (logsSubmenuItem >= LOGS_ITEMS_COUNT) logsSubmenuItem = 0;
      menuChanged = true;
      drawLogsMenuNav();
      break;

    case KEY_OK:
      if (logsSubmenuItem == LOGS_ITEMS_COUNT - 1) {  // Назад
        inLogsSubmenu = false;
        menuChanged = true;
        drawMenu();
        lastMenuActivity = millis();
        LOG_I("↩️ Выход из «Скачать логи» (без включения)");
        break;
      }
      if (logsSubmenuItem == 0) {  // С подсказками
        inLogsSubmenu = false;
        webLogsBegin(true);
        break;
      }
      if (logsSubmenuItem == 1) {  // Без подсказок
        inLogsSubmenu = false;
        if (webLogsActive) {
          // Сервер уже работает — останавливаем
          webLogsStop();
          menuChanged = true;
          drawMenu();
        } else {
          webLogsBegin(false);  // неблокирующий, сразу главный экран
        }
        break;
      }
      break;
  }
}

// ===================================================================
// ЗАПУСК ВЕБ-СЕРВЕРА (два режима: с подсказками / без)
// ===================================================================
void webLogsBegin(bool showHints) {
  // ===== НЕБЛОКИРУЮЩИЙ РЕЖИМ «БЕЗ ПОДСКАЗОК» =====
  if (!showHints) {
    WiFi.mode(WIFI_STA);
    WiFi.begin();

    unsigned long startAttempt = millis();
    while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt) < 15000) {
      delay(250);
    }
    delay(500);

    if (WiFi.status() != WL_CONNECTED) {
      LOG_E("❌ «Без подсказок»: Wi-Fi не подключился");
      WiFi.mode(WIFI_OFF);
      lastMenuActivity = millis();
      exitMenuMode();
      return;
    }

    logServer.on("/", handleLogRoot);
    logServer.on("/download", handleLogDownload);
    logServer.on("/delete", handleLogDelete);
    logServer.begin();
    webLogsActive = true;
    webLogsStartTime = millis();
    LOG_I("🌐 Веб-сервер (без подсказок) запущен: %s",
          WiFi.localIP().toString().c_str());

    lastMenuActivity = millis();
    exitMenuMode();   // сразу главный экран, AP появится
    return;
  }

  // ===== БЛОКИРУЮЩИЙ РЕЖИМ «С ПОДСКАЗКАМИ» =====
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Скачивание логов");

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 60);
  tft.print("Подключение к Wi-Fi...");

  WiFi.mode(WIFI_STA);
  WiFi.begin();

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt) < 15000) {
    delay(250);
  }
  delay(500);

  if (WiFi.status() != WL_CONNECTED) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(10, 100);
    tft.print("Ошибка Wi-Fi!");
    delay(2000);
    WiFi.mode(WIFI_OFF);
    return;
  }

  logServer.on("/", handleLogRoot);
  logServer.on("/download", handleLogDownload);
  logServer.on("/delete", handleLogDelete);
  logServer.begin();
  webLogsActive = true;

  IPAddress ip = WiFi.localIP();
  if (showHints) {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Веб-сервер запущен");

    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setCursor(10, 60);
    tft.print("Откройте в браузере:");
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(3);
    tft.setCursor(10, 90);
    tft.print(ip.toString());

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setCursor(10, 140);
    tft.print("Устройство и телефон");
    tft.setCursor(10, 170);
    tft.print("должны быть в одной");
    tft.setCursor(10, 200);
    tft.print("сети Wi-Fi.");

    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(10, 250);
    tft.print("Сервер отключится через 5 минут");

    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 280);
    tft.print("OK - выход");
  }

  LOG_I("🌐 Веб-сервер логов запущен: %s", ip.toString().c_str());

  unsigned long serverStart = millis();
  bool exitRequested = false;

  while (true) {
    logServer.handleClient();

    int key = readKeypad();
    if (key == KEY_OK && (millis() - serverStart > 500)) {
      exitRequested = true;
      break;
    }

    if (millis() - serverStart > 300000) {  // 5 минут
      LOG_I("⏰ Веб-сервер: таймаут");
      break;
    }
    delay(10);
  }

  if (exitRequested) {
    LOG_I("⏹ Выход по OK. Ждем отпускания...");
    while (readKeypad() == KEY_OK) {
      delay(50);
    }
  }

  logServer.stop();
  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);
  webLogsActive = false;
  LOG_I("📴 Веб-сервер остановлен");

  lastMenuActivity = millis();
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();
  exitMenuMode();
  LOG_I("🏠 Веб-сервер: выход на главный экран");
}

// ===================================================================
// НЕБЛОКИРУЮЩИЙ СЕРВЕР: обслуживание в loop()
// ===================================================================
void webLogsLoop() {
  if (!webLogsActive) return;

  logServer.handleClient();

  if (millis() - webLogsStartTime > 300000) {
    LOG_I("⏰ Веб-сервер: таймаут 5 мин");
    webLogsStop();
  }
}

void webLogsStop() {
  if (!webLogsActive) return;

  logServer.stop();
  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);
  webLogsActive = false;
  LOG_I("📴 Веб-сервер остановлен");

  extern void drawWebStatus();
  extern int8_t lastApDrawn;
  lastApDrawn = -1;
  drawWebStatus();
}