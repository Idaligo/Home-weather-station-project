#ifndef HUMIDITY_MODULE_H
#define HUMIDITY_MODULE_H

#include <TFT_eSPI.h>

class HumidityModule {
public:
  HumidityModule(TFT_eSPI& tft);
  void begin(float initialHum = 50.0);
  void update(float newHum);
  void draw();
  void forceUpdate();
  float getHumidity();  // Возвращает откалиброванное значение

  // ========== МЕТОДЫ КАЛИБРОВКИ ==========
  void setCalibration(float offset);
  float getCalibration() const;
  void resetCalibration();
  void saveCalibration();  // Сохранить калибровку в EEPROM
  void loadCalibration();  // Загрузить калибровку из EEPROM

private:
  TFT_eSPI& tft;
  float humidity;           // Сырое значение с датчика
  float calibrationOffset;  // Смещение калибровки

  char lastDrawnHumStr[24];  // было String
  uint16_t lastHumColor;
  bool isFirstDraw;

  // Спрайт (один для цифр + %)
  TFT_eSprite spriteHum;
  bool spritesInitialized;

  void initSprite();
  void drawHumidity();
  float getCalibratedHumidity() const;  // Вспомогательный метод

  // Константы позиционирования
  const int HUM_X = 290;
  const int HUM_Y = 164;

  // Адрес в EEPROM (20, чтобы не пересекаться с температурой на 10)
  const int EEPROM_ADDR_HUM = 20;
};

#endif  // HUMIDITY_MODULE_H