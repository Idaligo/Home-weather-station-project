#ifndef SCD40_MODULE_H
#define SCD40_MODULE_H

#include <TFT_eSPI.h>
#include <SparkFun_SCD4x_Arduino_Library.h>

class SCD40Module {
public:
  SCD40Module(TFT_eSPI& tft);  // Конструктор с передачей tft
  void requestMeasurement(SCD4x& sensor);
  void draw();         // Больше не нужен параметр tft
  void forceUpdate();  // Принудительное обновление
  uint16_t getCO2Color(uint16_t co2);

private:
  TFT_eSPI& tft;  // Ссылка на дисплей

  bool isNewDataAvailable;
  uint16_t co2Values[5];
  int filterIndex;

  // Кэширование для умного обновления
  uint16_t lastDisplayedValue;
  char lastDrawnStr[8];  // было String
  bool isFirstDraw;

  // Таймер для ограничения обновления (1 раз в минуту)
  unsigned long lastDrawTime;
  const unsigned long DRAW_INTERVAL = 60000;  // 60 секунд

  // Спрайты
  TFT_eSprite spriteCO2;  // Для цифр CO2
  bool spritesInitialized;

  void initSprites();
  void drawNumber();
  void drawUnit();
  uint16_t calculateAverage();
  void addSample(uint16_t sample);

  // Константы позиционирования
  const int CO2_X = 10;
  const int CO2_Y = 235;
  const int UNIT_X = 120;
  const int UNIT_Y = 253;
  static const char UNIT_LABEL[];  // определение в .cpp
};

#endif  // SCD40_MODULE_H