// web_module.h
#ifndef WEB_MODULE_H
#define WEB_MODULE_H

#include <Arduino.h>

// ==================== СОСТОЯНИЕ ВЕБ-СЕРВЕРА ====================
extern bool webLogsActive;
extern unsigned long webLogsStartTime;

// ==================== ПОДМЕНЮ «СКАЧАТЬ ЛОГИ» ====================
extern bool inLogsSubmenu;
extern int logsSubmenuItem;
extern int lastLogsItem;

#define LOGS_ITEMS_COUNT 3

// ==================== ФУНКЦИИ ====================
void drawLogsMenu();
void drawLogsMenuItem(int itemIndex, bool selected);
void drawLogsMenuNav();
void handleLogsMenu();

void webLogsBegin(bool showHints);
void webLogsLoop();
void webLogsStop();

#endif  // WEB_MODULE_H