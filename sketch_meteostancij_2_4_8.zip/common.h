// common.h
#ifndef COMMON_H
#define COMMON_H

#include <Arduino.h>
#include "openmeteo.h"
#include "yandex_weather.h"

// ==================== СТРУКТУРА ДАННЫХ ====================
struct DataStruct {
  float temperature;
  float humidity;
  float pressure;
  float battery_voltage;
};

// ==================== РЕЖИМЫ РАБОТЫ ====================
enum AppMode {
  MODE_MAIN,
  MODE_MENU,
  MODE_OTA,
  MODE_GRAPHS,
  MODE_STATS
};

// ==================== ИНФОРМАЦИЯ О ПОСЛЕДНЕМ СЕАНСЕ ====================
struct SessionInfo {
  bool valid = false;          // была ли запись
  bool success = false;        // OK / ошибка
  uint32_t unixTime = 0;       // когда (unix-timestamp RTC)
  uint8_t source = 255;        // 0=RF, 1=Open-Meteo, 2=Яндекс, 255=нет
  int httpCode = 0;            // HTTP-код
  int bytesRead = 0;           // прочитано байт
  int ramBefore = 0;           // RAM до сеанса
  int ramAfter = 0;            // RAM после сеанса
  int largestBlockBefore = 0;  // самый большой блок до
  int largestBlockAfter = 0;   // самый большой блок после
  int minRamEver = 999999;     // МИНИМАЛЬНЫЙ RAM за всё время
  int minBlockEver = 999999;   // МИНИМАЛЬНЫЙ Block за всё время
  char error[128] = "";        // текст ошибки (расширено до 128)
};

// ==================== СТРУКТУРА НАСТРОЕК WI-FI ====================  // ← НОВОЕ
struct WiFiConfig {
  uint8_t enabled;
  uint8_t intervalIdx;
  uint8_t forecastSource;
  uint8_t forecastSourceBeforeWiFiOff;
  uint8_t configured;
  char yandexApiKey[40];
  // ===== НОВОЕ: последний час/день сеанса =====
  uint8_t lastSessionHour;  // 0-23, 255 = ещё не было
  uint8_t lastSessionDay;   // 1-31, 0 = ещё не было
};

// ==================== ИНТЕРВАЛЫ WI-FI ====================  // ← НОВОЕ
#define WIFI_INTERVAL_COUNT 4
extern const uint32_t wifiIntervalsSec[WIFI_INTERVAL_COUNT];
// = {1800, 3600, 7200, 10800}  — 30м, 1ч, 2ч, 3ч

// ==================== СТРУКТУРА МЕСТОПОЛОЖЕНИЯ ====================
struct LocationConfig {
  float lat;  // широта
  float lon;  // долгота
};

// ===== МЕСТОПОЛОЖЕНИЕ =====
extern LocationConfig locationConfig;

// ==================== СТРУКТУРА НАСТРОЕК ПРОГНОЗА ====================
struct ForecastConfig {
  uint8_t forecastHourIdx;  // 0..5 (Через 1..6 часов)
  uint8_t yandexFormat;     // 0=часы, 1=части суток
};

// ===== НАСТРОЙКИ ПРОГНОЗА =====
extern ForecastConfig forecastConfig;

// ==================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ (extern) ====================
extern AppMode currentMode;
extern bool needFullRedraw;
extern int menuCurrentItem;
extern int menuDepth;
extern bool menuChanged;
extern DataStruct receivedData;
extern SessionInfo lastSession;

// ===== НАСТРОЙКИ WI-FI =====  // ← НОВОЕ
extern WiFiConfig wifiConfig;

// ===== СОСТОЯНИЕ СЕАНСОВ =====  // ← НОВОЕ
extern uint32_t lastWiFiSessionTime;  // unix-timestamp последнего сеанса (RAM)
extern bool wifiSessionInProgress;    // идёт ли сеанс сейчас
extern bool lastSessionFailed;        // результат последнего сеанса

// ===== ПЕРЕМЕННЫЕ OPEN-METEO (ТОЛЬКО ОБЪЯВЛЕНИЯ) =====
extern bool openMeteoFirstUpdate;
extern OpenMeteoData openMeteoData;
extern bool openMeteoIconsDrawn;

// ===== ЯНДЕКС ПОГОДА =====
extern YandexData yandexData;
extern bool yandexFirstUpdate;
extern bool yandexIconsDrawn;

extern bool webIndicatorDirty;

// ==================== МАССИВЫ ГРАФИКОВ (из graph_module) ====================
// Заполняются в graphAddHour()/graphAddDay(), читаются в graph_module
// (пока не нужны в main.ino, но могут пригодиться для stats_module)

// ==================== СТАТИСТИКА (из stats_module) ====================
// (пока не нужны extern, всё внутри stats_module.cpp)

// ==================== ПАРСИНГ CSV ====================
// Парсит строку "YYYY-MM-DD HH:MM:SS;T;H;P" (hourly, raw, month)
// или "date;T_avg;T_min;..." (daily — но для daily есть parseDailyLine).
// Возвращает true, если удалось выделить 3 числа после первой ';'.
// Заменяет ',' на '.' (европейский формат).
static inline bool parseCsvLine(const char* line, float* t, float* h, float* p) {
  const char* s = strchr(line, ';');
  if (!s) return false;
  s++;
  char buf[16];

  int i = 0;
  while (*s && *s != ';' && i < 15) buf[i++] = (*s == ',') ? '.' : *s, s++;
  buf[i] = '\0';
  *t = atof(buf);
  if (*s == ';') s++;

  i = 0;
  while (*s && *s != ';' && i < 15) buf[i++] = (*s == ',') ? '.' : *s, s++;
  buf[i] = '\0';
  *h = atof(buf);
  if (*s == ';') s++;

  i = 0;
  while (*s && *s != ';' && *s != '\n' && *s != '\r' && i < 15) buf[i++] = (*s == ',') ? '.' : *s, s++;
  buf[i] = '\0';
  *p = atof(buf);

  return true;
}

#endif  // COMMON_H