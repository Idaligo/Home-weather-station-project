// ===================================================================
// ПОДКЛЮЧЕНИЕ БИБЛИОТЕК
// ===================================================================

#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <EEPROM.h>
#include <Wire.h>
#include <RTClib.h>
#include <SparkFun_SCD4x_Arduino_Library.h>
#include <Adafruit_BME280.h>
#include <LittleFS.h>

// ===================================================================
// ПОДКЛЮЧЕНИЕ ПОЛЬЗОВАТЕЛЬСКИХ МОДУЛЕЙ
// ===================================================================

#include "debug_commands.h"
#include "rtc_module.h"
#include "temperature_module.h"
#include "humidity_module.h"
#include "pressure_module.h"
#include "SCD40_Module.h"
#include "BME280_Module.h"
#include "weather_forecast.h"
#include "weather_icons.h"
#include "trends_module.h"
#include "keypad_module.h"
#include "common.h"
#include "menu_module.h"
#include "openmeteo.h"
#include "yandex_weather.h"
#include "ota_module.h"
#include "sd_module.h"
#include "graph_module.h"
#include "stats_module.h"
#include "config.h"

bool openMeteoFirstUpdate = true;  // ← ОПРЕДЕЛЕНИЕ!
OpenMeteoData openMeteoData;       // ← ОПРЕДЕЛЕНИЕ!
bool openMeteoIconsDrawn = false;  // ← ОПРЕДЕЛЕНИЕ!
YandexData yandexData;
bool yandexFirstUpdate = true;
bool yandexIconsDrawn = false;
SessionInfo lastSession;

// ===================================================================
// НАСТРОЙКА СЕРИАЛЬНОГО ПОРТА
// ===================================================================

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

#ifndef TFT_WIDTH
#define TFT_WIDTH 320
#define TFT_HEIGHT 480
#endif

// ===================================================================
// ОБЪЯВЛЕНИЯ ПЕРЕМЕННЫХ ИЗ debug_commands.cpp
// ===================================================================

extern bool isDebugMode;
extern bool isDataFake;
extern float debugTemp;
extern float debugHum;
extern float debugPres;
extern bool isNoSignalWarningActive;
extern bool noDataMessageShown;
extern bool hasFirstPacket;
extern int lastWeatherCode;
extern int lastForecastCode;
extern char lastForecastText[64];
extern bool isBrightnessPendingSave;
extern unsigned long lastBrightnessChangeTime;
extern BrightnessConfig brightConfig;

// ===================================================================
// ГЛОБАЛЬНЫЕ ОБЪЕКТЫ
// ===================================================================

SPIClass hspi(HSPI);
TFT_eSPI tft = TFT_eSPI();

RTCModule rtcClock;
TemperatureModule tempBlock(tft);
HumidityModule humBlock(tft);
PressureModule presBlock(tft);
Trends trends;

TwoWire I2Cone = TwoWire(0);
TwoWire rtcWire = TwoWire(1);
SCD4x airSensor;
SCD40Module co2Module(tft);
bool isCo2Working = false;

Adafruit_BME280 bme;
BME280Module bmeModule(bme, tft);
bool isBmeWorking = false;

WeatherForecast forecast;

bool isRadioWorking = true;
RF24 radio(NRF_CE, NRF_CSN);
const uint64_t radioPipe = 0x1234567890LL;

// ===================================================================
// СТРУКТУРЫ ДАННЫХ
// ===================================================================

struct SensorData {
  float temperature;
  float humidity;
  float pressure;
};
/*
struct DataStruct {
  float temperature;
  float humidity;
  float pressure;
  float battery_voltage;
} receivedData;
*/
DataStruct receivedData;
// ===================================================================
// ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ
// ===================================================================

SensorData filteredData;

// ===== НАКОПИТЕЛИ ЗА ЧАС (для hourly archive) =====
float hourSumTemp = 0;
float hourSumHum = 0;
float hourSumPres = 0;
int hourMeasCount = 0;
uint8_t lastLoggedHour = 255;

// ===== НАКОПИТЕЛИ ЗА ДЕНЬ (для daily archive) =====
float daySumTemp = 0, dayMinTemp = 999, dayMaxTemp = -999;
float daySumHum = 0, dayMinHum = 999, dayMaxHum = -999;
float daySumPres = 0, dayMinPres = 9999, dayMaxPres = -999;
int dayMeasCount = 0;
int lastLoggedDay = -1;

unsigned long lastDisplayUpdate = 0;
unsigned long lastSerialPrint = 0;

bool newFilteredDataAvailable = false;
bool isDisplayUpdatePending = false;

float lastDisplayedTemp = -999;
float lastDisplayedHum = -999;
float lastDisplayedPres = -999;

int lastTempTrendCached = 999;
int lastHumTrendCached = 999;
int lastPresTrendCached = 999;
bool trendChanged = false;

static int lastIndicatorHeight = -1;

bool labelsDrawn = false;

// ===== ПЕРЕМЕННЫЕ ДЛЯ ИНДИКАТОРА РЕЖИМА =====
static unsigned long modeIndicatorStartTime = 0;
static bool modeIndicatorVisible = false;
static String modeIndicatorText = "";
static uint16_t modeIndicatorColor = TFT_GREEN;

// ===================================================================
// ПЕРЕМЕННЫЕ ПОДСВЕТКИ
// ===================================================================

bool autoBrightness = true;  // false = ручной, true = автоматический
bool autoBrightnessAvailable = false;

float lightSensorCalibA = 6.0;
float lightSensorCalibB = 0.0;
bool lightSensorCalibrated = false;

unsigned long lastAutoUpdate = 0;
unsigned long lastButtonActivity = 0;

#define LUX_BUFFER_SIZE 10
float luxBuffer[LUX_BUFFER_SIZE];
int luxBufferIndex = 0;
bool luxBufferFilled = false;

// ===================================================================
// КОНСТАНТЫ ПОДСВЕТКИ (переменные — остаются здесь)
// ===================================================================
int minAutoBrightness = 5;
int maxAutoBrightness = 255;
int autoTransitionStep = 1;

uint8_t brightness = 30;
uint8_t targetBrightness = 10;
bool isFading = false;
static uint8_t lastSavedBrightness = 255;

unsigned long lastSignalTime = 0;
static bool isSignalJustRestored = false;

// ===================================================================
// БУФЕРЫ ФИЛЬТРАЦИИ
// ===================================================================
float tempBuffer[BUFFER_SIZE];
float humBuffer[BUFFER_SIZE];
float presBuffer[BUFFER_SIZE];
int tempBufferIndex = 0;
int humBufferIndex = 0;
int presBufferIndex = 0;

// ===================================================================
// КОНСТАНТЫ ПОГОДЫ (переменные — остаются здесь)
// ===================================================================

float sensorHeight = 0.0;

float batteryMinVoltage = 6.35;
float batteryMaxVoltage = 8.2;

// ===================================================================
// ПЕРЕМЕННЫЕ КНОПОК
// ===================================================================

bool lastButtonUpState = HIGH;
bool lastButtonDownState = HIGH;
bool currentButtonUpState;
bool currentButtonDownState;

unsigned long lastDebounceTimeUp = 0;
unsigned long lastDebounceTimeDown = 0;

bool isIndicatorActive = false;
unsigned long lastButtonPressTime = 0;

static unsigned long previousFadeMillis = 0;

// ===================================================================
// ПРОТОТИПЫ ФУНКЦИЙ
// ===================================================================

void readAndProcessPacket();
void updateDisplayIfChanged();
void printDebugInfoIfChanged();
void drawStaticLabels(TFT_eSPI& tft);
void drawThreeSidedFrame(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color, int thickness, bool isRightSide);
void drawBatteryIndicator(TFT_eSPI& tft_ref, float voltage);
void drawMonoIcon(int x, int y, const unsigned char* iconData, uint16_t onColor, bool flipVertical);
void drawTrendIcon(int x, int y, int trend);
void clearWarningArea();
void showNoSignalWarning();
void handleBrightnessControl();
void drawIndicator();
void updateIndicatorVisibility();
void activateIndicator();
//void checkModeSwitch();
void blinkIndicator(int times);
float getAmbientLight();
float getMedianLux(float newLux);
float getFilteredAmbientLight();
int getTargetBrightnessFromLux(float lux);
float easeInOutCubic(float t);
float easeOutCubic(float t);
void updateBrightness();
uint16_t interpolateColor(uint16_t color1, uint16_t color2, float t);
uint16_t getTempColor(float temp);
uint16_t getHumColor(float hum);
uint16_t getPresColor(float pres);
void swap(float* a, float* b);
float getMedianFilterOptimized(float buffer[], float newValue, int& bufferIndex);
float hPaToPa(float hPa);
float PaTohPa(float Pa);
float hPaToMmHg(float hPa);
float correctPressureSimple(float pressure_hPa, float height_m);

// ===================================================================
// ИКОНКИ ТРЕНДОВ
// ===================================================================

const unsigned char epd_bitmap_free_icon_arrow_38[] PROGMEM = {
  0x00, 0x00, 0xfe, 0x00, 0x00, 0x00, 0x07, 0xff, 0xe0, 0x00, 0x00, 0x1f, 0xff, 0xf0, 0x00, 0x00,
  0x7f, 0xff, 0xfc, 0x60, 0x00, 0xff, 0xff, 0xfe, 0xe0, 0x01, 0xff, 0xff, 0xff, 0xe0, 0x03, 0xf8,
  0x0f, 0xff, 0xe0, 0x07, 0xc0, 0x01, 0xff, 0xe0, 0x0f, 0x00, 0x00, 0x7f, 0xf0, 0x0e, 0x00, 0x00,
  0x3f, 0xf0, 0x18, 0x00, 0x00, 0x7f, 0xf0, 0x30, 0x00, 0x00, 0xff, 0xf0, 0x20, 0x00, 0x01, 0xff,
  0xf0, 0x40, 0x00, 0x00, 0x7f, 0xf8, 0x40, 0x00, 0x00, 0x0f, 0xf8, 0x00, 0x00, 0x00, 0x01, 0xf8,
  0x00, 0x00, 0x00, 0x00, 0x78, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0x7e, 0x00,
  0x00, 0x00, 0x00, 0x7f, 0xc0, 0x00, 0x00, 0x00, 0x3f, 0xf8, 0x00, 0x00, 0x00, 0x3f, 0xfe, 0x00,
  0x00, 0x08, 0x3f, 0xfe, 0x00, 0x00, 0x08, 0x3f, 0xfc, 0x00, 0x00, 0x10, 0x3f, 0xf0, 0x00, 0x00,
  0x30, 0x1f, 0xf8, 0x00, 0x00, 0x60, 0x1f, 0xfc, 0x00, 0x00, 0xe0, 0x1f, 0xff, 0x00, 0x03, 0xc0,
  0x1f, 0xff, 0xe0, 0x1f, 0x80, 0x1c, 0xff, 0xff, 0xff, 0x00, 0x18, 0x7f, 0xff, 0xfe, 0x00, 0x00,
  0x1f, 0xff, 0xf8, 0x00, 0x00, 0x07, 0xff, 0xe0, 0x00, 0x00, 0x00, 0xff, 0x00, 0x00
};

const unsigned char epd_bitmap_free_icon_up_arrow_38[] PROGMEM = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x01, 0xf0, 0x00, 0x00, 0x00, 0x0f, 0xf0, 0x00, 0x00, 0x00,
  0x0f, 0xf8, 0x00, 0x00, 0x00, 0x07, 0xf8, 0x00, 0x00, 0x00, 0x07, 0xf8, 0x00, 0x00, 0x00, 0x07,
  0xf8, 0x00, 0x00, 0x00, 0x0f, 0xf8, 0x00, 0x00, 0x00, 0x1f, 0xd8, 0x00, 0x00, 0x00, 0x3f, 0x80,
  0x00, 0x00, 0x00, 0x3f, 0x00, 0x00, 0x00, 0x00, 0x7e, 0x00, 0x00, 0x00, 0x00, 0xfc, 0x00, 0x00,
  0x00, 0x01, 0xf8, 0x00, 0x00, 0x00, 0x03, 0xf0, 0x00, 0x00, 0x00, 0x0f, 0xe0, 0x00, 0x00, 0x00,
  0x1f, 0xc0, 0x00, 0x00, 0x00, 0x3f, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x00, 0x00, 0x00, 0x01, 0xf8,
  0x00, 0x00, 0x00, 0x07, 0xf0, 0x00, 0x00, 0x00, 0x1f, 0xc0, 0x00, 0x00, 0x00, 0x7f, 0x00, 0x00,
  0x00, 0x01, 0xf8, 0x00, 0x00, 0x00, 0x07, 0xc0, 0x00, 0x00, 0x00, 0x1c, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

// ===================================================================
// ФУНКЦИИ ЦВЕТА
// ===================================================================

uint16_t interpolateColor(uint16_t color1, uint16_t color2, float t) {
  t = constrain(t, 0.0f, 1.0f);
  uint8_t r1 = (color1 >> 11) & 0x1F;
  uint8_t g1 = (color1 >> 5) & 0x3F;
  uint8_t b1 = color1 & 0x1F;
  uint8_t r2 = (color2 >> 11) & 0x1F;
  uint8_t g2 = (color2 >> 5) & 0x3F;
  uint8_t b2 = color2 & 0x1F;
  uint8_t r = r1 + (r2 - r1) * t;
  uint8_t g = g1 + (g2 - g1) * t;
  uint8_t b = b1 + (b2 - b1) * t;
  return ((r & 0x1F) << 11) | ((g & 0x3F) << 5) | (b & 0x1F);
}

uint16_t getTempColor(float temp) {
  if (temp <= -50) return TFT_BLUE;
  if (temp >= 40) return TFT_MAGENTA;
  if (temp < 0) return interpolateColor(TFT_BLUE, TFT_CYAN, temp / 50.0f + 1.0f);
  if (temp < 15) return interpolateColor(TFT_CYAN, TFT_GREEN, (temp - 0) / 15.0f);
  if (temp < 20) return interpolateColor(TFT_GREEN, TFT_YELLOW, (temp - 15) / 5.0f);
  if (temp < 25) return interpolateColor(TFT_YELLOW, TFT_ORANGE, (temp - 20) / 5.0f);
  if (temp < 30) return interpolateColor(TFT_ORANGE, TFT_RED, (temp - 25) / 5.0f);
  return interpolateColor(TFT_RED, TFT_MAGENTA, (temp - 30) / 10.0f);
}

uint16_t getHumColor(float hum) {
  if (hum <= 0) return TFT_RED;
  if (hum >= 100) return TFT_BLUE;
  if (hum < 30) return interpolateColor(TFT_RED, TFT_ORANGE, hum / 30.0f);
  if (hum < 50) return interpolateColor(TFT_ORANGE, TFT_YELLOW, (hum - 30) / 20.0f);
  if (hum < 60) return interpolateColor(TFT_YELLOW, TFT_GREEN, (hum - 50) / 10.0f);
  if (hum < 70) return interpolateColor(TFT_GREEN, TFT_CYAN, (hum - 60) / 10.0f);
  return interpolateColor(TFT_CYAN, TFT_BLUE, (hum - 70) / 30.0f);
}

uint16_t getPresColor(float pres) {
  if (pres <= 650) return TFT_GREEN;
  if (pres >= 770) return TFT_RED;
  if (pres < 750) return interpolateColor(TFT_BLUE, TFT_CYAN, (pres - 650) / 100.0f);
  if (pres < 755) return interpolateColor(TFT_CYAN, TFT_GREEN, (pres - 750) / 5.0f);
  if (pres < 760) return interpolateColor(TFT_GREEN, TFT_YELLOW, (pres - 755) / 5.0f);
  return interpolateColor(TFT_YELLOW, TFT_RED, (pres - 760) / 10.0f);
}

// ===================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ===================================================================

void swap(float* a, float* b) {
  float temp = *a;
  *a = *b;
  *b = temp;
}

float hPaToPa(float hPa) {
  return hPa * 100.0;
}
float PaTohPa(float Pa) {
  return Pa / 100.0;
}
float hPaToMmHg(float hPa) {
  return hPa * 0.750062;
}

float correctPressureSimple(float pressure_hPa, float height_m) {
  return pressure_hPa + (height_m / 8.4);
}

float easeInOutCubic(float t) {
  t = constrain(t, 0.0f, 1.0f);
  if (t < 0.5f) return 4.0f * t * t * t;
  return 1.0f - pow(-2.0f * t + 2.0f, 3.0f) / 2.0f;
}

float easeOutCubic(float t) {
  t = constrain(t, 0.0f, 1.0f);
  return 1.0f - pow(1.0f - t, 3.0f);
}

// ===================================================================
// ФИЛЬТРАЦИЯ
// ===================================================================

float getMedianFilterOptimized(float buffer[], float newValue, int& bufferIndex) {
  buffer[bufferIndex] = newValue;
  bufferIndex = (bufferIndex + 1) % BUFFER_SIZE;

  float tempBuffer[BUFFER_SIZE];
  int validCount = 0;

  for (int i = 0; i < BUFFER_SIZE; i++) {
    if (buffer[i] != 0.0) {
      tempBuffer[validCount] = buffer[i];
      validCount++;
    }
  }

  if (validCount == 0 || validCount == 1) return newValue;
  if (validCount == 2) return (tempBuffer[0] + tempBuffer[1]) / 2.0;

  int n = validCount;
  int k = n / 2;
  int left = 0, right = n - 1;

  while (left <= right) {
    int pivotIndex = (left + right) / 2;
    float pivotValue = tempBuffer[pivotIndex];
    swap(&tempBuffer[pivotIndex], &tempBuffer[right]);
    int storeIndex = left;
    for (int i = left; i < right; i++) {
      if (tempBuffer[i] < pivotValue) {
        swap(&tempBuffer[storeIndex], &tempBuffer[i]);
        storeIndex++;
      }
    }
    swap(&tempBuffer[storeIndex], &tempBuffer[right]);
    if (storeIndex == k) return tempBuffer[storeIndex];
    else if (storeIndex < k) left = storeIndex + 1;
    else right = storeIndex - 1;
  }
  return tempBuffer[k];
}

// ===================================================================
// ОТРИСОВКА
// ===================================================================

void drawMonoIcon(int x, int y, const unsigned char* iconData, uint16_t onColor, bool flipVertical = false) {
  const int width = 38;
  const int height = 38;
  const int bytesPerRow = (width + 7) / 8;

  for (int row = 0; row < height; row++) {
    int drawRow = flipVertical ? (height - 1 - row) : row;
    for (int col = 0; col < width; col++) {
      int byteIndex = row * bytesPerRow + (col / 8);
      unsigned char byte = pgm_read_byte(&iconData[byteIndex]);
      bool pixelOn = byte & (0x80 >> (col % 8));
      if (pixelOn) {
        tft.drawPixel(x + col, y + drawRow, onColor);
      }
    }
  }
}

void drawTrendIcon(int x, int y, int trend) {
  tft.fillRect(x, y, 38, 38, TFT_BLACK);
  const unsigned char* iconPtr = nullptr;
  uint16_t color = TFT_WHITE;
  bool flip = false;

  switch (trend) {
    case 2:
      iconPtr = epd_bitmap_free_icon_up_arrow_38;
      color = TFT_RED;
      flip = false;
      break;
    case 1:
      iconPtr = epd_bitmap_free_icon_up_arrow_38;
      color = TFT_GREEN;
      flip = false;
      break;
    case -2:
      iconPtr = epd_bitmap_free_icon_up_arrow_38;
      color = TFT_RED;
      flip = true;
      break;
    case -1:
      iconPtr = epd_bitmap_free_icon_up_arrow_38;
      color = TFT_GREEN;
      flip = true;
      break;
    case 0:
      iconPtr = epd_bitmap_free_icon_arrow_38;
      color = TFT_YELLOW;
      flip = false;
      break;
  }

  if (iconPtr) {
    drawMonoIcon(x, y, iconPtr, color, flip);
  }
}

void drawThreeSidedFrame(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color, int thickness, bool isRightSide) {
  tft.fillRect(x, y, w, thickness, color);
  tft.fillRect(x, y + h - thickness, w, thickness, color);
  if (isRightSide) {
    tft.fillRect(x + w - thickness, y, thickness, h, color);
  } else {
    tft.fillRect(x, y, thickness, h, color);
  }
}

void drawStaticLabels(TFT_eSPI& tft) {
  const uint16_t FRAME_COLOR = TFT_WHITE;
  const int FRAME_THICKNESS = 1;
  const int FRAME_HEIGHT = 70;
  const int LEFT_FRAME_WIDTH = 165;
  const int RIGHT_FRAME_WIDTH = 195;
  const int LEFT_START_X = 10;
  const int RIGHT_START_X = 285;
  const int LEFT_Y_1 = 61, LEFT_Y_2 = 133, LEFT_Y_3 = 205;
  const int RIGHT_Y_1 = 61, RIGHT_Y_2 = 133, RIGHT_Y_3 = 205;
  const int NEW_FRAME_SIZE = 106;
  const int NEW_FRAME_X = 177;
  const int NEW_FRAME_Y_1 = 61;
  const int NEW_FRAME_Y_2 = 169;

  tft.drawRect(NEW_FRAME_X, NEW_FRAME_Y_1, NEW_FRAME_SIZE, NEW_FRAME_SIZE, FRAME_COLOR);
  tft.drawRect(NEW_FRAME_X, NEW_FRAME_Y_2, NEW_FRAME_SIZE, NEW_FRAME_SIZE, FRAME_COLOR);

  drawThreeSidedFrame(LEFT_START_X, LEFT_Y_1, LEFT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, true);
  drawThreeSidedFrame(LEFT_START_X, LEFT_Y_2, LEFT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, true);
  drawThreeSidedFrame(LEFT_START_X, LEFT_Y_3, LEFT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, true);
  drawThreeSidedFrame(RIGHT_START_X, RIGHT_Y_1, RIGHT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, false);
  drawThreeSidedFrame(RIGHT_START_X, RIGHT_Y_2, RIGHT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, false);
  drawThreeSidedFrame(RIGHT_START_X, RIGHT_Y_3, RIGHT_FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR, FRAME_THICKNESS, false);

  struct LabelData {
    const char* text;
    int16_t xPos;
    int16_t yPos;
    uint8_t fontSize;
  };

  const LabelData labels[] = {
    { "Дом", 50, 33, 28 },
    { "Температура", 15, 64, 24 },
    { "Влажность", 15, 136, 24 },
    { "СО2", 50, 208, 24 },
    { "Улица", 350, 33, 28 },
    { "Температура", 310, 64, 24 },
    { "Влажность", 325, 136, 24 },
    { "Давление", 335, 208, 24 }
  };

  uint8_t currentFontSize = 0;
  for (int i = 0; i < 8; i++) {
    if (labels[i].fontSize != currentFontSize) {
      tft.loadFont("cambriai" + String(labels[i].fontSize));
      currentFontSize = labels[i].fontSize;
    }
    tft.setTextColor(TFT_ORANGE);
    tft.setCursor(labels[i].xPos, labels[i].yPos);
    tft.print(labels[i].text);
    delay(1);
  }
  tft.unloadFont();
}

void drawBatteryIndicator(TFT_eSPI& tft_ref, float voltage) {
  const int width = 40;
  const int height = 10;
  const int border = 1;

  float v = constrain(voltage, batteryMinVoltage, batteryMaxVoltage);
  float level = (v - batteryMinVoltage) / (batteryMaxVoltage - batteryMinVoltage);

  uint16_t fillColor;
  uint16_t borderColor = TFT_WHITE;

  if (level <= 0.05) {
    fillColor = TFT_BLACK;
    borderColor = TFT_RED;
  } else if (level <= 0.25) {
    fillColor = TFT_RED;
  } else if (level <= 0.5) {
    fillColor = TFT_YELLOW;
  } else {
    fillColor = TFT_GREEN;
  }

  tft_ref.fillRect(BATTERY_X, BATTERY_Y, width + border, height + border, TFT_BLACK);
  tft_ref.drawRect(BATTERY_X, BATTERY_Y, width, height, borderColor);
  tft_ref.fillRect(BATTERY_X + width - 1, BATTERY_Y + height / 2 - 2, 3, 5, borderColor);

  if (level > 0.05) {
    int fillWidth = (width - border * 2) * level;  // ← Убрал - 2
    if (fillWidth > width - border * 2) fillWidth = width - border * 2;
    tft_ref.fillRect(BATTERY_X + border, BATTERY_Y + border, fillWidth, height - border * 2, fillColor);
  }
}

void clearWarningArea() {
  tft.fillRect(WARNING_X - 2, WARNING_Y - 2, WARNING_WIDTH + 4, WARNING_HEIGHT + 4, TFT_BLACK);
}

void showNoSignalWarning() {
  clearWarningArea();
  tft.setTextColor(TFT_RED);
  tft.setCursor(WARNING_X + 2, WARNING_Y + 2);
  tft.loadFont("cambriai24", LittleFS);
  tft.print("Н С");
  tft.unloadFont();
  isNoSignalWarningActive = true;
}

// ===================================================================
// ПОДСВЕТКА
// ===================================================================

float getAmbientLight() {
  int raw = analogRead(LIGHT_SENSOR_PIN);
  float voltage = raw * (3.3 / 4095.0);
  float current = voltage / 10000.0;
  float microAmps = current * 1000000.0;
  float rawLux = microAmps * 2.0;
  float calibratedLux = rawLux * lightSensorCalibA + lightSensorCalibB;
  return constrain(calibratedLux, 0, 1000);
}

float getMedianLux(float newLux) {
  static float luxHistory[7];
  static int histIndex = 0;
  static bool filled = false;

  luxHistory[histIndex] = newLux;
  histIndex = (histIndex + 1) % 7;
  if (histIndex == 0) filled = true;

  float temp[7];
  int count = filled ? 7 : histIndex;
  for (int i = 0; i < count; i++) temp[i] = luxHistory[i];

  for (int i = 0; i < count - 1; i++) {
    for (int j = 0; j < count - i - 1; j++) {
      if (temp[j] > temp[j + 1]) {
        float t = temp[j];
        temp[j] = temp[j + 1];
        temp[j + 1] = t;
      }
    }
  }
  return temp[count / 2];
}

float getFilteredAmbientLight() {
  int raw = analogRead(LIGHT_SENSOR_PIN);
  float voltage = raw * (3.3 / 4095.0);
  float current = voltage / 10000.0;
  float microAmps = current * 1000000.0;
  float rawLux = microAmps * 2.0;
  float calibratedLux = rawLux * lightSensorCalibA + lightSensorCalibB;
  calibratedLux = constrain(calibratedLux, 0, 1000);

  luxBuffer[luxBufferIndex] = calibratedLux;
  luxBufferIndex = (luxBufferIndex + 1) % LUX_BUFFER_SIZE;

  float sum = 0;
  int validCount = luxBufferFilled ? LUX_BUFFER_SIZE : luxBufferIndex;
  for (int i = 0; i < validCount; i++) sum += luxBuffer[i];
  if (validCount > 0) calibratedLux = sum / validCount;
  if (luxBufferIndex == 0 && !luxBufferFilled) luxBufferFilled = true;
  return getMedianLux(calibratedLux);
}

int getTargetBrightnessFromLux(float lux) {
  lux = constrain(lux, 0, 1000);

  if (lux <= LUX_DARK) return BRIGHT_DARK;
  if (lux <= LUX_TWILIGHT) {
    float t = (lux - LUX_DARK) / (LUX_TWILIGHT - LUX_DARK);
    t = easeInOutCubic(t);
    return BRIGHT_DARK + (BRIGHT_TWILIGHT - BRIGHT_DARK) * t;
  }
  if (lux <= LUX_ROOM) {
    float t = (lux - LUX_TWILIGHT) / (LUX_ROOM - LUX_TWILIGHT);
    t = easeInOutCubic(t);
    return BRIGHT_TWILIGHT + (BRIGHT_ROOM - BRIGHT_TWILIGHT) * t;
  }
  if (lux <= LUX_BRIGHT) {
    float t = (lux - LUX_ROOM) / (LUX_BRIGHT - LUX_ROOM);
    t = easeInOutCubic(t);
    return BRIGHT_ROOM + (BRIGHT_BRIGHT - BRIGHT_ROOM) * t;
  }
  float t = constrain((lux - LUX_BRIGHT) / (500 - LUX_BRIGHT), 0, 1);
  t = easeOutCubic(t);
  return BRIGHT_BRIGHT + (maxAutoBrightness - BRIGHT_BRIGHT) * t;
}

void updateBrightness() {
  if (autoBrightness && autoBrightnessAvailable) {
    if (millis() - lastAutoUpdate >= AUTO_UPDATE_INTERVAL) {
      lastAutoUpdate = millis();
      float lux = getFilteredAmbientLight();
      int newTarget = getTargetBrightnessFromLux(lux);
      int diff = abs(newTarget - targetBrightness);

      if (diff > 15) {
        targetBrightness = newTarget;
        isFading = true;
      } else if (diff > 8) {
        static float lastLux[3] = { 0, 0, 0 };
        static int luxIndex = 0;
        lastLux[luxIndex] = lux;
        luxIndex = (luxIndex + 1) % 3;
        bool stable = true;
        for (int i = 0; i < 3; i++) {
          if (abs(lastLux[i] - lux) > 2) stable = false;
        }
        if (stable || diff > 12) {
          targetBrightness = newTarget;
          isFading = true;
        }
      }
    }
  }

  if (isFading && (millis() - previousFadeMillis >= FADE_INTERVAL)) {
    previousFadeMillis = millis();
    float diff = targetBrightness - brightness;
    float step;
    if (autoBrightness) {
      float absDiff = abs(diff);
      if (absDiff > 50) step = diff * 0.15f;
      else if (absDiff > 20) step = diff * 0.08f;
      else step = diff * 0.04f;
      if (abs(step) < 0.3f && abs(diff) > 0) step = (diff > 0) ? 0.5f : -0.5f;
    } else {
      step = diff * 0.1f;
    }
    if (abs(step) < 0.3f && abs(diff) < 1.0f) {
      brightness = targetBrightness;
      isFading = false;
    } else {
      brightness += step;
    }
    brightness = constrain(brightness, 0, 255);
    analogWrite(LED_PWM_PIN, (int)brightness);

    if (isIndicatorActive && !autoBrightness) {
      drawIndicator();
    }
  }
}

// ===================================================================
// УПРАВЛЕНИЕ ЯРКОСТЬЮ (С ПЕРЕКЛЮЧЕНИЕМ UP+DOWN)
// ===================================================================

// ===================================================================
// УПРАВЛЕНИЕ ЯРКОСТЬЮ
// ===================================================================

void handleBrightnessControl() {
  static bool upPressed = false;
  static bool downPressed = false;

  int key = readKeypadWithRepeat();

  if (key == KEY_UP) {
    upPressed = true;
  } else if (key == KEY_DOWN) {
    downPressed = true;
  } else if (key == KEY_NONE) {
    upPressed = false;
    downPressed = false;
  }

  if (upPressed && downPressed) {
    static unsigned long lastSwitchTime = 0;
    if (millis() - lastSwitchTime > 1000) {
      autoBrightness = !autoBrightness;

      // ===== СИНХРОНИЗАЦИЯ С brightConfig =====
      brightConfig.autoMode = autoBrightness;
      saveBrightnessConfig();  // Сохраняем в EEPROM

      lastSwitchTime = millis();
      blinkIndicator(3);

      if (autoBrightness) {
        isIndicatorActive = false;
        drawIndicator();
        float lux = getFilteredAmbientLight();
        targetBrightness = getTargetBrightnessFromLux(lux);
        isFading = true;
        LOG_I("🌞 Режим: AUTO");
        showModeIndicator("А", TFT_GREEN);
      } else {
        uint8_t savedBrightness = EEPROM.read(BRIGHTNESS_EEPROM_ADDR);
        if (savedBrightness != 0xFF && savedBrightness != 0 && savedBrightness <= 255) {
          targetBrightness = savedBrightness;
          brightness = savedBrightness;
          isFading = true;
          analogWrite(LED_PWM_PIN, brightness);
          lastSavedBrightness = savedBrightness;
        }
        lastButtonActivity = millis();
        isIndicatorActive = true;
        drawIndicator();
        LOG_I("✋ Режим: MANUAL");
        showModeIndicator("Р", TFT_YELLOW);
      }
    }
    upPressed = false;
    downPressed = false;
    return;
  }

  // ===== AUTO РЕЖИМ — ВСЁ ЗАБЛОКИРОВАНО =====
  if (autoBrightness) {
    return;
  }

  // ===== MANUAL РЕЖИМ: ТОЛЬКО UP И DOWN =====
  if (key != KEY_NONE) {
    bool changed = false;

    switch (key) {
      case KEY_UP:
        if (!downPressed) {
          targetBrightness = min(255, targetBrightness + 5);
          isFading = true;
          changed = true;
        }
        break;

      case KEY_DOWN:
        if (!upPressed) {
          targetBrightness = max(0, targetBrightness - 5);
          isFading = true;
          changed = true;
        }
        break;

      case KEY_LEFT:
        break;

      case KEY_RIGHT:
        break;

      case KEY_OK:
        break;
    }

    if (changed) {
      activateIndicator();
    }
  }
}

// ===== Индикатор режима (ИСЧЕЗАЕТ ЧЕРЕЗ 3 СЕКУНДЫ) =====
void showModeIndicator(const char* text, uint16_t color) {
  // Запоминаем данные
  modeIndicatorText = String(text);
  modeIndicatorColor = color;
  modeIndicatorStartTime = millis();
  modeIndicatorVisible = true;

  // Рисуем индикатор
  tft.fillRect(1, 1, 20, 25, TFT_BLACK);
  tft.loadFont("cambriai24", LittleFS);
  tft.setTextColor(color, TFT_BLACK);
  tft.setCursor(2, 2);
  tft.print(text);
  tft.unloadFont();
}

// ===== ОБНОВЛЕНИЕ ИНДИКАТОРА РЕЖИМА (ВЫЗЫВАТЬ В LOOP) =====
void updateModeIndicator() {
  // Если индикатор виден и прошло больше 3 секунд — скрываем
  if (modeIndicatorVisible && (millis() - modeIndicatorStartTime > 3000)) {
    tft.fillRect(1, 1, 20, 25, TFT_BLACK);
    modeIndicatorVisible = false;
    modeIndicatorText = "";
  }
}

void drawIndicator() {
  if (!isIndicatorActive || autoBrightness) {
    if (lastIndicatorHeight != -1) {
      tft.fillRect(INDICATOR_X - 2, INDICATOR_Y - 2,
                   INDICATOR_WIDTH + 4, INDICATOR_HEIGHT + 4, TFT_BLACK);
      lastIndicatorHeight = -1;
    }
    return;
  }

  int currentHeight;

  // ===== ПРИ ЯРКОСТИ >= 244 — ПОЛНАЯ ПОЛОСКА =====
  // (244 даёт 114, а нам нужно 120)
  if (brightness >= 244) {
    currentHeight = INDICATOR_HEIGHT;  // 120
  } else if (brightness <= 5) {
    currentHeight = 0;
  } else {
    currentHeight = map(brightness, 0, 255, 0, INDICATOR_HEIGHT);
  }
  // =============================================

  if (currentHeight == lastIndicatorHeight) {
    return;
  }

  tft.fillRect(INDICATOR_X - 2, INDICATOR_Y - 2,
               INDICATOR_WIDTH + 4, INDICATOR_HEIGHT + 4, TFT_BLACK);

  if (currentHeight > 0) {
    tft.fillRect(INDICATOR_X,
                 INDICATOR_Y + INDICATOR_HEIGHT - currentHeight,
                 INDICATOR_WIDTH, currentHeight, INDICATOR_COLOR);
  }
  tft.drawRect(INDICATOR_X - 1, INDICATOR_Y - 1,
               INDICATOR_WIDTH + 2, INDICATOR_HEIGHT + 2, TFT_WHITE);

  lastIndicatorHeight = currentHeight;
}

void activateIndicator() {
  if (!autoBrightness) {
    lastButtonActivity = millis();
    if (!isIndicatorActive) {
      isIndicatorActive = true;
      drawIndicator();
    }
  }
}

void updateIndicatorVisibility() {
  if (!autoBrightness && isIndicatorActive) {
    if (millis() - lastButtonActivity > INDICATOR_HIDE_DELAY) {
      isIndicatorActive = false;
      tft.fillRect(INDICATOR_X - 2, INDICATOR_Y - 2,
                   INDICATOR_WIDTH + 4, INDICATOR_HEIGHT + 4, TFT_BLACK);
      if (!autoBrightness && brightness != lastSavedBrightness) {
        EEPROM.write(BRIGHTNESS_EEPROM_ADDR, brightness);
        if (EEPROM.commit()) {
          lastSavedBrightness = brightness;
        }
      }
    }
  }
}

void blinkIndicator(int times) {
  // Запоминаем состояние
  bool wasActive = isIndicatorActive;
  int savedBrightness = brightness;

  // Если индикатор был активен — скрываем его перед миганием
  if (wasActive) {
    tft.fillRect(INDICATOR_X - 2, INDICATOR_Y - 2,
                 INDICATOR_WIDTH + 4, INDICATOR_HEIGHT + 4, TFT_BLACK);
  }

  // Мигаем
  for (int i = 0; i < times; i++) {
    // ВКЛ
    tft.fillRect(INDICATOR_X, INDICATOR_Y,
                 INDICATOR_WIDTH, INDICATOR_HEIGHT, INDICATOR_COLOR);
    tft.drawRect(INDICATOR_X - 1, INDICATOR_Y - 1,
                 INDICATOR_WIDTH + 2, INDICATOR_HEIGHT + 2, TFT_WHITE);
    delay(150);

    // ВЫКЛ
    tft.fillRect(INDICATOR_X - 2, INDICATOR_Y - 2,
                 INDICATOR_WIDTH + 4, INDICATOR_HEIGHT + 4, TFT_BLACK);
    delay(150);
  }

  // Подсветка остаётся на своей яркости
  // (не меняется, только индикатор мигает)

  // Восстанавливаем состояние индикатора
  if (wasActive) {
    isIndicatorActive = true;
    lastIndicatorHeight = -1;
    drawIndicator();
  } else {
    isIndicatorActive = false;
    lastIndicatorHeight = -1;
  }
}

// ===================================================================
// ОБРАБОТКА ДАННЫХ
// ===================================================================

void readAndProcessPacket() {
  filteredData.temperature = getMedianFilterOptimized(tempBuffer, receivedData.temperature, tempBufferIndex);
  filteredData.humidity = getMedianFilterOptimized(humBuffer, receivedData.humidity, humBufferIndex);
  float filteredPres_hPa = getMedianFilterOptimized(presBuffer, receivedData.pressure, presBufferIndex);
  filteredData.pressure = hPaToMmHg(correctPressureSimple(filteredPres_hPa, sensorHeight));

  // ===== ПЕРЕДАЁМ СЫРЫЕ ЗНАЧЕНИЯ В МОДУЛИ =====
  tempBlock.update(filteredData.temperature);
  humBlock.update(filteredData.humidity);
  presBlock.update(filteredData.pressure);

  // ===== БЕРЁМ ОТКАЛИБРОВАННЫЕ ДЛЯ ПРОГНОЗА И ТРЕНДОВ =====
  float calTemp = tempBlock.getTemperature();
  float calHum = humBlock.getHumidity();
  float calPres = presBlock.getPressure();

  // ===== ЗАЩИТА ОТ NaN =====
  // Если датчик вернул NaN (нет сигнала, ошибка, плохой контакт) —
  // не накапливаем в hourSum*/daySum*/raw. Иначе NaN попадёт в файлы.
  if (isnan(calTemp) || isnan(calHum) || isnan(calPres)) {
    LOG_W("⚠️ NaN от датчиков — пропуск пакета");
    return;
  }

  forecast.addMeasurement(calTemp, calHum, calPres);
  hasFirstPacket = true;

  trends.addData(calTemp, calHum, calPres);
  trends.updateTrends();

  int newTempTrend = trends.getTempTrend();
  int newHumTrend = trends.getHumTrend();
  int newPresTrend = trends.getPresTrend();

  if (newTempTrend != lastTempTrendCached) {
    lastTempTrendCached = newTempTrend;
    drawTrendIcon(441, 87, lastTempTrendCached);
    LOG_D("🔄 T тренд: %d (скорость %.4f°/с)", newTempTrend, trends.getTempSpeed());
  }

  if (newHumTrend != lastHumTrendCached) {
    lastHumTrendCached = newHumTrend;
    drawTrendIcon(441, 159, lastHumTrendCached);
    LOG_D("🔄 H тренд: %d (скорость %.4f%%/с)", newHumTrend, trends.getHumSpeed());
  }

  if (newPresTrend != lastPresTrendCached) {
    lastPresTrendCached = newPresTrend;
    drawTrendIcon(441, 230, lastPresTrendCached);
    LOG_D("🔄 P тренд: %d (скорость %.4f ммHg/с)", newPresTrend, trends.getPresSpeed());
  }

  trends.resetTrendChangedFlags();

  newFilteredDataAvailable = true;

  if (isCo2Working) {
    co2Module.requestMeasurement(airSensor);
  }
  bmeModule.update();

  // ===== SD: калиброванные данные в буфер =====
  if (sdLoggingEnabled) {
    saveRawData(calTemp, calHum, calPres);
  }

  // ===== Накопление средних за час =====
  hourSumTemp += calTemp;
  hourSumHum += calHum;
  hourSumPres += calPres;
  hourMeasCount++;

  // ===== Накопление за день (min/max/avg) =====
  daySumTemp += calTemp;
  daySumHum += calHum;
  daySumPres += calPres;
  if (calTemp < dayMinTemp) dayMinTemp = calTemp;
  if (calTemp > dayMaxTemp) dayMaxTemp = calTemp;
  if (calHum < dayMinHum) dayMinHum = calHum;
  if (calHum > dayMaxHum) dayMaxHum = calHum;
  if (calPres < dayMinPres) dayMinPres = calPres;
  if (calPres > dayMaxPres) dayMaxPres = calPres;
  dayMeasCount++;
}

// ===================================================================
// ИНДИКАТОР SD НА ГЛАВНОМ ЭКРАНЕ
// ===================================================================
// Переменная sdLoggingEnabled объявлена в sd_module.cpp (extern в sd_module.h)

int8_t lastSdStatusDrawn = -1;  // -1 = ещё не рисовали (глобальная для extern)

void drawSdStatus() {
  int8_t status;
  uint16_t color;
  const char* text;

  if (!sdLoggingEnabled) {
    // Логирование отключено — не выводим индикатор вообще (очищаем область)
    if (lastSdStatusDrawn != 0) {
      tft.fillRect(1, 15, 60, 10, TFT_BLACK);
      lastSdStatusDrawn = 0;
    }
    return;
  } else if (sdReady) {
    status = 1;
    text = "SD:OK";
    color = TFT_GREEN;
  } else {
    status = 2;
    text = "SD:ERR";
    color = TFT_RED;
  }

  // Если статус не изменился — не перерисовываем (избегаем мерцания)
  if (status == lastSdStatusDrawn) return;
  lastSdStatusDrawn = status;

  // Очищаем область под текст (x=1, y=15, ширина ~60, высота ~10)
  tft.fillRect(1, 15, 60, 10, TFT_BLACK);

  // Рисуем текст
  tft.setTextSize(1);
  tft.setCursor(1, 15);
  tft.setTextColor(color, TFT_BLACK);
  tft.print(text);
}

// ===================================================================
// ИНДИКАТОР ВЕБ-СЕРВЕРА (AP) НА ГЛАВНОМ ЭКРАНЕ
// ===================================================================
extern bool webLogsActive;  // из menu_module.cpp
int8_t lastApDrawn = -1;    // -1 = ещё не рисовали (глобальная, для сброса из redrawMainScreen)

void drawWebStatus() {
  int8_t status = webLogsActive ? 1 : 0;
  if (status == lastApDrawn) return;
  lastApDrawn = status;

  // Позиция AP — справа от WEB/SENS с отступом 4 px
  int sourceWidth = (wifiConfig.forecastSource == 0) ? (4 * 6) : (3 * 6);
  int apX = 1 + sourceWidth + 4;

  // Стереть область AP (2 символа + запас)
  tft.fillRect(apX, 1, 24, 10, TFT_BLACK);

  if (webLogsActive) {
    tft.setCursor(apX, 1);
    tft.setTextSize(1);
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.print("AP");
  }
}

void updateDisplayIfChanged() {
  static float lastTempDrawn = -999;
  static float lastHumDrawn = -999;
  static float lastPresDrawn = -999;
  static bool lastIsNight = false;
  static bool firstRun = true;

  // ===== СТАТИЧЕСКИЕ ПЕРЕМЕННЫЕ ДЛЯ ПРОГНОЗА =====
  static bool labelsDrawn = false;
  static bool noDataMessageShown = false;

  // ===== ДОПОЛНИТЕЛЬНЫЕ СТАТИЧЕСКИЕ ПЕРЕМЕННЫЕ ДЛЯ ОТСЛЕЖИВАНИЯ ИЗМЕНЕНИЙ =====
  static int lastOpenMeteoWeatherCode = -1;
  static int lastOpenMeteoForecastCode = -1;
  static char lastOpenMeteoForecastText[64] = "";
  static char lastOmWarning[48] = "";

  bool shouldUpdate = false;

  // ===== ПРИНУДИТЕЛЬНАЯ ПЕРЕРИСОВКА ДЛЯ OPEN-METEO =====
  if (wifiConfig.forecastSource == 1 && openMeteoData.isValid && !openMeteoIconsDrawn) {
    openMeteoIconsDrawn = true;
    needFullRedraw = true;
    LOG_D("🎨 Первое обновление иконок Open-Meteo!");
  }

  // ← ДОБАВЬ рядом — для Яндекса
  if (wifiConfig.forecastSource == 2 && yandexData.isValid && !yandexIconsDrawn) {
    yandexIconsDrawn = true;
    needFullRedraw = true;
    LOG_D("🎨 Первое обновление иконок Яндекса!");
  }
  // =========================================================
  // ===== ОБНОВЛЕНИЕ ИНДИКАТОРА SD =====
  drawSdStatus();
  drawWebStatus();
  // ============================================================
  // 1. ОБНОВЛЕНИЕ ОСНОВНЫХ ПОКАЗАТЕЛЕЙ
  // ============================================================
  if (newFilteredDataAvailable || isDisplayUpdatePending) {
    if (isDisplayUpdatePending) {
      lastTempDrawn = -999;
      lastHumDrawn = -999;
      lastPresDrawn = -999;
      isDisplayUpdatePending = false;
    }

    if (abs(filteredData.temperature - lastTempDrawn) > 0.1) {
      lastTempDrawn = filteredData.temperature;
      shouldUpdate = true;
    }
    if (abs(filteredData.humidity - lastHumDrawn) > 0.1) {
      lastHumDrawn = filteredData.humidity;
      shouldUpdate = true;
    }
    if (abs(filteredData.pressure - lastPresDrawn) > 1.0) {
      lastPresDrawn = filteredData.pressure;
      shouldUpdate = true;
    }
    newFilteredDataAvailable = false;
  }

  if (shouldUpdate) {
    tempBlock.draw();
    humBlock.draw();
    presBlock.draw();

    if (isCo2Working) {
      co2Module.draw();
    } else {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setCursor(10, 242);
      tft.print("ERR: CO2");
    }

    if (isBmeWorking) {
      bmeModule.update();
      bmeModule.draw();
    } else {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setCursor(10, 160);
      tft.print("ERR: BME280");
    }
    drawBatteryIndicator(tft, receivedData.battery_voltage);
  }

  // ============================================================
  // 2. ПРОГНОЗ ПОГОДЫ
  // ============================================================

  // ===== ВЕТКА 1: OPEN-METEO =====
  if (wifiConfig.forecastSource == 1 && openMeteoData.isValid) {

    int currentWeather = mapOpenMeteoToWeatherCode(openMeteoData.currentWeatherCode);

    uint8_t hourIdx = forecastConfig.forecastHourIdx;
    if (hourIdx >= 6) hourIdx = 5;
    int forecastCode = mapOpenMeteoToWeatherCode(openMeteoData.forecastWeatherCode[hourIdx]);
    const char* forecastText = getWeatherDescription(openMeteoData.forecastWeatherCode[hourIdx]);

    // ===== ОПРЕДЕЛЯЕМ НОЧЬ =====
    bool isNight = false;
    DateTime now = rtcClock.getTime();
    int hour = now.hour();
    if (hour >= 0 && hour <= 23) {
      isNight = (hour < 6 || hour >= 20);
    } else {
      struct tm timeinfo;
      if (getLocalTime(&timeinfo, 1)) {
        hour = timeinfo.tm_hour;
        isNight = (hour < 6 || hour >= 20);
      } else {
        isNight = false;
      }
    }

    bool weatherChanged = (currentWeather != lastOpenMeteoWeatherCode);
    bool forecastChanged = (forecastCode != lastOpenMeteoForecastCode);
    bool textChanged = (strcmp(forecastText, lastOpenMeteoForecastText) != 0);
    bool nightChanged = (isNight != lastIsNight);

    bool needRedraw = (needFullRedraw || weatherChanged || forecastChanged || textChanged || nightChanged || firstRun);

    if (needRedraw) {
      // === НАДПИСИ "Сейчас" и "Через N часов" ===
      if (!labelsDrawn || needFullRedraw || firstRun) {
        tft.fillRect(160, 33, 137, 25, TFT_BLACK);
        tft.fillRect(10, 276, 145, 23, TFT_BLACK);

        tft.loadFont("cambriai24", LittleFS);
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setCursor(191, 35);
        tft.print("Сейчас");

        char periodText[40];
        uint8_t h = forecastConfig.forecastHourIdx + 1;
        const char* word;
        if (h == 1) word = "час";
        else if (h >= 2 && h <= 4) word = "часа";
        else word = "часов";
        snprintf(periodText, sizeof(periodText), "Через %d %s", h, word);

        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setCursor(11, 277);
        tft.print(periodText);
        tft.unloadFont();

        labelsDrawn = true;
      }

      // === ИНДИКАТОР ИСТОЧНИКА (дефолтный шрифт) ===
      tft.setTextSize(1);
      tft.setCursor(1, 1);

      bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
      bool wifiConfigured = wifiConfig.configured && coordsOk;

      if (wifiConfigured) {
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
      } else {
        tft.setTextColor(TFT_RED, TFT_BLACK);
      }
      tft.print("WEB");

      // === ВЕРХНЯЯ ИКОНКА ===
      if (weatherChanged || nightChanged || needFullRedraw || firstRun) {
        tft.fillRect(178, 62, ICON_SIZE, ICON_SIZE, TFT_BLACK);
        const uint16_t* icon = getWeatherIcon(currentWeather, isNight);
        if (icon != nullptr) {
          tft.pushImage(178, 62, ICON_SIZE, ICON_SIZE, icon);
        }
        lastOpenMeteoWeatherCode = currentWeather;
        LOG_D("   ✅ Обновлена иконка текущей погоды");
      }

      // === НИЖНЯЯ ИКОНКА ===
      if (forecastChanged || nightChanged || needFullRedraw || firstRun) {
        tft.fillRect(178, 170, ICON_SIZE, ICON_SIZE, TFT_BLACK);
        const uint16_t* icon = getWeatherIcon(forecastCode, isNight);
        if (icon != nullptr) {
          tft.pushImage(178, 170, ICON_SIZE, ICON_SIZE, icon);
        }
        lastOpenMeteoForecastCode = forecastCode;
        LOG_D("   ✅ Обновлена иконка прогноза");
      }

      // === ТЕКСТ ПРОГНОЗА ===
      if (textChanged || needFullRedraw || firstRun) {
        tft.fillRect(155, 276, 325, 23, TFT_BLACK);
        tft.loadFont("cambriai24", LittleFS);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.setCursor(157, 277);
        tft.print(forecastText);
        tft.unloadFont();
        strncpy(lastOpenMeteoForecastText, forecastText, sizeof(lastOpenMeteoForecastText) - 1);
        lastOpenMeteoForecastText[sizeof(lastOpenMeteoForecastText) - 1] = '\0';
        LOG_D("   ✅ Обновлен текст прогноза");
      }

      tft.fillRect(14, 300, 200, 23, TFT_BLACK);

      lastIsNight = isNight;
      noDataMessageShown = false;

      if (firstRun) {
        firstRun = false;
        LOG_D("✅ Первая отрисовка Open-Meteo выполнена");
      }
    }

    // ===== ВЕТКА 2: ЯНДЕКС =====
  } else if (wifiConfig.forecastSource == 2 && yandexData.isValid) {

    if (forecastConfig.yandexFormat == 0) {
      // ===== ПО ЧАСАМ =====
      int nowHour = rtcClock.getTime().hour();
      int targetHour = (nowHour + forecastConfig.forecastHourIdx + 1) % 24;

      static int lastDebugHour = -1;
      if (targetHour != lastDebugHour) {
        lastDebugHour = targetHour;
        LOG_D("🕐 nowHour=%d, fhi=%d, targetHour=%d, temp=%.0f, isDay=%d, cond='%s'",
              nowHour, forecastConfig.forecastHourIdx, targetHour,
              yandexData.forecastTemp[targetHour],
              yandexData.forecastIsDay[targetHour],
              yandexData.forecastCondition[targetHour]);
      }

      if (targetHour < 0) targetHour += 24;
      if (targetHour > 23) targetHour -= 24;

      const char* yCondition = yandexData.forecastCondition[targetHour];
      int forecastCode = mapYandexToWeatherCode(yCondition);
      const char* forecastText = getYandexDescription(yCondition);
      bool isNight = !yandexData.forecastIsDay[targetHour];

      int currentWeather = mapYandexToWeatherCode(yandexData.currentCondition);
      bool currentIsNight = !yandexData.isDaytime;

      if (strcmp(yandexData.currentPhenom, "fog") == 0 || strcmp(yandexData.currentPhenom, "mist") == 0) {
        currentWeather = WEATHER_FOG;
      }

      static int lastYandexCurrentCode = -1;
      static int lastYandexForecastCode = -1;
      static char lastYandexForecastText[64] = "";
      static bool lastYandexNight = false;
      static uint8_t lastYandexHourIdx = 255;

      bool weatherChanged = (currentWeather != lastYandexCurrentCode);
      bool forecastChanged = (forecastCode != lastYandexForecastCode);
      bool textChanged = (strcmp(forecastText, lastYandexForecastText) != 0);
      bool nightChanged = (isNight != lastYandexNight);
      bool hourChanged = (targetHour != lastYandexHourIdx);

      bool needRedraw = (needFullRedraw || weatherChanged || forecastChanged || textChanged || nightChanged || hourChanged || firstRun);

      if (needRedraw) {
        // === НАДПИСИ ===
        if (!labelsDrawn || needFullRedraw || firstRun || hourChanged) {
          tft.fillRect(160, 33, 137, 25, TFT_BLACK);
          tft.fillRect(10, 276, 145, 23, TFT_BLACK);

          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setCursor(191, 35);
          tft.print("Сейчас");

          char periodText[40];
          uint8_t h = forecastConfig.forecastHourIdx + 1;
          const char* word;
          if (h == 1) word = "час";
          else if (h >= 2 && h <= 4) word = "часа";
          else word = "часов";
          snprintf(periodText, sizeof(periodText), "Через %d %s", h, word);

          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setCursor(11, 277);
          tft.print(periodText);
          tft.unloadFont();

          labelsDrawn = true;
        }

        // === ИНДИКАТОР WEB (дефолтный шрифт) ===
        static uint16_t lastWebColorY = 0xFFFF;
        static int lastWebSourceY = -1;

        tft.setTextSize(1);
        tft.setCursor(1, 1);
        bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
        bool yandexConfigured = wifiConfig.configured && coordsOk && (strlen(wifiConfig.yandexApiKey) > 0);

        uint16_t webColorY;
        if (!yandexConfigured) {
          webColorY = TFT_RED;
        } else if (lastSessionFailed) {
          webColorY = TFT_YELLOW;
        } else {
          webColorY = TFT_GREEN;
        }

        if (webColorY != lastWebColorY || lastWebSourceY != 2 || webIndicatorDirty) {
          lastWebColorY = webColorY;
          lastWebSourceY = 2;
          webIndicatorDirty = false;

          tft.setTextColor(webColorY, TFT_BLACK);
          tft.print("WEB");
        }

        // === ВЕРХНЯЯ ИКОНКА ===
        if (weatherChanged || nightChanged || needFullRedraw || firstRun) {
          tft.fillRect(178, 62, ICON_SIZE, ICON_SIZE, TFT_BLACK);
          const uint16_t* icon = getWeatherIcon(currentWeather, currentIsNight);
          if (icon != nullptr) {
            tft.pushImage(178, 62, ICON_SIZE, ICON_SIZE, icon);
          }
          lastYandexCurrentCode = currentWeather;
        }

        // === НИЖНЯЯ ИКОНКА ===
        if (forecastChanged || nightChanged || needFullRedraw || firstRun || hourChanged) {
          tft.fillRect(178, 170, ICON_SIZE, ICON_SIZE, TFT_BLACK);
          const uint16_t* icon = getWeatherIcon(forecastCode, isNight);
          if (icon != nullptr) {
            tft.pushImage(178, 170, ICON_SIZE, ICON_SIZE, icon);
          }
          lastYandexForecastCode = forecastCode;
        }

        // === ТЕКСТ ПРОГНОЗА ===
        if (textChanged || needFullRedraw || firstRun || hourChanged) {
          tft.fillRect(155, 276, 325, 23, TFT_BLACK);
          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          tft.setCursor(157, 277);
          tft.print(forecastText);
          tft.unloadFont();
          strncpy(lastYandexForecastText, forecastText, sizeof(lastYandexForecastText) - 1);
          lastYandexForecastText[sizeof(lastYandexForecastText) - 1] = '\0';
        }

        lastYandexNight = isNight;
        lastYandexHourIdx = targetHour;
        noDataMessageShown = false;

        if (firstRun) {
          firstRun = false;
          LOG_D("✅ Первая отрисовка Яндекса (по часам)");
        }
      }

      // ===== ВЕРОЯТНОСТЬ ОСАДКОВ =====
      static uint8_t lastYandexRainProbH = 255;
      static int lastYandexTargetHour = -1;
      uint8_t precProbH = yandexData.forecastPrecProb[targetHour];

      char rainProbTextH[32];
      if (precProbH == 0) {
        strcpy(rainProbTextH, "Без осадков");
      } else if (precProbH > 50) {
        snprintf(rainProbTextH, sizeof(rainProbTextH), "(%u%% дождь)", precProbH);
      } else {
        snprintf(rainProbTextH, sizeof(rainProbTextH), "(%u%%)", precProbH);
      }

      bool hourChangedH = (targetHour != lastYandexTargetHour);

      if (precProbH != lastYandexRainProbH || needFullRedraw || firstRun || hourChangedH) {
        tft.fillRect(14, 300, 200, 23, TFT_BLACK);

        if (rainProbTextH[0] != '\0') {
          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_CYAN, TFT_BLACK);
          tft.setCursor(15, 301);
          tft.print(rainProbTextH);
          tft.unloadFont();
        }

        lastYandexRainProbH = precProbH;
        lastYandexTargetHour = targetHour;
      }

    } else {
      // ===== ПО ЧАСТЯМ СУТОК =====
      DateTime now = rtcClock.getTime();
      int hour = now.hour();

      int partIdx;
      if (hour >= 23 || hour < 6) partIdx = 1;
      else if (hour >= 6 && hour < 12) partIdx = 2;
      else if (hour >= 12 && hour < 18) partIdx = 3;
      else partIdx = 0;

      const char* partCondition = yandexData.partCondition[partIdx];
      int forecastCode = mapYandexToWeatherCode(partCondition);
      const char* forecastText = getYandexDescription(partCondition);

      const char* partNames[4] = { "Ночью", "Утром", "Днём", "Вечером" };

      int currentWeather = mapYandexToWeatherCode(yandexData.currentCondition);
      bool currentIsNight = !yandexData.isDaytime;

      if (strcmp(yandexData.currentPhenom, "fog") == 0 || strcmp(yandexData.currentPhenom, "mist") == 0) {
        currentWeather = WEATHER_FOG;
      }

      bool isNight = (partIdx == 0) || (partIdx == 3);

      static int lastYandexCurrentCode2 = -1;
      static int lastYandexForecastCode2 = -1;
      static char lastYandexForecastText2[64] = "";
      static int lastYandexPartIdx = -1;

      bool weatherChanged = (currentWeather != lastYandexCurrentCode2);
      bool forecastChanged = (forecastCode != lastYandexForecastCode2);
      bool textChanged = (strcmp(forecastText, lastYandexForecastText2) != 0);
      bool partChanged = (partIdx != lastYandexPartIdx);

      bool needRedraw = (needFullRedraw || weatherChanged || forecastChanged || textChanged || partChanged || firstRun);

      if (needRedraw) {
        // === НАДПИСИ ===
        if (!labelsDrawn || needFullRedraw || firstRun || partChanged) {
          tft.fillRect(160, 33, 137, 25, TFT_BLACK);
          tft.fillRect(10, 276, 145, 23, TFT_BLACK);

          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setCursor(191, 35);
          tft.print("Сейчас");

          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setCursor(11, 277);
          tft.print(partNames[partIdx]);
          tft.unloadFont();

          labelsDrawn = true;
        }

        // === ИНДИКАТОР WEB (дефолтный шрифт) ===
        static uint16_t lastWebColorY2 = 0xFFFF;
        static int lastWebSourceY2 = -1;

        tft.setTextSize(1);
        tft.setCursor(1, 1);
        bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
        bool yandexConfigured = wifiConfig.configured && coordsOk && (strlen(wifiConfig.yandexApiKey) > 0);

        uint16_t webColorY2;
        if (!yandexConfigured) {
          webColorY2 = TFT_RED;
        } else if (lastSessionFailed) {
          webColorY2 = TFT_YELLOW;
        } else {
          webColorY2 = TFT_GREEN;
        }

        if (webColorY2 != lastWebColorY2 || lastWebSourceY2 != 2 || webIndicatorDirty) {
          lastWebColorY2 = webColorY2;
          lastWebSourceY2 = 2;
          webIndicatorDirty = false;

          tft.setTextColor(webColorY2, TFT_BLACK);
          tft.print("WEB");
        }

        // === ВЕРХНЯЯ ИКОНКА ===
        if (weatherChanged || needFullRedraw || firstRun) {
          tft.fillRect(178, 62, ICON_SIZE, ICON_SIZE, TFT_BLACK);
          const uint16_t* icon = getWeatherIcon(currentWeather, currentIsNight);
          if (icon != nullptr) {
            tft.pushImage(178, 62, ICON_SIZE, ICON_SIZE, icon);
          }
          lastYandexCurrentCode2 = currentWeather;
        }

        // === НИЖНЯЯ ИКОНКА ===
        if (forecastChanged || needFullRedraw || firstRun || partChanged) {
          tft.fillRect(178, 170, ICON_SIZE, ICON_SIZE, TFT_BLACK);
          const uint16_t* icon = getWeatherIcon(forecastCode, isNight);
          if (icon != nullptr) {
            tft.pushImage(178, 170, ICON_SIZE, ICON_SIZE, icon);
          }
          lastYandexForecastCode2 = forecastCode;
        }

        // === ТЕКСТ ПРОГНОЗА ===
        if (textChanged || needFullRedraw || firstRun || partChanged) {
          tft.fillRect(155, 276, 325, 23, TFT_BLACK);
          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          tft.setCursor(157, 277);
          tft.print(forecastText);
          tft.unloadFont();
          strncpy(lastYandexForecastText2, forecastText, sizeof(lastYandexForecastText2) - 1);
          lastYandexForecastText2[sizeof(lastYandexForecastText2) - 1] = '\0';
        }

        lastYandexPartIdx = partIdx;
        noDataMessageShown = false;

        if (firstRun) {
          firstRun = false;
          LOG_D("✅ Первая отрисовка Яндекса (по частям суток)");
        }
      }

      // ===== ВЕРОЯТНОСТЬ ОСАДКОВ =====
      static uint8_t lastYandexRainProb = 255;
      uint8_t precProb = yandexData.partPrecProb[partIdx];

      char rainProbText[32];
      if (precProb == 0) {
        strcpy(rainProbText, "Без осадков");
      } else if (precProb > 50) {
        snprintf(rainProbText, sizeof(rainProbText), "(%u%% дождь)", precProb);
      } else {
        snprintf(rainProbText, sizeof(rainProbText), "(%u%%)", precProb);
      }

      if (precProb != lastYandexRainProb || needFullRedraw || firstRun) {
        tft.fillRect(14, 300, 200, 23, TFT_BLACK);

        if (rainProbText[0] != '\0') {
          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_CYAN, TFT_BLACK);
          tft.setCursor(15, 301);
          tft.print(rainProbText);
          tft.unloadFont();
        }

        lastYandexRainProb = precProb;
      }
    }

    // ===== ВЕТКА 3: RF =====
  } else if (wifiConfig.forecastSource == 0 && forecast.isDataAvailable()) {

    int currentWeather = forecast.getHybridForecast();
    int forecastCode = forecast.getForecastCode();
    const char* forecastText = forecast.getForecastText();
    bool isNight = forecast.isNightTime();
    const char* rainProbText = forecast.getRainProbText();

    static int lastOwnWeatherCode = -1;
    static int lastOwnForecastCode = -1;
    static char lastOwnForecastText[64] = "";
    static char lastOwnRainProb[32] = "";
    static bool lastOwnIsNight = false;

    bool weatherChanged = (currentWeather != lastOwnWeatherCode);
    bool forecastChanged = (forecastCode != lastOwnForecastCode);
    bool textChanged = (strcmp(forecastText, lastOwnForecastText) != 0);
    bool nightChanged = (isNight != lastOwnIsNight);
    bool rainProbChanged = (strcmp(rainProbText, lastOwnRainProb) != 0);

    bool needRedraw = (needFullRedraw || weatherChanged || forecastChanged || textChanged || nightChanged || rainProbChanged || firstRun);

    if (needRedraw) {
      LOG_D("🎨 Собственный прогноз: погода=%d, прогноз=%d, ночь=%d",
            currentWeather, forecastCode, isNight);

      // === НАДПИСИ ===
      if (!labelsDrawn || needFullRedraw || firstRun) {
        tft.fillRect(160, 33, 137, 25, TFT_BLACK);
        tft.fillRect(10, 276, 135, 23, TFT_BLACK);

        tft.loadFont("cambriai24", LittleFS);
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setCursor(191, 35);
        tft.print("Сейчас");

        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setCursor(11, 277);
        tft.print("Ожидается");
        tft.unloadFont();

        labelsDrawn = true;
      }

      // === ИНДИКАТОР ИСТОЧНИКА (дефолтный шрифт) ===
      tft.setTextSize(1);
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      tft.setCursor(1, 1);
      tft.print("SENS");

      // === ВЕРХНЯЯ ИКОНКА ===
      if (weatherChanged || nightChanged || needFullRedraw || firstRun) {
        tft.fillRect(178, 62, ICON_SIZE, ICON_SIZE, TFT_BLACK);
        const uint16_t* icon = getWeatherIcon(currentWeather, isNight);
        if (icon != nullptr) {
          tft.pushImage(178, 62, ICON_SIZE, ICON_SIZE, icon);
        }
        lastOwnWeatherCode = currentWeather;
      }

      // === НИЖНЯЯ ИКОНКА ===
      if (forecastChanged || nightChanged || needFullRedraw || firstRun) {
        tft.fillRect(178, 170, ICON_SIZE, ICON_SIZE, TFT_BLACK);
        const uint16_t* icon = getWeatherIcon(forecastCode, isNight);
        if (icon != nullptr) {
          tft.pushImage(178, 170, ICON_SIZE, ICON_SIZE, icon);
        }
        lastOwnForecastCode = forecastCode;
      }

      // === ТЕКСТ ПРОГНОЗА ===
      if (textChanged || needFullRedraw || firstRun) {
        tft.fillRect(143, 276, 333, 23, TFT_BLACK);
        tft.loadFont("cambriai24", LittleFS);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.setCursor(145, 277);
        tft.print(forecastText);
        tft.unloadFont();
        strncpy(lastOwnForecastText, forecastText, sizeof(lastOwnForecastText) - 1);
        lastOwnForecastText[sizeof(lastOwnForecastText) - 1] = '\0';
      }

      // === ВЕРОЯТНОСТЬ ДОЖДЯ ===
      if (rainProbChanged || needFullRedraw || firstRun) {
        if (rainProbText[0] != '\0') {
          tft.fillRect(14, 300, 200, 23, TFT_BLACK);
          tft.loadFont("cambriai24", LittleFS);
          tft.setTextColor(TFT_CYAN, TFT_BLACK);
          tft.setCursor(15, 301);
          tft.print(rainProbText);
          tft.unloadFont();
        } else {
          tft.fillRect(14, 300, 200, 23, TFT_BLACK);
        }
        strncpy(lastOwnRainProb, rainProbText, sizeof(lastOwnRainProb) - 1);
        lastOwnRainProb[sizeof(lastOwnRainProb) - 1] = '\0';
      }

      lastOwnIsNight = isNight;
      noDataMessageShown = false;

      if (firstRun) {
        firstRun = false;
        LOG_D("✅ Первая отрисовка собственного прогноза выполнена");
      }
    }

  } else if (hasFirstPacket) {
    // === НЕТ ДАННЫХ ===
    if (!noDataMessageShown || needFullRedraw) {
      tft.fillRect(160, 33, 137, 25, TFT_BLACK);
      tft.fillRect(10, 285, 137, 25, TFT_BLACK);

      tft.loadFont("cambriai24", LittleFS);
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(161, 35);
      tft.print("Сбор данных");
      tft.unloadFont();

      noDataMessageShown = true;
    }
  }

  // ===== ПРЕДУПРЕЖДЕНИЯ ОТ RF =====
  const char* omWarning = forecast.getWeatherWarning();

  // При источнике не RF — показываем только критичные (гололёд, мороз, жара)
  if (wifiConfig.forecastSource != 0 && omWarning[0] != '\0') {
    bool isCritical = (strstr(omWarning, "ГОЛОЛЁД") != nullptr) || (strstr(omWarning, "мороз") != nullptr) || (strstr(omWarning, "жара") != nullptr);
    if (!isCritical) {
      omWarning = "";
    }
  }

  if (strcmp(omWarning, lastOmWarning) != 0 || needFullRedraw || firstRun) {
    tft.fillRect(305, 300, 175, 23, TFT_BLACK);

    if (omWarning[0] != '\0') {
      tft.loadFont("cambriai24");

      uint16_t warnColor = TFT_RED;
      if (strstr(omWarning, "Мороз") != nullptr) warnColor = TFT_CYAN;
      else if (strstr(omWarning, "Жара") != nullptr) warnColor = TFT_ORANGE;
      else if (strstr(omWarning, "Душно") != nullptr) warnColor = TFT_YELLOW;

      tft.setTextColor(warnColor, TFT_BLACK);
      tft.setCursor(307, 301);
      tft.print(omWarning);
      tft.unloadFont();

      LOG_I("⚠️ Предупреждение (RF): %s", omWarning);
    }
    strncpy(lastOmWarning, omWarning, sizeof(lastOmWarning) - 1);
    lastOmWarning[sizeof(lastOmWarning) - 1] = '\0';
  }

  if (needFullRedraw) {
    needFullRedraw = false;
    LOG_D("🔄 needFullRedraw = false");
  }
}

void printDebugInfoIfChanged() {
  static float lastTempPrinted = -999;
  static float lastHumPrinted = -999;
  static float lastPresPrinted = -999;

  bool shouldPrint = false;

  if (abs(filteredData.temperature - lastTempPrinted) > 0.1) {
    lastTempPrinted = filteredData.temperature;
    shouldPrint = true;
  }
  if (abs(filteredData.humidity - lastHumPrinted) > 0.1) {
    lastHumPrinted = filteredData.humidity;
    shouldPrint = true;
  }
  if (abs(filteredData.pressure - lastPresPrinted) > 1.0) {
    lastPresPrinted = filteredData.pressure;
    shouldPrint = true;
  }

  if (shouldPrint) {
    LOG_I("T:%.1fC | H:%.1f%% | P:%.1fmmHg",
          filteredData.temperature, filteredData.humidity, filteredData.pressure);
  }
}

// ===================================================================
// SETUP
// ===================================================================
void setup() {
  HWSerial.begin(115200);
  loggerInit();  // уровень ERROR по умолчанию
  delay(100);    // ← было 1000, уменьшено
  HWSerial.println("\n=== SYSTEM START ===");

  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  autoBrightnessAvailable = true;

  // ========== EEPROM ==========
  if (!EEPROM.begin(512)) {
    HWSerial.println("EEPROM initialization failed!");
    brightness = 30;
    targetBrightness = 30;
    lastSavedBrightness = 30;
  } else {
    uint8_t savedBrightness = EEPROM.read(BRIGHTNESS_EEPROM_ADDR);
    if (savedBrightness != 0xFF && savedBrightness != 0 && savedBrightness <= 255) {
      brightness = savedBrightness;
      targetBrightness = savedBrightness;
      lastSavedBrightness = savedBrightness;
    } else {
      brightness = 30;
      targetBrightness = 30;
      lastSavedBrightness = 30;
    }
  }

  // ========== TFT ДИСПЛЕЙ (в начале — для splash) ==========
  tft.init();
  tft.setSwapBytes(true);
  tft.setRotation(3);
  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Загрузка...");
  HWSerial.println("TFT... OK");

  // ========== I2C ДАТЧИКИ ==========
  I2Cone.begin(21, 47);
  I2Cone.setClock(100000);

  tft.setCursor(10, 40);
  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("I2C... ");

  if (airSensor.begin(I2Cone)) {
    airSensor.startPeriodicMeasurement();
    isCo2Working = true;
  } else {
    isCo2Working = false;
  }

  if (bme.begin(0x76, &I2Cone)) {
    bmeModule.begin();
    bmeModule.loadAllCalibrations();
    isBmeWorking = true;
  } else {
    isBmeWorking = false;
  }
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.print("OK");
  HWSerial.println("I2C + SCD40 + BME280... OK");

  // ========== RTC ==========
  tft.setCursor(10, 70);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("RTC... ");

  rtcWire.begin(1, 2);
  rtcWire.setClock(100000);
  rtcClock.begin(rtcWire, 0x68, 1, 2);
  rtcClock.forceUpdate();

  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.print("OK");
  HWSerial.println("RTC... OK");

  // ========== УЛИЧНЫЕ ДАННЫЕ ==========
  tempBlock.begin(20.0);
  humBlock.begin(50.0);
  presBlock.begin(760.0);
  tempBlock.loadCalibration();
  humBlock.loadCalibration();
  presBlock.loadCalibration();

  tft.setCursor(10, 100);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("Модули... ");
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.print("OK");
  HWSerial.println("Уличные модули... OK");

  // ========== КНОПКИ ==========
  pinMode(LED_PWM_PIN, OUTPUT);
  pinMode(KEYPAD_PIN, INPUT);
  analogWrite(LED_PWM_PIN, brightness);

  // ========== ОТКЛЮЧЕНИЕ РАДИО ESP32 ==========
  btStop();

  // ========== НАСТРОЙКА WI-FI ==========
  // Wi-Fi настроен через веб-интерфейс и сохранён в NVS.
  // При старте — только выключаем радио (включит расписание).
  WiFi.setSleep(false);  // критично — иначе MMU/Cache fault
  WiFi.mode(WIFI_OFF);
  HWSerial.println("📴 Wi-Fi выключен (включит расписание)");

  tft.setCursor(10, 130);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("WiFi... ");
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.print("OK");

  isIndicatorActive = false;
  lastButtonActivity = millis();

  // ========== nRF24L01 ==========
  tft.setCursor(10, 160);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("nRF24... ");

  // SPI.begin() НЕ ВЫЗЫВАЕМ — он ломает VSPI, который использует TFT
  hspi.begin(NRF_SCK, NRF_MISO, NRF_MOSI, NRF_CSN);

  if (!radio.begin(&hspi)) {
    HWSerial.println("⚠️ nRF24L01 не подключён — работаем без уличных данных");
    isRadioWorking = false;
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.print("ОШИБКА");
  } else {
    radio.setChannel(0x7A);
    radio.setDataRate(RF24_250KBPS);
    radio.setPALevel(RF24_PA_LOW);
    radio.openReadingPipe(1, radioPipe);
    radio.startListening();

    uint8_t dummyBuffer[32];
    while (radio.available()) {
      radio.read(dummyBuffer, sizeof(dummyBuffer));
      delay(10);
    }
    isRadioWorking = true;
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.print("OK");
    HWSerial.println("nRF24L01... OK");
  }

  // ========== LittleFS ==========
  tft.setCursor(10, 190);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("LittleFS... ");

  if (!LittleFS.begin(true)) {
    HWSerial.println("Ошибка инициализации LittleFS");
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.print("ОШИБКА");
    return;
  }
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.print("OK");
  HWSerial.printf("LittleFS mounted successfully (total: %u, used: %u)\n",
                  LittleFS.totalBytes(), LittleFS.usedBytes());



  // ========== SD (VSPI, отдельно) ==========
  loadSdConfig();  // Читаем настройку из EEPROM

  tft.setCursor(10, 220);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.print("SD... ");

  bool sdInitOk = false;
  if (sdLoggingEnabled) {
    sdInitOk = initSD();
    tft.setTextColor(sdInitOk ? TFT_GREEN : TFT_RED, TFT_BLACK);
    tft.print(sdInitOk ? "OK" : "ОШИБКА");
    if (sdInitOk) {
      loadGraphsFromArchive();
      restoreCurrentHour();  // ← ДОБАВИТЬ: восстановить средние за текущий час
      restoreDailyStats();
    }
  } else {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.print("ВЫКЛ");
  }

  // ========== ОСНОВНАЯ ГРАФИКА ==========
  tft.fillScreen(TFT_BLACK);  // ← ОЧИЩАЕМ SPLASH

  tft.loadFont("cambriai48", LittleFS);
  tft.loadFont("cambriai38", LittleFS);

  drawStaticLabels(tft);

  lastDisplayedTemp = -999;
  lastDisplayedHum = -999;
  lastDisplayedPres = -999;
  tempBufferIndex = 0;
  humBufferIndex = 0;
  presBufferIndex = 0;

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  isNoSignalWarningActive = false;
  lastSignalTime = millis();
  drawIndicator();

  currentMode = MODE_MAIN;
  needFullRedraw = true;

  // ========== ЗАГРУЗКА КОНФИГОВ ==========
  loadBrightnessConfig();
  applyBrightnessConfig();
  loadCalibrationConfig();
  applyCalibrationConfig();
  loadTimeConfig();
  loadTrendsConfig();
  applyTrendsConfig();  // ← ДОБАВИТЬ: применить пороги из EEPROM к классу Trends
  loadWiFiConfig();
  applyWiFiConfig();
  loadLocationConfig();
  applyLocationConfig();
  loadForecastConfig();
  applyForecastConfig();

  // ========== ОДНО ЧТЕНИЕ RTC ==========
  rtcClock.update();
  if (rtcClock.getTime().year() < 2024) {
    HWSerial.println("⚠️ RTC не отдаёт валидное время");
  }

  HWSerial.println("Настройка завершена.");
}

// ===================================================================
// LOOP
// ===================================================================

void loop() {
  unsigned long currentMillis = millis();

  // ===== РЕЖИМ OTA =====
  if (currentMode == MODE_OTA) {
    otaLoop();
    return;
  }

  // ===== РЕЖИМ ГРАФИКИ =====
  if (currentMode == MODE_GRAPHS) {
    handleGraphsNavigation();
    return;
  }

  // ===== РЕЖИМ СТАТИСТИКА =====
  if (currentMode == MODE_STATS) {
    handleStatsNavigation();
    return;
  }

  // ============================================================
  // 1. СКАНИРОВАНИЕ КНОПОК (ОТЛАДКА ADC)
  // ============================================================
  int rawValue = analogRead(KEYPAD_PIN);
  static int lastPrintValue = -1;
  if (abs(rawValue - lastPrintValue) > 10) {
    // LOG_D("ADC: %4d", rawValue);
    lastPrintValue = rawValue;
  }

  // ============================================================
  // 2. ПРОВЕРКА ВХОДА В МЕНЮ / ГРАФИКИ / СТАТИСТИКУ (MODE_MAIN)
  // ============================================================
  if (currentMode == MODE_MAIN) {
    int key = readKeypad();
    if (key != KEY_NONE) {
      static unsigned long lastPressTime = 0;
      if (millis() - lastPressTime > 300) {
        lastPressTime = millis();
        if (key == KEY_OK) {
          enterMenuMode();
          return;
        }
        if (key == KEY_RIGHT) {
          enterGraphsMode();
          return;
        }
        if (key == KEY_LEFT) {
          enterStatsMode();
          return;
        }
      }
    }
  }

  // ============================================================
  // 3. РЕЖИМ МЕНЮ
  // ============================================================
  if (currentMode == MODE_MENU) {
    handleMenuNavigation();
    delay(50);
    return;
  }

  // ============================================================
  // 4. РЕЖИМ ГЛАВНОГО ЭКРАНА
  // ============================================================

  // ===== РАСПИСАНИЕ WI-FI И ОБНОВЛЕНИЕ ПРОГНОЗА =====
  updateWiFiSchedule();

  // ===== НЕБЛОКИРУЮЩИЙ ВЕБ-СЕРВЕР ЛОГОВ =====
  // Если сервер запущен в режиме «Без подсказок» — обслуживаем его
  // и проверяем таймаут 5 минут.
  extern bool webLogsActive;
  extern void webLogsLoop();
  if (webLogsActive) {
    webLogsLoop();
  }

  // ===== SD: сброс буфера раз в 5 минут =====
  static unsigned long lastSdFlush = 0;
  if (sdLoggingEnabled && millis() - lastSdFlush >= 5 * 60 * 1000) {
    lastSdFlush = millis();
    flushBufferToSD();
  }

  // ===== SD: часовой архив в :00 =====
  {
    DateTime now = rtcClock.getTime();
    if (now.minute() == 0 && now.hour() != lastLoggedHour && hourMeasCount > 0) {
      lastLoggedHour = now.hour();
      float avgT = hourSumTemp / hourMeasCount;
      float avgH = hourSumHum / hourMeasCount;
      float avgP = hourSumPres / hourMeasCount;

      LOG_I("⏰ Час: T=%.1f H=%.1f P=%.1f (n=%d)",
            avgT, avgH, avgP, hourMeasCount);

      if (sdLoggingEnabled) {
        saveHourlyArchive(now.unixtime(), avgT, avgH, avgP);
        writeLog(now.unixtime(), avgT, avgH, avgP);
        clearRawHourly();  // Очищаем сырые данные для нового часа
      }
      graphAddHour(avgT, avgH, avgP);

      hourSumTemp = 0;
      hourSumHum = 0;
      hourSumPres = 0;
      hourMeasCount = 0;
    }
  }

  // ===== SD: дневной архив при смене дня =====
  {
    DateTime now = rtcClock.getTime();
    if (now.day() != lastLoggedDay && dayMeasCount > 0) {
      if (lastLoggedDay != -1) {  // не при первом старте
        float avgT = daySumTemp / dayMeasCount;
        float avgH = daySumHum / dayMeasCount;
        float avgP = daySumPres / dayMeasCount;

        LOG_I("📅 День: T=%.1f[%.1f..%.1f] H=%.1f P=%.1f (n=%d)",
              avgT, dayMinTemp, dayMaxTemp, avgH, avgP, dayMeasCount);

        if (sdLoggingEnabled) {
          saveDailyArchive(now.unixtime(),
                           avgT, dayMinTemp, dayMaxTemp,
                           avgH, dayMinHum, dayMaxHum,
                           avgP, dayMinPres, dayMaxPres,
                           dayMeasCount);
        }
        graphAddDay(avgT, avgH, avgP);

        // ===== СБРОС — ТОЛЬКО ПРИ РЕАЛЬНОЙ СМЕНЕ ДНЯ =====
        // (не при первом проходе после старта, когда lastLoggedDay == -1
        //  и daySum* только что восстановлены restoreDailyStats)
        daySumTemp = 0;
        dayMinTemp = 999;
        dayMaxTemp = -999;
        daySumHum = 0;
        dayMinHum = 999;
        dayMaxHum = -999;
        daySumPres = 0;
        dayMinPres = 9999;
        dayMaxPres = -999;
        dayMeasCount = 0;
      }

      // ВСЕГДА обновляем lastLoggedDay, чтобы не срабатывало повторно
      lastLoggedDay = now.day();
    }
  }


  // ===== SD: проверка карты раз в 3 сек =====
  static unsigned long lastSdCheck = 0;
  if (sdLoggingEnabled && millis() - lastSdCheck >= 3000) {
    lastSdCheck = millis();
    checkSD();
  }

  // --- ОТЛАДКА: ПОДМЕНА ДАННЫХ (только если isDataFake) ---
  if (isDataFake) {
    DataStruct fakeData;
    fakeData.temperature = debugTemp;
    fakeData.humidity = debugHum;
    fakeData.pressure = debugPres;
    fakeData.battery_voltage = 8.4;
    receivedData = fakeData;
    readAndProcessPacket();
  }

  handleHWSerialCommands(rtcClock, tempBlock, humBlock, presBlock, bmeModule, forecast, tft);

  handleBrightnessControl();
  updateBrightness();
  updateIndicatorVisibility();
  updateModeIndicator();

  // --- РАДИО ---
  if (isRadioWorking && radio.available()) {
    digitalWrite(LED_PIN, HIGH);
    bool dataWasRead = false;
    unsigned long packetArrivalTime = millis();
    while (radio.available()) {
      radio.read(&receivedData, sizeof(receivedData));
      packetArrivalTime = millis();
      dataWasRead = true;
    }
    if (dataWasRead) {
      // Пакет прочитан — сигнал есть (независимо от PACKET_TIMEOUT)
      lastSignalTime = millis();
      if (isNoSignalWarningActive) {
        isNoSignalWarningActive = false;
        clearWarningArea();
      }
      // Обрабатываем только «свежие» пакеты (защита от мусора)
      if (millis() - packetArrivalTime < PACKET_TIMEOUT) {
        readAndProcessPacket();
      }
    }
    digitalWrite(LED_PIN, LOW);
  }

  // --- ОБНОВЛЕНИЕ ДИСПЛЕЯ ---
  if (currentMillis - lastDisplayUpdate >= DISPLAY_UPDATE_INTERVAL) {
    updateDisplayIfChanged();
    lastDisplayUpdate = currentMillis;
  }

  // --- RTC ---
  static unsigned long lastRTCUpdate = 0;
  const unsigned long RTC_UPDATE_INTERVAL = 1000;

  if (currentMillis - lastRTCUpdate >= RTC_UPDATE_INTERVAL) {
    rtcClock.update();
    rtcClock.draw(tft);
    lastRTCUpdate = currentMillis;
  }

  // --- ПРОВЕРКА СИГНАЛА ---
  static unsigned long lastSignalCheck = millis();
  unsigned long nowSignal = millis();  // ← свежий millis() (после блока радио)
  if (nowSignal - lastSignalCheck >= 1000) {
    lastSignalCheck = nowSignal;

    if (nowSignal - lastSignalTime > SIGNAL_TIMEOUT) {
      if (!isNoSignalWarningActive) {
        showNoSignalWarning();
      }
      static unsigned long ledBlinkTime = millis();
      static bool ledState = false;
      if (nowSignal - ledBlinkTime > 500) {
        ledState = !ledState;
        digitalWrite(LED_PIN, ledState);
        ledBlinkTime = nowSignal;
      }
    } else {
      if (isNoSignalWarningActive) {
        isNoSignalWarningActive = false;
        clearWarningArea();
        digitalWrite(LED_PIN, LOW);
      }
    }
  }

  // --- КОНТРОЛЬ СКОРОСТИ ЦИКЛА ---
  unsigned long loopDuration = millis() - currentMillis;
  if (loopDuration < LOOP_INTERVAL) {
    delay(LOOP_INTERVAL - loopDuration);
  }
}