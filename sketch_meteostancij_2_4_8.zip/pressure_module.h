#ifndef PRESSURE_MODULE_H
#define PRESSURE_MODULE_H

#include <TFT_eSPI.h>

class PressureModule {
public:
  PressureModule(TFT_eSPI& tft);  // Конструктор с передачей tft
  void begin(float initialPres = 760.0);
  void update(float newPres);
  void draw();  // Больше не нужен параметр tft
  void forceUpdate();
  float getPressure();  // Возвращает откалиброванное значение

  // ========== МЕТОДЫ КАЛИБРОВКИ ==========
  void setCalibration(float offset);
  float getCalibration() const;
  void resetCalibration();
  void saveCalibration();  // Сохранить калибровку в EEPROM
  void loadCalibration();  // Загрузить калибровку из EEPROM

private:
  TFT_eSPI& tft;            // Ссылка на дисплей
  float pressure;           // Сырое значение с датчика
  float calibrationOffset;  // Смещение калибровки

  char lastDrawnPresStr[16];  // было String
  char lastDrawnUnitStr[8];   // было String
  uint16_t lastPresColor;
  uint16_t lastUnitColor;
  bool isFirstDraw;

  // Спрайты
  TFT_eSprite spritePres;  // Для цифр давления
  bool spritesInitialized;

  void initSprites();
  void drawNumber();
  void drawUnit();                      // Единицы рисуем напрямую (стандартный шрифт)
  float getCalibratedPressure() const;  // Вспомогательный метод

  // Константы позиционирования
  const int PRESS_X = 290;
  const int PRESS_Y = 235;
  const int UNIT_X = 385;
  const int UNIT_Y = 253;
  const int UNIT_TEXT_HEIGHT = 19;
  static const char UNIT_LABEL[];  // определение в .cpp

  // Адрес в EEPROM (30, чтобы не пересекаться с температурой на 10 и влажностью на 20)
  const int EEPROM_ADDR_PRES = 30;
};

#endif  // PRESSURE_MODULE_H