#include <cstdint>
#include <Arduino.h>
#include <EEPROM.h>
#include <LittleFS.h>
#include "humidity_module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

uint16_t getHumColor(float hum);

const int HUM_X = 290;
const int HUM_Y = 164;

HumidityModule::HumidityModule(TFT_eSPI& tft_ref)
  : tft(tft_ref),
    spriteHum(&tft_ref) {
  isFirstDraw = true;
  spritesInitialized = false;
  humidity = 50.0;
  calibrationOffset = 0.0;
  lastHumColor = TFT_WHITE;
}

// ========== МЕТОДЫ КАЛИБРОВКИ ==========
void HumidityModule::setCalibration(float offset) {
  calibrationOffset = offset;
  forceUpdate();
}

float HumidityModule::getCalibration() const {
  return calibrationOffset;
}

void HumidityModule::resetCalibration() {
  calibrationOffset = 0.0;
  forceUpdate();
}

void HumidityModule::saveCalibration() {
  EEPROM.put(EEPROM_ADDR_HUM, calibrationOffset);
  EEPROM.commit();
  LOG_I("💾 Калибровка влажности сохранена: %.1f%%", calibrationOffset);
}

void HumidityModule::loadCalibration() {
  float savedOffset;
  EEPROM.get(EEPROM_ADDR_HUM, savedOffset);

  // Проверяем, есть ли валидные данные в EEPROM
  if (savedOffset >= -20.0 && savedOffset <= 20.0 && savedOffset != 0.0) {
    calibrationOffset = savedOffset;
    LOG_I("📥 Калибровка влажности загружена: %.1f%%", calibrationOffset);
  } else {
    calibrationOffset = 0.0;
    LOG_I("📥 Калибровка влажности: используется значение по умолчанию (0.0)");
  }
  forceUpdate();
}

// ========== ПОЛУЧЕНИЕ ОТКАЛИБРОВАННОГО ЗНАЧЕНИЯ ==========
float HumidityModule::getCalibratedHumidity() const {
  float result = humidity + calibrationOffset;
  // Ограничиваем влажность разумными пределами 0-100%
  if (result < 0) result = 0;
  if (result > 100) result = 100;
  return result;
}

// ========== ОСТАЛЬНЫЕ МЕТОДЫ ==========

void HumidityModule::initSprite() {
  if (spritesInitialized) return;

  // Вычисляем ширину для максимального значения
  tft.loadFont("cambriai48", LittleFS);
  String maxStr = "100%";
  int textWidth = tft.textWidth(maxStr);
  tft.unloadFont();

  spriteHum.setColorDepth(16);
  spriteHum.createSprite(textWidth + 38, 37);
  spriteHum.setSwapBytes(true);
  spriteHum.loadFont("cambriai48");

  spritesInitialized = true;
}

void HumidityModule::drawHumidity() {
  // Используем ОТКАЛИБРОВАННОЕ значение для отображения
  float displayedHum = getCalibratedHumidity();

  char humStr[16];
  snprintf(humStr, sizeof(humStr), "%.1f", displayedHum);
  const char* unitStr = "%";
  uint16_t newColor = getHumColor(displayedHum);

  // Формируем строку для кэша
  char newStr[24];
  snprintf(newStr, sizeof(newStr), "%s%s", humStr, unitStr);

  // Проверяем, изменилось ли значение или цвет
  if (!isFirstDraw && strcmp(newStr, lastDrawnHumStr) == 0 && newColor == lastHumColor) {
    return;
  }

  spriteHum.fillSprite(TFT_BLACK);

  // Рисуем цифры
  spriteHum.setTextColor(newColor, TFT_BLACK);
  spriteHum.setCursor(0, 0);
  spriteHum.print(humStr);

  // Рисуем единицы со сдвигом (+10 пикселей от конца цифр)
  int humWidth = spriteHum.textWidth(humStr);
  spriteHum.setCursor(humWidth + 10, 0);
  spriteHum.print(unitStr);

  spriteHum.pushSprite(HUM_X, HUM_Y);

  strncpy(lastDrawnHumStr, newStr, sizeof(lastDrawnHumStr) - 1);
  lastDrawnHumStr[sizeof(lastDrawnHumStr) - 1] = '\0';
  lastHumColor = newColor;
}

void HumidityModule::draw() {
  initSprite();
  drawHumidity();
  isFirstDraw = false;
}

void HumidityModule::begin(float initialHum) {
  humidity = initialHum;
  isFirstDraw = true;
  lastDrawnHumStr[0] = '\0';
  lastHumColor = TFT_WHITE;
}

void HumidityModule::update(float newHum) {
  humidity = newHum;
}

void HumidityModule::forceUpdate() {
  isFirstDraw = true;
  lastDrawnHumStr[0] = '\0';
  lastHumColor = TFT_WHITE;
}

float HumidityModule::getHumidity() {
  // Возвращаем ОТКАЛИБРОВАННОЕ значение для прогноза и трендов
  return getCalibratedHumidity();
}