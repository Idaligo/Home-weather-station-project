// menu_module.h
#ifndef MENU_MODULE_H
#define MENU_MODULE_H

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "common.h"

// ==================== КОНСТАНТЫ МЕНЮ ====================
#define MENU_TIMEOUT 30000
#define FIRST_SESSION_DELAY_MS 30000
#define MENU_ITEMS_COUNT 10

// ==================== СТРУКТУРА ДЛЯ НАСТРОЕК ПОДСВЕТКИ ====================
struct BrightnessConfig {
  bool autoMode;
  struct Point {
    uint16_t lux;
    uint8_t brightness;
  };
  Point points[4];
  uint8_t reactionSpeed;
  bool smoothing;
  float calibA;
  float calibB;
  bool autoReturn;
};

// ==================== СТРУКТУРА ДЛЯ КАЛИБРОВОК ДАТЧИКОВ ====================
struct CalibrationConfig {
  // Уличные датчики (по радио)
  float tempOffset;  // температура (улица)
  float humOffset;   // влажность (улица)
  float presOffset;  // давление (улица)
  float sensorHeight;  // ← НОВОЕ: высота над уровнем моря (м), 0..500

  // Внутренние датчики (BME280)
  float bmeTempOffset;  // температура BME280
  float bmeHumOffset;   // влажность BME280
};

// ==================== СТРУКТУРА ДЛЯ НАСТРОЕК ВРЕМЕНИ ====================
struct TimeConfig {
  uint8_t hours;
  uint8_t minutes;
  uint8_t seconds;
  uint8_t day;
  uint8_t month;
  uint16_t year;
  uint8_t dayOfWeek;  // 0-6 (Пн-Вс)
};

// ==================== СТРУКТУРА ДЛЯ НАСТРОЕК ТРЕНДОВ ====================
struct TrendsConfig {
  // Температура
  float tempFastUp;
  float tempSlowUp;
  float tempFastDown;
  float tempSlowDown;
  float tempFastOffRatio;
  float tempSlowOffRatio;

  // Влажность
  float humFastUp;
  float humSlowUp;
  float humFastDown;
  float humSlowDown;
  float humFastOffRatio;
  float humSlowOffRatio;

  // Давление
  float presFastUp;
  float presSlowUp;
  float presFastDown;
  float presSlowDown;
  float presFastOffRatio;
  float presSlowOffRatio;
};

// ==================== ФУНКЦИИ ====================
void enterMenuMode();
void exitMenuMode();
void redrawMainScreen();
void drawMenu();
void handleMenuNavigation();
void handleMenuItemSelected(int index);

// ==================== ФУНКЦИИ ПОДСВЕТКИ ====================
void loadBrightnessConfig();
void saveBrightnessConfig();
void resetBrightnessConfig();
void applyBrightnessConfig();
void syncBrightnessConfig();

// ==================== ФУНКЦИИ КАЛИБРОВОК ====================
void loadCalibrationConfig();
void saveCalibrationConfig();
void resetCalibrationConfig(bool resetStreet, bool resetHome);
void applyCalibrationConfig();
void showResetCalibrationConfirmation(const char* title, int type);

// ==================== ФУНКЦИИ ВРЕМЕНИ ====================
void loadTimeConfig();
void saveTimeConfig();
void applyTimeConfig();
void loadTimeFromRTC();
void drawTimeMenu();
void handleTimeMenu();
void handleTimeValueChange(bool increase);

// ==================== ФУНКЦИИ ТРЕНДОВ ====================
void loadTrendsConfig();
void saveTrendsConfig();
void applyTrendsConfig();
void resetTrendsConfig();
void drawTrendsMenu();
void handleTrendsMenu();
void drawTrendsSubMenu();
void handleTrendsEdit(int key);
float getTrendsValue(int type, int index);
void setTrendsValue(int type, int index, float val);
void saveTrendsChanges();
void discardTrendsChanges();
void showResetTrendsConfirmation();

// ==================== ФУНКЦИЯ О СИСТЕМЕ ====================
void rebuildSystemLines();
void drawSystemInfo();
void drawSystemInfoLine(int idx, bool selected);
void drawSystemInfoNav();
void handleSystemInfo();

// ==================== ФУНКЦИИ WI-FI ====================
void loadWiFiConfig();
void saveWiFiConfig();
void applyWiFiConfig();

void drawWiFiMenu();
void handleWiFiMenu();

// ==================== ФУНКЦИИ МЕСТОПОЛОЖЕНИЯ ====================
void loadLocationConfig();
void saveLocationConfig();
void applyLocationConfig();

// ==================== ФУНКЦИИ ИСТОЧНИКА ПРОГНОЗА ====================
void drawForecastSourceMenu();
void handleForecastSourceMenu();

// ==================== ФУНКЦИИ ПРОГНОЗА ====================
void loadForecastConfig();
void saveForecastConfig();
void applyForecastConfig();

// ==================== РАСПИСАНИЕ / СЕАНСЫ ====================  // ← НОВОЕ
void updateWiFiSchedule();         // вызывается из loop()
bool performForecastUpdate();      // вкл Wi-Fi → запрос → выкл
void confirmAndRefreshForecast();  // диалог «Обновить?» Да/Нет

// ==================== ОБЩИЙ ДИАЛОГ ПОДТВЕРЖДЕНИЯ ====================  // ← НОВОЕ
bool showConfirmDialog(const char* title, const char* line1, const char* line2);

#endif  // MENU_MODULE_H