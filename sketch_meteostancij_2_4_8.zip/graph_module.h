// graph_module.h
#ifndef GRAPH_MODULE_H
#define GRAPH_MODULE_H

#include <Arduino.h>
#include <TFT_eSPI.h>

// ==================== КОНСТАНТЫ ====================
#define GRAPH_PARAMS 3   // T, H, P
#define GRAPH_PERIODS 3  // 24ч, 7д, 30д
#define GRAPH_TOTAL 9    // 3×3

#define GRAPH_HOURS 24
#define GRAPH_WEEK 7
#define GRAPH_MONTH 30

#define GRAPH_TIMEOUT_MS 60000

// ==================== ДАННЫЕ ГРАФИКОВ ====================
extern float tempHour[GRAPH_HOURS];
extern float humHour[GRAPH_HOURS];
extern float presHour[GRAPH_HOURS];
extern int hourIndex;
extern bool hourFilled;

extern float tempWeek[GRAPH_WEEK];
extern float humWeek[GRAPH_WEEK];
extern float presWeek[GRAPH_WEEK];
extern int weekIndex;
extern bool weekFilled;

extern float tempMonth[GRAPH_MONTH];
extern float humMonth[GRAPH_MONTH];
extern float presMonth[GRAPH_MONTH];
extern int monthIndex;
extern bool monthFilled;

// ==================== ФУНКЦИИ ====================
void enterGraphsMode();
void exitGraphsMode();
void handleGraphsNavigation();
void drawGraphScreen();

// Заполнение массивов (вызывается из main.ino в :00 и при смене дня)
void graphAddHour(float t, float h, float p);
void graphAddDay(float t, float h, float p);

// Загрузка с SD (при старте, после initSD)
void loadGraphsFromArchive();

#endif  // GRAPH_MODULE_H