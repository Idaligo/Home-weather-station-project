#ifndef RTC_MODULE_H
#define RTC_MODULE_H

#include <TFT_eSPI.h>
#include <Wire.h>
#include <RTClib.h>

class RTCModule {
public:
  RTCModule();

  void begin(TwoWire& wire, uint8_t addr = 0x68, int sda = 1, int scl = 2);
  void begin(uint8_t addr = 0x68, int sda = 1, int scl = 2);

  void forceUpdate();
  void update();
  void draw(TFT_eSPI& tft);
  void setDateTime(DateTime dt);
  const DateTime& getTime() const;
  bool isRunning();

private:
  RTC_DS3231 rtc;
  DateTime now;
  unsigned long lastUpdate;
  bool isFirstDraw;
  void getDayOfWeekString(char* buffer);

  int lastDow;
  int lastDateDay;
  int lastDateMonth;
  int lastDateYear;

  // ===== КЭШ СОСТОЯНИЯ =====
  bool frameDrawn;
  char lastHours[3];
  char lastMinutes[3];
  bool colonDrawn;  // было нарисовано двоеточие или нет

  TwoWire* _wire;
};

#endif