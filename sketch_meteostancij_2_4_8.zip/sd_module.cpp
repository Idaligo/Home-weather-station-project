// sd_module.cpp
#include "sd_module.h"
#include "common.h"
#include "rtc_module.h"
#include "logger.h"
#include <SPI.h>
#include <EEPROM.h>

extern RTCModule rtcClock;

#if ARDUINO_USB_CDC_ON_BOOT

#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ===================================================================
// УТИЛИТА: чтение файла с конца блоками
// ===================================================================
bool readFileBackwards(File& f, bool (*callback)(const char* line, void* ctx),
                       void* ctx, size_t blockSize) {
  if (!f) return false;
  size_t fileSize = f.size();
  if (fileSize == 0) return false;

  char carry[160];
  size_t carryLen = 0;

  size_t pos = fileSize;

  while (pos > 0) {
    size_t toRead = (pos >= blockSize) ? blockSize : pos;
    pos -= toRead;

    if (!f.seek(pos)) return false;

    char buf[256];
    size_t got = f.read((uint8_t*)buf, toRead);
    if (got == 0) return false;

    int i = (int)got - 1;

    while (i >= 0) {
      int lineEnd = i + 1;
      int lineStart = i;
      while (lineStart >= 0 && buf[lineStart] != '\n') lineStart--;
      lineStart++;

      int lineLen = lineEnd - lineStart;

      char line[256];
      if (lineLen + carryLen >= sizeof(line)) {
        carryLen = 0;
        i = lineStart - 2;
        continue;
      }
      memcpy(line, buf + lineStart, lineLen);
      memcpy(line + lineLen, carry, carryLen);
      size_t totalLen = lineLen + carryLen;
      line[totalLen] = '\0';

      while (totalLen > 0 && (line[totalLen - 1] == '\r' || line[totalLen - 1] == '\0')) {
        line[--totalLen] = '\0';
      }

      if (totalLen > 0) {
        if (callback(line, ctx)) return true;
      }
      carryLen = 0;
      i = lineStart - 2;
    }

    if (i < 0) {
      int tailStart = 0;
      while (tailStart < (int)got && buf[tailStart] != '\n') tailStart++;
      int tailLen = tailStart;
      if (tailLen > 0 && tailLen + carryLen < sizeof(carry)) {
        memmove(carry + tailLen, carry, carryLen);
        memcpy(carry, buf, tailLen);
        carryLen += tailLen;
      }
    }
  }

  if (carryLen > 0) {
    while (carryLen > 0 && (carry[carryLen - 1] == '\r' || carry[carryLen - 1] == '\0')) {
      carry[--carryLen] = '\0';
    }
    if (carryLen > 0) {
      carry[carryLen] = '\0';
      if (callback(carry, ctx)) return true;
    }
  }

  return false;
}

// ==================== СОСТОЯНИЕ ====================
bool sdReady = false;
bool sdSafeToRemove = false;
bool sdLoggingEnabled = true;  // По умолчанию включено
static int lastHeaderDay = -1;

#define EEPROM_ADDR_SD_ENABLED 500

// ===================================================================
// ИНИЦИАЛИЗАЦИЯ SD (VSPI, отдельные пины)
// ===================================================================
bool initSD(bool isSilent) {
  if (!isSilent) {
    LOG_I("=== SD INIT (VSPI 39/41/40/6) ===");
  }

  // ===== ПРИНУДИТЕЛЬНЫЙ СБРОС ПРЕДЫДУЩЕГО СОСТОЯНИЯ =====
  // Если SD уже был инициализирован ранее (горячая замена) — размонтируем
  if (sdReady || SD.cardType() != CARD_NONE) {
    if (!isSilent) LOG_I("SD: принудительный SD.end()...");
    SD.end();
    delay(100);  // даём файловой системе «остыть»
  }

  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
  delay(10);

  // VSPI на отдельных пинах (TFT/nRF на HSPI — не трогаем)
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  delay(10);

  if (!SD.begin(SD_CS, SPI, 1000000)) {
    if (!isSilent) LOG_E("SD: FAIL");
    sdReady = false;
    return false;
  }

  // ===== ПРОВЕРКА, ЧТО ФАЙЛОВАЯ СИСТЕМА РЕАЛЬНО ДОСТУПНА =====
  // SD.begin() может вернуть true, но open() — nullptr (баг после hot-swap)
  File test = SD.open("/", FILE_READ);
  if (!test) {
    if (!isSilent) LOG_E("SD: begin OK, но open(/) FAIL — карта не готова");
    SD.end();
    sdReady = false;
    return false;
  }
  test.close();

  if (!isSilent) {
    LOG_I("SD: OK");
    LOG_I("  Card type: %d", SD.cardType());
    LOG_I("  Card size: %llu MB", SD.cardSize() / (1024ULL * 1024ULL));
  }

  sdReady = true;
  sdSafeToRemove = false;
  return true;
}

// ===================================================================
// ТЕСТ SD (диагностика, вызывать вручную)
// ===================================================================
bool testSD() {
  LOG_I("=== SD TEST ===");

  if (!sdReady) {
    if (!initSD()) {
      LOG_E("=== END SD TEST (FAIL) ===");
      return false;
    }
  }

  File root = SD.open("/");
  int n = 0;
  while (File f = root.openNextFile()) {
    LOG_I("  %s (%d)", f.name(), f.size());
    n++;
    f.close();
  }
  root.close();
  LOG_I("  Files: %d", n);

  File w = SD.open("/test.txt", FILE_WRITE);
  if (w) {
    w.println("hello");
    w.close();
    LOG_I("  write OK");
  }
  File r = SD.open("/test.txt", FILE_READ);
  if (r) {
    LOG_I("  read: %s", r.readString().c_str());
    r.close();
  }

  LOG_I("=== END SD TEST ===");
  return true;
}

// ===================================================================
// ПРОВЕРКА, ЧТО КАРТА НА МЕСТЕ
// ===================================================================
bool checkSD() {
  if (sdSafeToRemove) return false;

  static bool lastCheckFailed = false;  // флаг для логов

  // ===== SD не готова — пробуем переинициализировать =====
  if (!sdReady) {
    static unsigned long lastRetry = 0;
    if (millis() - lastRetry < 3000) return false;
    lastRetry = millis();

    // Пытаемся тихо. Если получилось — пишем лог, что ожили.
    if (initSD(true)) {
      LOG_I("SD: переинициализирована (оживление)");
      flushBufferToSD();
      restoreCurrentHour();  // ← ДОБАВИТЬ: восстановить текущий час, если в RAM пусто
      restoreDailyStats();
      lastCheckFailed = false;
      return true;
    }

    // Если не получилось — пишем только ПЕРВЫЙ раз, чтобы не спамить
    if (!lastCheckFailed) {
      LOG_E("SD: FAIL (карта не найдена или ошибка)");
      lastCheckFailed = true;
    }
    return false;
  }

  // ===== SD готова — проверяем, на месте ли карта =====
  // Используем open("/"), т.к. cardType() может кэшировать старое состояние
  File test = SD.open("/", FILE_READ);
  if (!test) {
    LOG_E("SD: карта извлечена (open FAIL)");
    sdReady = false;
    SD.end();
    lastCheckFailed = true;
    return false;
  }
  test.close();
  return true;
}

// ===================================================================
// ЗАГРУЗКА / СОХРАНЕНИЕ НАСТРОЙКИ SD
// ===================================================================
void loadSdConfig() {
  uint8_t val = EEPROM.read(EEPROM_ADDR_SD_ENABLED);
  // Если EEPROM пустая (0xFF) — по умолчанию Вкл (true)
  if (val == 0xFF) {
    sdLoggingEnabled = true;
  } else {
    sdLoggingEnabled = (val == 1);
  }
  LOG_I("📥 SD-логирование: %s", sdLoggingEnabled ? "ВКЛ" : "ВЫКЛ");
}

void saveSdConfig() {
  EEPROM.write(EEPROM_ADDR_SD_ENABLED, sdLoggingEnabled ? 1 : 0);
  EEPROM.commit();
  LOG_I("💾 SD-логирование: %s", sdLoggingEnabled ? "ВКЛ" : "ВЫКЛ");
}

// ===================================================================
// БЕЗОПАСНОЕ ИЗВЛЕЧЕНИЕ
// ===================================================================
void deinitSD() {
  if (!sdReady) return;
  SD.end();
  sdReady = false;
  sdSafeToRemove = true;
  LOG_I("SD: safe to remove");
}

// ===================================================================
// БУФЕР СЫРЫХ ДАННЫХ
// ===================================================================
static RawData dataBuffer[SD_BUFFER_SIZE];
static int bufferCount = 0;
static bool bufferOverflow = false;

int getBufferCount() {
  return bufferCount;
}

// ===================================================================
// ИМЕНА ФАЙЛОВ
// ===================================================================
void getArchiveFileName(char* buf, size_t bufSize, const char* type, int year, int month) {
  snprintf(buf, bufSize, "/%s_%04d-%02d.csv", type, year, month);
}

void getLogFileName(char* buf, size_t bufSize, int year, int month) {
  snprintf(buf, bufSize, "/month_%04d-%02d.csv", year, month);
}

// ===================================================================
// SAVE RAW DATA — В RAM-БУФЕР (горячий путь)
// ===================================================================
void saveRawData(float temp, float hum, float pres) {
  uint32_t ts = rtcClock.getTime().unixtime();

  if (bufferCount < SD_BUFFER_SIZE) {
    dataBuffer[bufferCount].unixTime = ts;
    dataBuffer[bufferCount].temp = temp;
    dataBuffer[bufferCount].hum = hum;
    dataBuffer[bufferCount].pres = pres;
    bufferCount++;
  } else {
    for (int i = 0; i < SD_BUFFER_SIZE - 1; i++) dataBuffer[i] = dataBuffer[i + 1];
    dataBuffer[SD_BUFFER_SIZE - 1] = { ts, temp, hum, pres };
    bufferOverflow = true;
  }
}

// ===================================================================
// FLUSH BUFFER TO SD
// ===================================================================
void flushBufferToSD() {
  if (!sdReady || sdSafeToRemove) return;
  if (bufferCount == 0) return;

  LOG_I("SD flush: %d записей...", bufferCount);

  File f = SD.open("/raw_hourly.csv", FILE_APPEND);
  if (!f) {
    LOG_E("SD flush: FAIL — карта недоступна, помечаем sdReady=false");
    sdReady = false;  // checkSD() попробует переинициализировать
    return;           // буфер НЕ очищаем — данные сохранятся
  }

  for (int i = 0; i < bufferCount; i++) {
    DateTime dt(dataBuffer[i].unixTime);
    char line[80];
    snprintf(line, sizeof(line), "%04d-%02d-%02d %02d:%02d:%02d;%.1f;%.1f;%.1f\n",
             dt.year(), dt.month(), dt.day(),
             dt.hour(), dt.minute(), dt.second(),
             dataBuffer[i].temp, dataBuffer[i].hum, dataBuffer[i].pres);
    for (char* p = line; *p; p++)
      if (*p == '.') *p = ',';
    f.print(line);
  }
  f.close();

  LOG_I("SD flush: OK (%d)", bufferCount);
  bufferCount = 0;
  bufferOverflow = false;
}

// ===================================================================
// SAVE HOURLY ARCHIVE
// ===================================================================
void saveHourlyArchive(uint32_t unixTime, float temp, float hum, float pres) {
  if (!sdReady || sdSafeToRemove) return;

  // ===== ЗАЩИТА ОТ NaN/INF =====
  if (isnan(temp) || isnan(hum) || isnan(pres) || isinf(temp) || isinf(hum) || isinf(pres)) {
    LOG_W("hourly: пропуск (NaN/INF)");
    return;
  }
  if (temp < -50 || temp > 60 || hum < 0 || hum > 100 || pres < 600 || pres > 850) {
    LOG_W("hourly: пропуск (вне диапазона)");
    return;
  }

  DateTime dt(unixTime);
  char fname[32];
  getArchiveFileName(fname, sizeof(fname), "hourly", dt.year(), dt.month());

  File f = SD.open(fname, FILE_APPEND);
  if (!f) {
    LOG_E("hourly: FAIL");
    return;
  }

  char line[80];
  snprintf(line, sizeof(line), "%04d-%02d-%02d %02d:%02d:00;%.1f;%.1f;%.1f\n",
           dt.year(), dt.month(), dt.day(), dt.hour(), dt.minute(),
           temp, hum, pres);
  for (char* p = line; *p; p++)
    if (*p == '.') *p = ',';
  f.print(line);
  f.close();
  LOG_I("hourly: OK (%s)", fname);
}

// ===================================================================
// ОЧИСТКА RAW_HOURLY.CSV (вызывается после записи часового архива)
// ===================================================================
void clearRawHourly() {
  if (!sdReady || sdSafeToRemove) return;

  // Открытие в режиме FILE_WRITE (без APPEND) обнуляет файл
  File f = SD.open("/raw_hourly.csv", FILE_WRITE);
  if (f) {
    f.close();
    LOG_I("🧹 raw_hourly.csv очищен (новый час)");
  } else {
    LOG_W("⚠️ Не удалось очистить raw_hourly.csv");
  }
}

// ===================================================================
// SAVE DAILY ARCHIVE
// ===================================================================
void saveDailyArchive(uint32_t unixTime,
                      float tempAvg, float tempMin, float tempMax,
                      float humAvg, float humMin, float humMax,
                      float presAvg, float presMin, float presMax, int count) {
  if (!sdReady || sdSafeToRemove) return;

  // ===== ЗАЩИТА ОТ NaN/INF =====
  // Если хотя бы одно значение NaN/INF или вне разумных пределов —
  // не пишем строку (лучше пропустить день, чем записать мусор).
  if (isnan(tempAvg) || isnan(tempMin) || isnan(tempMax) || isnan(humAvg) || isnan(humMin) || isnan(humMax) || isnan(presAvg) || isnan(presMin) || isnan(presMax) || isinf(tempAvg) || isinf(tempMin) || isinf(tempMax) || isinf(humAvg) || isinf(humMin) || isinf(humMax) || isinf(presAvg) || isinf(presMin) || isinf(presMax)) {
    LOG_W("daily: пропуск (NaN/INF в данных)");
    return;
  }
  if (tempAvg < -50 || tempAvg > 60 || tempMin < -50 || tempMin > 60 || tempMax < -50 || tempMax > 60 || humAvg < 0 || humAvg > 100 || humMin < 0 || humMin > 100 || humMax < 0 || humMax > 100 || presAvg < 600 || presAvg > 850 || presMin < 600 || presMin > 850 || presMax < 600 || presMax > 850) {
    LOG_W("daily: пропуск (значения вне диапазона)");
    return;
  }

  DateTime dt(unixTime);
  char fname[32];
  getArchiveFileName(fname, sizeof(fname), "daily", dt.year(), dt.month());

  bool exists = SD.exists(fname);
  File f = SD.open(fname, FILE_APPEND);
  if (!f) {
    LOG_E("daily: FAIL");
    return;
  }

  if (!exists) {
    f.println("date;temp_avg;temp_min;temp_max;hum_avg;hum_min;hum_max;pres_avg;pres_min;pres_max;count");
  }

  char line[160];
  snprintf(line, sizeof(line), "%04d-%02d-%02d;%.1f;%.1f;%.1f;%.1f;%.1f;%.1f;%.1f;%.1f;%.1f;%d\n",
           dt.year(), dt.month(), dt.day(),
           tempAvg, tempMin, tempMax,
           humAvg, humMin, humMax,
           presAvg, presMin, presMax, count);
  for (char* p = line; *p; p++)
    if (*p == '.') *p = ',';
  f.print(line);
  f.close();
  LOG_I("daily: OK (%s)", fname);
}

// ===================================================================
// WRITE LOG (месячный лог, с заголовком дня)
// ===================================================================
void writeLog(uint32_t unixTime, float temp, float hum, float pres) {
  if (!sdReady || sdSafeToRemove) return;

  // ===== ЗАЩИТА ОТ NaN/INF =====
  if (isnan(temp) || isnan(hum) || isnan(pres) || isinf(temp) || isinf(hum) || isinf(pres)) {
    LOG_W("log: пропуск (NaN/INF)");
    return;
  }
  if (temp < -50 || temp > 60 || hum < 0 || hum > 100 || pres < 600 || pres > 850) {
    LOG_W("log: пропуск (вне диапазона)");
    return;
  }

  DateTime dt(unixTime);
  char fname[32];
  getLogFileName(fname, sizeof(fname), dt.year(), dt.month());

  bool exists = SD.exists(fname);
  File f = SD.open(fname, FILE_APPEND);
  if (!f) {
    LOG_E("log: FAIL");
    return;
  }

  // ===== Проверка: был ли уже заголовок этого дня? =====
  // Используем RAM-флаг lastHeaderDay, а не поиск в файле: поиск
  // в последних 200 байтах ненадёжен — после заголовка идёт 24 строки
  // часов, и заголовок «уезжает» за 200 байт → писался бы каждый час.
  // RAM-флаг теряется при перезагрузке, но это даёт максимум один
  // лишний заголовок при перезагрузке, а не 24.
  bool needHeader = (lastHeaderDay != dt.day());

  // Страховка: если файл только что создан (!exists) — заголовок пишем ВСЕГДА,
  // даже если lastHeaderDay случайно равен dt.day() (защита от «тёмных» случаев).
  if (!exists || needHeader) {
    if (exists) f.println();
    char hdr[48];
    snprintf(hdr, sizeof(hdr), "=== %04d-%02d-%02d ===",
             dt.year(), dt.month(), dt.day());
    f.println(hdr);
    f.println("time;temp;hum;pres");
    LOG_I("📅 Новый день: %04d-%02d-%02d", dt.year(), dt.month(), dt.day());
    lastHeaderDay = dt.day();
  }

  char line[80];
  snprintf(line, sizeof(line), "%02d:%02d:%02d;%.1f;%.1f;%.1f\n",
           dt.hour(), dt.minute(), dt.second(),
           temp, hum, pres);
  for (char* p = line; *p; p++)
    if (*p == '.') *p = ',';
  f.print(line);
  f.close();
}

// ===================================================================
// СРАВНЕНИЕ: вчера в тот же час (чтение с конца файла)
// ===================================================================
struct CompareCtx {
  char prefix[24];
  float t, h, p;
  bool found;
  bool badLine;
};

static bool compareCallback(const char* line, void* ctx) {
  CompareCtx* c = (CompareCtx*)ctx;
  if (strlen(line) < 20) return false;
  if (strncmp(line, c->prefix, strlen(c->prefix)) != 0) return false;

  float tt, hh, pp;
  if (!parseCsvLine(line, &tt, &hh, &pp)) {
    c->badLine = true;
    return true;
  }
  if (tt < -50.0f || tt > 60.0f || hh < 0.0f || hh > 100.0f || pp < 600.0f || pp > 850.0f) {
    c->badLine = true;
    return true;
  }
  c->t = tt;
  c->h = hh;
  c->p = pp;
  c->found = true;
  return true;
}

bool loadHourlyForCompare(uint8_t hour, float* t, float* h, float* p) {
  if (!sdReady || sdSafeToRemove) return false;

  DateTime now = rtcClock.getTime();
  DateTime yesterday = now - TimeSpan(1, 0, 0, 0);

  char fname[32];
  getArchiveFileName(fname, sizeof(fname), "hourly",
                     yesterday.year(), yesterday.month());

  File f = SD.open(fname, FILE_READ);
  if (!f) {
    LOG_D("compare: нет файла %s", fname);
    return false;
  }

  CompareCtx ctx;
  ctx.found = false;
  ctx.badLine = false;
  snprintf(ctx.prefix, sizeof(ctx.prefix), "%04d-%02d-%02d %02d:",
           yesterday.year(), yesterday.month(), yesterday.day(), hour);

  readFileBackwards(f, compareCallback, &ctx, 256);
  f.close();

  if (ctx.found) {
    *t = ctx.t;
    *h = ctx.h;
    *p = ctx.p;
    LOG_D("compare: вчера %02d:00 → T=%.1f H=%.1f P=%.1f",
          hour, *t, *h, *p);
    return true;
  }
  if (ctx.badLine) {
    LOG_D("compare: вчера %02d:00 — битая строка", hour);
  } else {
    LOG_D("compare: нет данных за вчера %02d:00", hour);
  }
  return false;
}
// ===================================================================
// ВНЕШНЯЯ ЗАВИСИМОСТЬ: RTC
// ===================================================================
// ВНИМАНИЕ: rtcClock объявлен в main.ino, доступен через extern
// ===================================================================
// ВОССТАНОВЛЕНИЕ СРЕДНИХ ЗА ТЕКУЩИЙ ЧАС ИЗ raw_hourly.csv
// ===================================================================
// Вызывается при старте (setup) и при «оживлении» SD (checkSD).
// Берёт только строки, у которых timestamp попадает в текущий час
// (год/месяц/день/час из RTC). Строки за прошлые часы игнорируются —
// это защита от сценария «карту вынули в :00, clearRawHourly не сработал».
// Битые и обрезанные строки (сбой питания) пропускаются.
// ===================================================================

// Внешние накопители из main.ino
extern float hourSumTemp;
extern float hourSumHum;
extern float hourSumPres;
extern int hourMeasCount;

static bool currentHourRestored = false;  // ← флаг: уже восстанавливали в этой сессии

void restoreCurrentHour() {
  if (!sdReady || sdSafeToRemove) return;

  if (currentHourRestored) {
    LOG_D("🔄 restoreCurrentHour: уже восстанавливали, пропуск (в RAM %d)",
          hourMeasCount);
    return;
  }

  File f = SD.open("/raw_hourly.csv", FILE_READ);
  if (!f) {
    LOG_D("🔄 restoreCurrentHour: raw_hourly.csv не найден");
    return;
  }

  // Текущий час из RTC
  DateTime now = rtcClock.getTime();
  if (now.year() < 2024) {
    LOG_W("🔄 restoreCurrentHour: RTC невалиден, пропуск");
    f.close();
    return;
  }

  // Префикс для сравнения: "YYYY-MM-DD HH:"
  char prefix[20];
  snprintf(prefix, sizeof(prefix), "%04d-%02d-%02d %02d:",
           now.year(), now.month(), now.day(), now.hour());

  float sumT = 0.0f, sumH = 0.0f, sumP = 0.0f;
  int count = 0;
  int skippedOld = 0;
  int skippedBad = 0;

  char line[80];
  while (f.available()) {
    size_t len = f.readBytesUntil('\n', line, sizeof(line) - 1);
    if (len == 0) continue;
    line[len] = '\0';

    // Убираем \r, если файл с CRLF
    if (len > 0 && line[len - 1] == '\r') line[len - 1] = '\0';

    // Пропускаем пустые и слишком короткие
    if (strlen(line) < 20) {
      skippedBad++;
      continue;
    }

    // Только текущий час
    if (strncmp(line, prefix, strlen(prefix)) != 0) {
      skippedOld++;
      continue;
    }

    // Парсим T;H;P после первого ';'
    float t, h, p;
    if (!parseCsvLine(line, &t, &h, &p)) {
      skippedBad++;
      continue;
    }

    // Проверка диапазонов — отсекаем мусор от обрезанных строк
    if (t < -50.0f || t > 60.0f) {
      skippedBad++;
      continue;
    }
    if (h < 0.0f || h > 100.0f) {
      skippedBad++;
      continue;
    }
    if (p < 600.0f || p > 850.0f) {
      skippedBad++;
      continue;
    }

    sumT += t;
    sumH += h;
    sumP += p;
    count++;
  }
  f.close();

  if (count > 0) {
    hourSumTemp = sumT;
    hourSumHum = sumH;
    hourSumPres = sumP;
    hourMeasCount = count;
    LOG_I("🔄 restoreCurrentHour: восстановлено %d измерений (T=%.1f H=%.1f P=%.1f)",
          count, sumT / count, sumH / count, sumP / count);
    currentHourRestored = true;
  } else {
    LOG_D("🔄 restoreCurrentHour: нет данных за текущий час (старых: %d, битых: %d)",
          skippedOld, skippedBad);
  }
}

// ===================================================================
// ВОССТАНОВЛЕНИЕ ДНЕВНОЙ СТАТИСТИКИ ИЗ month_YYYY-MM.csv
// ===================================================================
// Вызывается при старте (setup) и при «оживлении» SD (checkSD).
// Читает блок "=== YYYY-MM-DD ===" за СЕГОДНЯ и восстанавливает
// daySum*/dayMin*/dayMax*/dayMeasCount по часовым строкам.
// Точность — до часа (не до секунды). dayMeasCount = число часовых
// записей за сегодня, а не число пакетов — честно отражает точность.
// ===================================================================

// Внешние накопители из main.ino
extern float daySumTemp, dayMinTemp, dayMaxTemp;
extern float daySumHum, dayMinHum, dayMaxHum;
extern float daySumPres, dayMinPres, dayMaxPres;
extern int dayMeasCount;

static bool dailyStatsRestored = false;  // ← флаг: уже восстанавливали в этой сессии

void restoreDailyStats() {
  if (!sdReady || sdSafeToRemove) return;

  // Пропускаем, только если УЖЕ восстанавливали в этой сессии
  // (при «оживлении» карты — RAM свежее). Но если ещё не восстанавливали
  // (первый вызов после старта), восстанавливаем ДАЖЕ если dayMeasCount > 0
  // (1 пакет успел прийти до карты — потеряем его, но восстановим N часов).
  if (dailyStatsRestored) {
    LOG_D("📊 restoreDailyStats: уже восстанавливали, пропуск (в RAM %d)", dayMeasCount);
    return;
  }

  DateTime now = rtcClock.getTime();
  if (now.year() < 2024) {
    LOG_W("📊 restoreDailyStats: RTC невалиден, пропуск");
    return;
  }

  char fname[32];
  getLogFileName(fname, sizeof(fname), now.year(), now.month());

  File f = SD.open(fname, FILE_READ);
  if (!f) {
    LOG_D("📊 restoreDailyStats: %s не найден", fname);
    return;
  }

  // Заголовок сегодняшнего дня
  char dayHeader[32];
  snprintf(dayHeader, sizeof(dayHeader), "=== %04d-%02d-%02d ===",
           now.year(), now.month(), now.day());

  bool inTodayBlock = false;
  bool foundToday = false;

  float sumT = 0.0f, sumH = 0.0f, sumP = 0.0f;
  float minT = 999.0f, maxT = -999.0f;
  float minH = 999.0f, maxH = -999.0f;
  float minP = 9999.0f, maxP = -999.0f;
  int count = 0;
  int skippedBad = 0;

  char line[80];
  while (f.available()) {
    size_t len = f.readBytesUntil('\n', line, sizeof(line) - 1);
    if (len == 0) continue;
    line[len] = '\0';
    if (len > 0 && line[len - 1] == '\r') line[len - 1] = '\0';

    // Заголовок дня?
    if (strncmp(line, "=== ", 4) == 0) {
      if (inTodayBlock) {
        // Начался следующий день — сегодняшний блок закончился
        break;
      }
      if (strcmp(line, dayHeader) == 0) {
        inTodayBlock = true;
        foundToday = true;
        // Восстанавливаем lastHeaderDay, чтобы после перезагрузки
        // writeLog() не написал заголовок повторно.
        lastHeaderDay = now.day();
        // Следующая строка — "time;temp;hum;pres" (заголовок колонок),
        // её пропустит проверка диапазонов ниже.
      }
      continue;
    }

    if (!inTodayBlock) continue;

    // Пропускаем строку заголовка колонок "time;temp;hum;pres"
    if (strncmp(line, "time;", 5) == 0) continue;

    // Парсим T;H;P (parseCsvLine ищет после первой ';')
    float t, h, p;
    if (!parseCsvLine(line, &t, &h, &p)) {
      skippedBad++;
      continue;
    }

    // Диапазоны
    if (t < -50.0f || t > 60.0f) {
      skippedBad++;
      continue;
    }
    if (h < 0.0f || h > 100.0f) {
      skippedBad++;
      continue;
    }
    if (p < 600.0f || p > 850.0f) {
      skippedBad++;
      continue;
    }

    sumT += t;
    sumH += h;
    sumP += p;
    if (t < minT) minT = t;
    if (t > maxT) maxT = t;
    if (h < minH) minH = h;
    if (h > maxH) maxH = h;
    if (p < minP) minP = p;
    if (p > maxP) maxP = p;
    count++;
  }
  f.close();

  if (count > 0) {
    daySumTemp = sumT;
    dayMinTemp = minT;
    dayMaxTemp = maxT;
    daySumHum = sumH;
    dayMinHum = minH;
    dayMaxHum = maxH;
    daySumPres = sumP;
    dayMinPres = minP;
    dayMaxPres = maxP;
    dayMeasCount = count;
    LOG_I("📊 restoreDailyStats: восстановлено %d часов (T=%.1f H=%.1f P=%.1f)",
          count, sumT / count, sumH / count, sumP / count);
    dailyStatsRestored = true;
  } else {
    if (foundToday) {
      LOG_D("📊 restoreDailyStats: блок за сегодня пуст (битых: %d)", skippedBad);
    } else {
      LOG_D("📊 restoreDailyStats: нет блока за сегодня в %s", fname);
    }
  }
}