#ifndef WEATHER_FORECAST_H
#define WEATHER_FORECAST_H

#include <Arduino.h>
#include <TFT_eSPI.h>

// ==================== КОДЫ ПОГОДЫ ====================
#define WEATHER_CLEAR 0          // Ясно
#define WEATHER_MOSTLY_CLEAR 1   // Малооблачно
#define WEATHER_PARTLY_CLOUDY 2  // Переменная облачность
#define WEATHER_CLOUDY 3         // Пасмурно
#define WEATHER_FOG 4            // Туман
#define WEATHER_DRIZZLE 5        // Морось
#define WEATHER_RAIN 6           // Дождь
#define WEATHER_HEAVY_RAIN 7     // Сильный дождь
#define WEATHER_LIGHT_SNOW 8     // Небольшой снег
#define WEATHER_SNOW 9           // Снег
#define WEATHER_SNOW_SHOWERS 10  // Снегопад
#define WEATHER_SLEET 11         // Дождь со снегом
#define WEATHER_HAIL 12          // Град
#define WEATHER_THUNDER 13       // Гроза
#define WEATHER_UNKNOWN 14       // Неизвестно

// ==================== НАСТРОЙКИ ====================
#define HISTORY_SIZE 144  // ← ИЗМЕНЕНО: 144 записи = 24 часа (было 24)
#define ICON_SIZE 104     // Размер иконки в пикселях

// ==================== СТРУКТУРА ЗАПИСИ ====================
struct WeatherRecord {
  unsigned long timestamp;
  float temperature;
  float humidity;
  float pressure;
};

// ==================== КЛАСС ПРОГНОЗА ====================
class WeatherForecast {
public:
  WeatherForecast();

  void addMeasurement(float temp, float hum, float pressure);
  bool isDataAvailable();  // ← ИЗМЕНЕНО: теперь метод в cpp
  int getRecordCount();    // ← НОВЫЙ: для отладки
  void printHistory();

  int getCurrentWeatherCode();
  String getCurrentWeatherText();
  String getCurrentWeatherEmoji();

  int getForecastCode();
  const char* getForecastText();

  float getPressureTrend(int hoursBack);
  float getTemperatureTrend(int hoursBack);
  int getRainProbability();

  bool isNightTime();

  void drawCurrentWeatherIcon(TFT_eSPI& tft, int x, int y);
  void drawForecastIcon(TFT_eSPI& tft, int x, int y);

  float getHumidityTrend(int hoursBack);
  int getHybridForecast();                        // Основной алгоритм прогноза
  int getSeason();                                // Определение сезона
  float getDewPoint(float temp, float humidity);  // Точка росы
  const char* getWeatherWarning();                // Предупреждения
  const char* getRainProbText();

private:
  WeatherRecord records[HISTORY_SIZE];
  int currentIndex;
  int recordCount;
  int lastStableForecast;             // ← НОВЫЙ: для инерции прогноза
  unsigned long forecastStableSince;  // ← НОВЫЙ: для инерции прогноза

  WeatherRecord getRecord(int offset) const;
  int determineWeather(float pressure, float humidity, float temp, float pressureTrend1h);

  // Буферы для возврата строк (вместо String)
  char _forecastTextBuf[80];
  char _warningBuf[48];
  char _rainProbBuf[24];
};
#endif