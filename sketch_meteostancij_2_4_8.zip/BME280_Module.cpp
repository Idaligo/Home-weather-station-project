#include <EEPROM.h>
#include <LittleFS.h>
#include "BME280_Module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

extern uint16_t getTempColor(float temp);
extern uint16_t getHumColor(float hum);

const int TEMP_X = 10;
const int TEMP_Y = 92;
const int HUM_X = 10;
const int HUM_Y = 164;

// ==================== КОНСТРУКТОР ====================
BME280Module::BME280Module(Adafruit_BME280& bmeSensor, TFT_eSPI& tft_ref)
  : bme(bmeSensor),
    tft(tft_ref),
    spriteTemp(&tft_ref),
    spriteHum(&tft_ref) {
  isNewDataAvailable = false;
  spritesInitialized = false;
  isFirstDraw = true;
  temperature = 0;
  humidity = 0;
  tempCalibration = 0.0;
  humCalibration = 0.0;
  lastDrawTime = 0;
  lastTempColor = TFT_WHITE;
  lastHumColor = TFT_WHITE;

  filterIndex = 0;
  for (int i = 0; i < FILTER_SIZE; i++) {
    tempBuffer[i] = 20.0;
    humBuffer[i] = 50.0;
  }
}

// ========== МЕТОДЫ КАЛИБРОВКИ ТЕМПЕРАТУРЫ ==========
void BME280Module::setTempCalibration(float offset) {
  tempCalibration = offset;
  forceUpdate();
}

float BME280Module::getTempCalibration() const {
  return tempCalibration;
}

void BME280Module::resetTempCalibration() {
  tempCalibration = 0.0;
  forceUpdate();
}

void BME280Module::saveTempCalibration() {
  EEPROM.put(EEPROM_ADDR_TEMP_CAL, tempCalibration);
  EEPROM.commit();
  LOG_I("💾 Калибровка температуры BME280 сохранена: %.1f°C", tempCalibration);
}

void BME280Module::loadTempCalibration() {
  float savedOffset;
  EEPROM.get(EEPROM_ADDR_TEMP_CAL, savedOffset);

  if (savedOffset >= -10.0 && savedOffset <= 10.0 && savedOffset != 0.0) {
    tempCalibration = savedOffset;
    LOG_I("📥 Калибровка температуры BME280 загружена: %.1f°C", tempCalibration);
  } else {
    tempCalibration = 0.0;
    LOG_I("📥 Калибровка температуры BME280: используется значение по умолчанию (0.0)");
  }
  forceUpdate();
}

// ========== МЕТОДЫ КАЛИБРОВКИ ВЛАЖНОСТИ ==========
void BME280Module::setHumCalibration(float offset) {
  LOG_D("=== setHumCalibration CALLED ===");
  LOG_D("offset = %.1f", offset);
  humCalibration = offset;
  LOG_D("humCalibration now = %.1f", humCalibration);
  forceUpdate();
}

float BME280Module::getHumCalibration() const {
  LOG_D("=== getHumCalibration CALLED, returning %.1f ===", humCalibration);
  return humCalibration;
}

void BME280Module::resetHumCalibration() {
  humCalibration = 0.0;
  forceUpdate();
}

void BME280Module::saveHumCalibration() {
  LOG_D("DEBUG SAVE: humCalibration = %.1f, адрес = %d", humCalibration, EEPROM_ADDR_HUM_CAL);
  EEPROM.put(EEPROM_ADDR_HUM_CAL, humCalibration);
  EEPROM.commit();
  LOG_I("💾 Калибровка влажности BME280 сохранена: %.1f%%", humCalibration);
}

void BME280Module::loadHumCalibration() {
  float savedOffset;
  EEPROM.get(EEPROM_ADDR_HUM_CAL, savedOffset);
  LOG_D("DEBUG LOAD: из EEPROM прочитано = %.1f, адрес = %d", savedOffset, EEPROM_ADDR_HUM_CAL);

  if (savedOffset >= -20.0 && savedOffset <= 20.0 && savedOffset != 0.0) {
    humCalibration = savedOffset;
    LOG_I("📥 Калибровка влажности BME280 загружена: %.1f%%", humCalibration);
  } else {
    humCalibration = 0.0;
    LOG_I("📥 Калибровка влажности BME280: используется значение по умолчанию (0.0)");
  }
  forceUpdate();
}

// ========== ГРУППОВЫЕ МЕТОДЫ ==========
void BME280Module::resetAllCalibrations() {
  resetTempCalibration();
  resetHumCalibration();
}

void BME280Module::saveAllCalibrations() {
  saveTempCalibration();
  saveHumCalibration();
}

void BME280Module::loadAllCalibrations() {
  loadTempCalibration();
  loadHumCalibration();
}

// ========== ПОЛУЧЕНИЕ ОТКАЛИБРОВАННЫХ ЗНАЧЕНИЙ ==========
float BME280Module::getCalibratedTemperature() const {
  return temperature + tempCalibration;
}

float BME280Module::getCalibratedHumidity() const {
  float result = humidity + humCalibration;
  if (result < 0) result = 0;
  if (result > 100) result = 100;
  return result;
}

float BME280Module::getTemperature() {
  return getCalibratedTemperature();
}

float BME280Module::getHumidity() {
  return getCalibratedHumidity();
}

// ========== ОСТАЛЬНЫЕ МЕТОДЫ ==========

void BME280Module::initSprites() {
  if (spritesInitialized) return;

  tft.loadFont("cambriai48", LittleFS);
  String maxTempStr = "-99.9°C";
  String maxHumStr = "100%";
  int tempWidth = tft.textWidth(maxTempStr);
  int humWidth = tft.textWidth(maxHumStr);
  tft.unloadFont();

  spriteTemp.setColorDepth(16);
  spriteTemp.createSprite(tempWidth + 17, 37);
  spriteTemp.setSwapBytes(true);
  spriteTemp.loadFont("cambriai48");

  spriteHum.setColorDepth(16);
  spriteHum.createSprite(humWidth + 50, 37);
  spriteHum.setSwapBytes(true);
  spriteHum.loadFont("cambriai48");

  spritesInitialized = true;
}

void BME280Module::drawTemperature() {
  float dispTemp = getCalibratedTemperature();

  char tempStr[16];
  snprintf(tempStr, sizeof(tempStr), "%.1f", dispTemp);
  const char* unitStr = "°C";
  uint16_t newColor = getTempColor(dispTemp);

  char newStr[24];
  snprintf(newStr, sizeof(newStr), "%s%s", tempStr, unitStr);

  if (!isFirstDraw && strcmp(newStr, lastDrawnTempStr) == 0 && newColor == lastTempColor) {
    return;
  }

  spriteTemp.fillSprite(TFT_BLACK);
  spriteTemp.setTextColor(newColor, TFT_BLACK);
  spriteTemp.setCursor(0, 0);
  spriteTemp.print(tempStr);

  int tempWidth = spriteTemp.textWidth(tempStr);
  spriteTemp.setCursor(tempWidth + 10, 0);
  spriteTemp.print(unitStr);

  spriteTemp.pushSprite(TEMP_X, TEMP_Y);

  strncpy(lastDrawnTempStr, newStr, sizeof(lastDrawnTempStr) - 1);
  lastDrawnTempStr[sizeof(lastDrawnTempStr) - 1] = '\0';
  lastTempColor = newColor;
}

void BME280Module::drawHumidity() {
  float dispHum = getCalibratedHumidity();

  char humStr[16];
  snprintf(humStr, sizeof(humStr), "%.1f", dispHum);
  const char* unitStr = "%";
  uint16_t newColor = getHumColor(dispHum);

  char newStr[24];
  snprintf(newStr, sizeof(newStr), "%s%s", humStr, unitStr);

  if (!isFirstDraw && strcmp(newStr, lastDrawnHumStr) == 0 && newColor == lastHumColor) {
    return;
  }

  spriteHum.fillSprite(TFT_BLACK);
  spriteHum.setTextColor(newColor, TFT_BLACK);
  spriteHum.setCursor(0, 0);
  spriteHum.print(humStr);

  int humWidth = spriteHum.textWidth(humStr);
  spriteHum.setCursor(humWidth + 15, 0);
  spriteHum.print(unitStr);

  spriteHum.pushSprite(HUM_X, HUM_Y);

  strncpy(lastDrawnHumStr, newStr, sizeof(lastDrawnHumStr) - 1);
  lastDrawnHumStr[sizeof(lastDrawnHumStr) - 1] = '\0';
  lastHumColor = newColor;
}

void BME280Module::draw() {
  if (!isNewDataAvailable && !isFirstDraw) {
    return;
  }

  unsigned long now = millis();
  if (!isFirstDraw && (now - lastDrawTime) < DRAW_INTERVAL) {
    isNewDataAvailable = false;
    return;
  }

  initSprites();

  drawTemperature();
  drawHumidity();

  lastDrawTime = now;
  isNewDataAvailable = false;
  isFirstDraw = false;
}

void BME280Module::forceUpdate() {
  isFirstDraw = true;
  lastDrawnTempStr[0] = '\0';
  lastDrawnHumStr[0] = '\0';
  lastDrawTime = 0;
}

// ==================== МЕТОДЫ ФИЛЬТРАЦИИ ====================
void BME280Module::addTempSample(float sample) {
  tempBuffer[filterIndex] = sample;
}

void BME280Module::addHumSample(float sample) {
  humBuffer[filterIndex] = sample;
}

float BME280Module::calculateTempAverage() {
  float sum = 0;
  for (int i = 0; i < FILTER_SIZE; i++) {
    sum += tempBuffer[i];
  }
  float avg = sum / FILTER_SIZE;
  filterIndex = (filterIndex + 1) % FILTER_SIZE;
  return avg;
}

float BME280Module::calculateHumAverage() {
  float sum = 0;
  for (int i = 0; i < FILTER_SIZE; i++) {
    sum += humBuffer[i];
  }
  return sum / FILTER_SIZE;
}

// ==================== ОСНОВНЫЕ МЕТОДЫ ====================
void BME280Module::begin() {
  bme.setSampling(Adafruit_BME280::MODE_FORCED,
                  Adafruit_BME280::SAMPLING_X2,
                  Adafruit_BME280::SAMPLING_X2,
                  Adafruit_BME280::SAMPLING_X1,
                  Adafruit_BME280::FILTER_X2);
}

void BME280Module::update() {
  if (bme.takeForcedMeasurement()) {
    float newTemp = bme.readTemperature();
    float newHum = bme.readHumidity();

    if (!isnan(newTemp) && !isnan(newHum) && isfinite(newTemp) && isfinite(newHum)) {
      addTempSample(newTemp);
      addHumSample(newHum);

      temperature = calculateTempAverage();
      humidity = calculateHumAverage();

      isNewDataAvailable = true;
    }
  }
}