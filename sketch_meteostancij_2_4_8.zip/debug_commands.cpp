// debug_commands.cpp
#include "debug_commands.h"
#include "logger.h"
#include <EEPROM.h>

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ====================
bool isDebugMode = false;   // только логи
bool isDataFake  = false;   // подмена данных
float debugTemp = -99.9;
float debugHum = 99.9;
float debugPres = 999.0;

bool isNoSignalWarningActive = false;
bool noDataMessageShown = false;
bool hasFirstPacket = false;
int lastWeatherCode = -1;
int lastForecastCode = -1;
char lastForecastText[64] = "";

// ==================== СПРАВКА ====================
void printHelp() {
  HWSerial.println("\n=== ОТЛАДОЧНЫЕ КОМАНДЫ ===");
  HWSerial.println("d          - Переключить режим отладки (логи)");
  HWSerial.println("D0 / D1    - Выключить / включить режим отладки");
  HWSerial.println("f          - Переключить подмену данных (fake)");
  HWSerial.println("F0 / F1    - Выключить / включить подмену данных");
  HWSerial.println("T[знач]    - Установить тестовую температуру");
  HWSerial.println("H[знач]    - Установить тестовую влажность");
  HWSerial.println("P[знач]    - Установить тестовое давление");
  HWSerial.println("w          - Переключить предупреждение 'Нет сигнала'");
  HWSerial.println("W0 / W1    - Выключить / включить предупреждение");
  HWSerial.println("EEPROM     - Дамп ключевых адресов EEPROM");
  HWSerial.println("? / HELP   - Показать эту справку");
  HWSerial.println("===========================\n");
}

// ==================== ДАМП EEPROM ====================
static void dumpEEPROM() {
  HWSerial.println("\n=== EEPROM ДАМП (ключевые адреса) ===");
  auto dumpFloat = [](int addr, const char* name) {
    float v;
    EEPROM.get(addr, v);
    HWSerial.printf("  [%3d] %-22s = %.2f\n", addr, name, v);
  };
  auto dumpU8 = [](int addr, const char* name) {
    uint8_t v = EEPROM.read(addr);
    HWSerial.printf("  [%3d] %-22s = %u (0x%02X)\n", addr, name, v, v);
  };
  dumpU8(0, "brightness (manual)");
  dumpFloat(10, "tempOffset (street)");
  dumpFloat(20, "humOffset (street)");
  dumpFloat(30, "presOffset (street)");
  dumpFloat(40, "bmeTempOffset");
  dumpFloat(44, "bmeHumOffset");
  dumpU8(100, "brightConfig (start)");
  dumpU8(150, "calConfig (start)");
  dumpU8(250, "timeConfig (start)");
  dumpU8(300, "trendsConfig (start)");
  dumpU8(400, "wifiConfig (start)");
  dumpU8(450, "locationConfig (start)");
  dumpU8(470, "forecastConfig (start)");
  dumpU8(500, "sdLoggingEnabled");
  HWSerial.println("=====================================\n");
}

// ==================== ОСНОВНАЯ ФУНКЦИЯ ====================
void handleHWSerialCommands(RTCModule& rtcClock,
                            TemperatureModule& tempBlock,
                            HumidityModule& humBlock,
                            PressureModule& presBlock,
                            BME280Module& bmeModule,
                            WeatherForecast& forecast,
                            TFT_eSPI& tft) {

  if (!HWSerial.available()) return;

  String input = HWSerial.readStringUntil('\n');
  input.trim();
  if (input.length() == 0) return;

  // ===== СПРАВКА =====
  if (input == "?" || input.equalsIgnoreCase("HELP")) {
    printHelp();
    return;
  }

    // ===== РЕЖИМ ОТЛАДКИ (логи) =====
  if (input == "d") {
    loggerToggleDebug();
    isDebugMode = (loggerGetLevel() >= LOG_LEVEL_DEBUG);
    return;
  }
  if (input == "D0") {
    loggerSetLevel(LOG_LEVEL_ERROR);
    isDebugMode = false;
    LOG_E("Режим отладки: ВЫКЛ");
    return;
  }
  if (input == "D1") {
    loggerSetLevel(LOG_LEVEL_DEBUG);
    isDebugMode = true;
    LOG_E("Режим отладки: ВКЛ");
    return;
  }

  // ===== ПОДМЕНА ДАННЫХ (fake) =====
  if (input == "f") {
    isDataFake = !isDataFake;
    HWSerial.printf("Подмена данных: %s\n", isDataFake ? "ВКЛ" : "ВЫКЛ");
    if (isDataFake) {
      HWSerial.println("⚠️ ВНИМАНИЕ: реальные данные не принимаются, в лог пишутся фейки!");
    }
    return;
  }
  if (input == "F0") { isDataFake = false; HWSerial.println("Подмена данных: ВЫКЛ"); return; }
  if (input == "F1") { isDataFake = true;  HWSerial.println("Подмена данных: ВКЛ");  return; }

  // ===== ПРЕДУПРЕЖДЕНИЕ «НЕТ СИГНАЛА» =====
  if (input == "w") {
    isNoSignalWarningActive = !isNoSignalWarningActive;
    if (isNoSignalWarningActive) showNoSignalWarning();
    else clearWarningArea();
    HWSerial.printf("Предупреждение 'Нет сигнала': %s\n", isNoSignalWarningActive ? "ВКЛ" : "ВЫКЛ");
    return;
  }
  if (input == "W0") { isNoSignalWarningActive = false; clearWarningArea(); HWSerial.println("Предупреждение: ВЫКЛ"); return; }
  if (input == "W1") { showNoSignalWarning(); HWSerial.println("Предупреждение: ВКЛ"); return; }

  // ===== ДАМП EEPROM =====
  if (input == "EEPROM") { dumpEEPROM(); return; }

  // ===== ТЕСТОВЫЕ ЗНАЧЕНИЯ (T/H/P) =====
  // Защита: второй символ должен быть цифрой или знаком
  if (input.length() > 1 && (isdigit(input[1]) || input[1] == '-' || input[1] == '+')) {
    if (input[0] == 'T') {
      debugTemp = input.substring(1).toFloat();
      HWSerial.printf("Тестовая T: %.1f°C\n", debugTemp);
      return;
    }
    if (input[0] == 'H') {
      debugHum = constrain(input.substring(1).toFloat(), 0, 100);
      HWSerial.printf("Тестовая H: %.1f%%\n", debugHum);
      return;
    }
    if (input[0] == 'P') {
      debugPres = input.substring(1).toFloat();
      HWSerial.printf("Тестовое P: %.1f мм рт.ст.\n", debugPres);
      return;
    }
  }

  // ===== НЕИЗВЕСТНАЯ КОМАНДА =====
  HWSerial.printf("Неизвестная команда: '%s'\n", input.c_str());
  HWSerial.println("Введите '?' для списка команд");
}