// logger.cpp
#include "logger.h"

int g_logLevel = LOG_LEVEL_ERROR;  // по умолчанию — только ошибки

void loggerInit() {
  // Serial уже инициализирован в setup(). Ничего не делаем.
}

void loggerSetLevel(int level) {
  if (level < LOG_LEVEL_NONE) level = LOG_LEVEL_NONE;
  if (level > LOG_LEVEL_DEBUG) level = LOG_LEVEL_DEBUG;
  g_logLevel = level;
  LOG_I("Уровень логов: %d", g_logLevel);
}

int loggerGetLevel() {
  return g_logLevel;
}

void loggerToggleDebug() {
  if (g_logLevel >= LOG_LEVEL_DEBUG) {
    g_logLevel = LOG_LEVEL_ERROR;
    LOG_E("Debug OFF (уровень ERROR)");
  } else {
    g_logLevel = LOG_LEVEL_DEBUG;
    LOG_E("Debug ON (уровень DEBUG)");
  }
}