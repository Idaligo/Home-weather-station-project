// yandex_weather.h
#ifndef YANDEX_WEATHER_H
#define YANDEX_WEATHER_H

#include <Arduino.h>

// ==================== СТРУКТУРА ДАННЫХ ЯНДЕКСА ====================
struct YandexData {
  bool isValid = false;
  unsigned long lastUpdate = 0;

  // Текущая погода (fact)
  float currentTemp = 0;
  float currentHumidity = 0;
  float currentPressure = 0;
  char currentCondition[24];  // было String
  bool isDaytime = true;      // fact.daytime == "d"
  char currentPhenom[16];     // было String

  // Прогноз на 24 часа (forecasts[0].hours)
  float forecastTemp[24];
  float forecastHumidity[24];
  char forecastCondition[24][24];  // было String[24]
  bool forecastIsDay[24];
  uint8_t forecastPrecProb[24];

  // Прогноз по частям суток (forecasts[0].parts)
  float partTemp[4];  // 0=night, 1=morning, 2=day, 3=evening
  float partHumidity[4];
  char partCondition[4][24];  // было String[4]
  uint8_t partPrecProb[4];

  // Время начала каждой части суток (в часах)
  // Например, partStartHour[0] = 23 (ночь начинается в 23:00)
  uint8_t partStartHour[4];
};

// ==================== ФУНКЦИИ ====================
bool fetchYandexDataManual(float lat, float lon, const char* apiKey,
                           bool includeHours, uint8_t yandexFormat,
                           YandexData& data);

const char* getYandexDescription(const char* condition);
int mapYandexToWeatherCode(const char* condition);

#endif  // YANDEX_WEATHER_H