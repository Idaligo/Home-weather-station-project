#include <cstdint>
#include <Arduino.h>
#include <EEPROM.h>
#include <LittleFS.h>
#include "pressure_module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

uint16_t getPresColor(float pres);

// ==================== КОНСТАНТЫ ====================
const int PRESS_X = 290;
const int PRESS_Y = 235;
const int UNIT_X = 385;
const int UNIT_Y = 253;
const int UNIT_TEXT_HEIGHT = 19;
// UNIT_LABEL теперь static const char[] — определение ниже

// Определение статической константы класса
const char PressureModule::UNIT_LABEL[] = "mmHg";

// ==================== КОНСТРУКТОР ====================
PressureModule::PressureModule(TFT_eSPI& tft_ref)
  : tft(tft_ref),
    spritePres(&tft_ref) {
  isFirstDraw = true;
  spritesInitialized = false;
  pressure = 760.0;
  calibrationOffset = 0.0;
  lastPresColor = TFT_WHITE;
  lastUnitColor = TFT_WHITE;
}

// ========== МЕТОДЫ КАЛИБРОВКИ ==========
void PressureModule::setCalibration(float offset) {
  calibrationOffset = offset;
  forceUpdate();
}

float PressureModule::getCalibration() const {
  return calibrationOffset;
}

void PressureModule::resetCalibration() {
  calibrationOffset = 0.0;
  forceUpdate();
}

void PressureModule::saveCalibration() {
  EEPROM.put(EEPROM_ADDR_PRES, calibrationOffset);
  EEPROM.commit();
  LOG_I("💾 Калибровка давления сохранена: %.1f мм рт.ст.", calibrationOffset);
}

void PressureModule::loadCalibration() {
  float savedOffset;
  EEPROM.get(EEPROM_ADDR_PRES, savedOffset);

  // Проверяем, есть ли валидные данные в EEPROM
  if (savedOffset >= -50.0 && savedOffset <= 50.0 && savedOffset != 0.0) {
    calibrationOffset = savedOffset;
    LOG_I("📥 Калибровка давления загружена: %.1f мм рт.ст.", calibrationOffset);
  } else {
    calibrationOffset = 0.0;
    LOG_I("📥 Калибровка давления: используется значение по умолчанию (0.0)");
  }
  forceUpdate();
}

// ========== ПОЛУЧЕНИЕ ОТКАЛИБРОВАННОГО ЗНАЧЕНИЯ ==========
float PressureModule::getCalibratedPressure() const {
  return pressure + calibrationOffset;
}

// ==================== ИНИЦИАЛИЗАЦИЯ СПРАЙТОВ ====================
void PressureModule::initSprites() {
  if (spritesInitialized) return;

  // Вычисляем ширину для максимального значения
  tft.loadFont("cambriai48", LittleFS);
  String maxStr = "999";
  int textWidth = tft.textWidth(maxStr);
  tft.unloadFont();

  spritePres.setColorDepth(16);
  spritePres.createSprite(textWidth + 15, 37);
  spritePres.setSwapBytes(true);
  spritePres.loadFont("cambriai48");

  spritesInitialized = true;
}

// ==================== РИСОВАНИЕ ЦИФР В СПРАЙТЕ ====================
void PressureModule::drawNumber() {
  // Используем ОТКАЛИБРОВАННОЕ значение для отображения
  float displayedPres = getCalibratedPressure();

  char newPresStr[16];
  snprintf(newPresStr, sizeof(newPresStr), "%.0f", displayedPres);
  uint16_t newColor = getPresColor(displayedPres);

  // Проверяем, изменилось ли значение или цвет
  if (!isFirstDraw && strcmp(newPresStr, lastDrawnPresStr) == 0 && newColor == lastPresColor) {
    return;
  }

  spritePres.fillSprite(TFT_BLACK);
  spritePres.setTextColor(newColor, TFT_BLACK);
  spritePres.setCursor(0, 0);
  spritePres.print(newPresStr);
  spritePres.pushSprite(PRESS_X, PRESS_Y);

  strncpy(lastDrawnPresStr, newPresStr, sizeof(lastDrawnPresStr) - 1);
  lastDrawnPresStr[sizeof(lastDrawnPresStr) - 1] = '\0';
  lastPresColor = newColor;
}

// ==================== РИСОВАНИЕ ЕДИНИЦ (стандартным шрифтом) ====================
void PressureModule::drawUnit() {
  float displayedPres = getCalibratedPressure();
  uint16_t unitColor = getPresColor(displayedPres);

  // Проверяем, изменился ли цвет
  if (!isFirstDraw && unitColor == lastUnitColor && strcmp(lastDrawnUnitStr, UNIT_LABEL) == 0) {
    return;
  }

  // Очищаем область (чуть шире для надёжности)
  tft.fillRect(UNIT_X - 2, UNIT_Y - 1, 55, UNIT_TEXT_HEIGHT, TFT_BLACK);

  // Рисуем единицы динамическим цветом
  tft.setTextSize(2);
  tft.setTextColor(unitColor, TFT_BLACK);
  tft.setCursor(UNIT_X, UNIT_Y);
  tft.print(UNIT_LABEL);

  strncpy(lastDrawnUnitStr, UNIT_LABEL, sizeof(lastDrawnUnitStr) - 1);
  lastDrawnUnitStr[sizeof(lastDrawnUnitStr) - 1] = '\0';
  lastUnitColor = unitColor;
}

// ==================== ОСНОВНОЙ DRAW ====================
void PressureModule::draw() {
  initSprites();  // Инициализация (1 раз)
  drawNumber();   // Рисуем цифры (спрайт)
  drawUnit();     // Рисуем единицы (напрямую)
  isFirstDraw = false;
}

// ==================== ОСТАЛЬНЫЕ МЕТОДЫ ====================
void PressureModule::begin(float initialPres) {
  pressure = initialPres;
  isFirstDraw = true;
  lastDrawnPresStr[0] = '\0';
  lastDrawnUnitStr[0] = '\0';
  lastPresColor = TFT_WHITE;
  lastUnitColor = TFT_WHITE;
}

void PressureModule::update(float newPres) {
  pressure = newPres;
}

void PressureModule::forceUpdate() {
  isFirstDraw = true;
  lastDrawnPresStr[0] = '\0';
  lastDrawnUnitStr[0] = '\0';
  lastPresColor = TFT_WHITE;
  lastUnitColor = TFT_WHITE;
}

float PressureModule::getPressure() {
  // Возвращаем ОТКАЛИБРОВАННОЕ значение для прогноза и трендов
  return getCalibratedPressure();
}