// menu_module.cpp
//#define WEBSERVER_H
#include <WiFiManager.h>
#include <WebServer.h>
#include "menu_module.h"
#include "keypad_module.h"
#include "debug_commands.h"
#include "common.h"
#include "SCD40_Module.h"
#include "trends_module.h"
#include "rtc_module.h"
#include "temperature_module.h"
#include "humidity_module.h"
#include "pressure_module.h"
#include "weather_forecast.h"
#include "BME280_Module.h"
#include "openmeteo.h"
#include "ota_module.h"
#include "sd_module.h"
#include "web_module.h"
#include "logger.h"
#include <EEPROM.h>
#include <Wire.h>
#include <RTClib.h>
#include <WiFi.h>

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== ОБЪЯВЛЕНИЯ ВНЕШНИХ ФУНКЦИЙ ====================
extern void drawStaticLabels(TFT_eSPI& tft);
extern void updateDisplayIfChanged();
extern void drawIndicator();
extern void drawBatteryIndicator(TFT_eSPI& tft, float voltage);
extern void showNoSignalWarning();
extern void clearWarningArea();
extern void drawTrendIcon(int x, int y, int trend);

// ==================== ВНЕШНИЕ ПЕРЕМЕННЫЕ ====================
extern TFT_eSPI tft;
extern RTCModule rtcClock;
extern TemperatureModule tempBlock;
extern HumidityModule humBlock;
extern PressureModule presBlock;
extern BME280Module bmeModule;
extern SCD40Module co2Module;
extern WeatherForecast forecast;
extern Trends trends;

extern float lastDisplayedTemp;
extern float lastDisplayedHum;
extern float lastDisplayedPres;
extern int lastWeatherCode;
extern int lastForecastCode;
extern char lastForecastText[64];
extern int lastTempTrendCached;
extern int lastHumTrendCached;
extern int lastPresTrendCached;
extern bool isNoSignalWarningActive;
extern bool noDataMessageShown;
extern bool labelsDrawn;
extern DataStruct receivedData;
extern OpenMeteoData openMeteoData;
extern bool openMeteoIconsDrawn;

// ==================== ПЕРЕМЕННЫЕ ДЛЯ СИСТЕМЫ ПОДСВЕТКИ ====================
extern bool autoBrightness;
extern float lightSensorCalibA;
extern float lightSensorCalibB;
extern uint8_t brightness;
extern uint8_t targetBrightness;
extern bool isFading;

bool webIndicatorDirty = false;

// ===== NTP СИНХРОНИЗАЦИЯ =====
uint32_t lastNtpSyncTime = 0;
#define EEPROM_ADDR_NTP_TIME 505

// Функция NTP-синхронизации (вызывается из performForecastUpdate)
bool syncTimeFromNTP() {
  LOG_I("🌐 NTP: запрос времени...");

  // Настраиваем NTP (UTC, без смещения — RTC хранит локальное время)
  // Смещение для вашего часового пояса (Москва = UTC+3 = 10800 сек)
  // Если у вас другой пояс, поменяйте число (например, UTC+2 = 7200)
  configTime(10800, 0, "pool.ntp.org");

  // Ждём получения времени (до 5 секунд)
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 5000)) {
    LOG_E("❌ NTP: таймаут");
    return false;
  }

  // Создаём DateTime из timeinfo
  DateTime dt(timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday,
              timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);

  // Устанавливаем в RTC
  rtcClock.setDateTime(dt);
  rtcClock.forceUpdate();

  LOG_I("✅ NTP: %04d-%02d-%02d %02d:%02d:%02d",
        dt.year(), dt.month(), dt.day(),
        dt.hour(), dt.minute(), dt.second());
  return true;
}

// ==================== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ МЕНЮ ====================
AppMode currentMode = MODE_MAIN;
bool needFullRedraw = true;
int menuCurrentItem = 0;
int menuDepth = 0;
bool menuChanged = true;
int menuScrollOffset = 0;       // текущий сдвиг
int lastMenuCurrentItem = -1;   // ← для drawMenuNav (предыдущий курсор)
int lastMenuScrollOffset = -1;  // ← для drawMenuNav (предыдущий скролл)
int sessionScrollOffset = 0;
#define SESSION_VISIBLE_LINES 8  // сколько строк видно при size=2 (lineH=30)
#define SESSION_LINE_HEIGHT 30
#define MENU_VISIBLE_ITEMS 6  // сколько пунктов видно

bool inForecastSourceSubmenu = false;

int forecastSourceSubmenuItem = 0;
int forecastSourceScrollOffset = 0;
int lastForecastSourceItem = -1;          // ← для drawForecastSourceMenuNav
int lastForecastSourceScrollOffset = -1;  // ← для drawForecastSourceMenuNav

#define FORECAST_SOURCE_ITEMS_COUNT 3

unsigned long lastMenuActivity = 0;

// ==================== ПРОВЕРКА ТАЙМАУТА ====================
bool checkMenuTimeout() {
  if (millis() - lastMenuActivity > MENU_TIMEOUT) {
    LOG_D("⏰ Таймаут меню");
    exitMenuMode();
    return true;
  }
  return false;
}

// ==================== ПЕРЕМЕННЫЕ ПОДМЕНЮ ====================
bool inBrightnessSubmenu = false;
int brightnessSubmenuItem = 0;
bool inBrightnessEdit = false;
int brightnessEditItem = 0;
int autoScrollOffset = 0;
bool hasUnsavedChanges = false;
int lastAutoItem = -1;
int lastAutoScrollOffset = -1;
int lastSensorCfgItem = -1;
int lastBrightnessItem = -1;  // ← для drawBrightnessMenuNav

bool inSensorSubmenu = false;
// ==================== НАСТРОЙКИ ПОДСВЕТКИ ПО УМОЛЧАНИЮ ====================
BrightnessConfig brightConfig = {
  .autoMode = false,
  .points = {
    { 1, 5 },
    { 30, 100 },
    { 100, 200 },
    { 255, 250 } },
  .reactionSpeed = 5,
  .smoothing = true,
  .calibA = 6.0,
  .calibB = 0.0,
  .autoReturn = true
};

// ==================== РЕЗЕРВНАЯ КОПИЯ ДЛЯ ОТМЕНЫ ДЛЯ ПОДСВЕТКИ ====================
BrightnessConfig backupConfig;
#define EEPROM_ADDR_BRIGHT_CONFIG 100

// ==================== ПЕРЕМЕННЫЕ ПОДМЕНЮ ДАТЧИКОВ ====================
bool inSensorsSubmenu = false;
int sensorsSubmenuItem = 0;
int sensorsScrollOffset = 0;
bool inSensorsEdit = false;
int sensorsEditItem = 0;
bool hasSensorChanges = false;
int lastSensorsItem = -1;          // ← для drawSensorsMenuNav
int lastSensorsScrollOffset = -1;  // ← для drawSensorsMenuNav

// ==================== КАЛИБРОВКИ ПО УМОЛЧАНИЮ ====================
CalibrationConfig calConfig = {
  .tempOffset = 0.0,
  .humOffset = 0.0,
  .presOffset = 0.0,
  .sensorHeight = 0.0,  // ← НОВОЕ
  .bmeTempOffset = 0.0,
  .bmeHumOffset = 0.0
};

// ==================== РЕЗЕРВНАЯ КОПИЯ ДЛЯ ОТМЕНЫ ДЛЯ ДАТЧИКОВ ====================
CalibrationConfig backupCalConfig;
#define EEPROM_ADDR_CAL_CONFIG 150

// ==================== НАСТРОЙКИ WI-FI ====================
#define EEPROM_ADDR_WIFI_CONFIG 400

WiFiConfig wifiConfig = {
  .enabled = 1,
  .intervalIdx = 1,
  .forecastSource = 0,
  .forecastSourceBeforeWiFiOff = 0,
  .configured = 0,
  .yandexApiKey = "",
  .lastSessionHour = 255,
  .lastSessionDay = 0
};

const uint32_t wifiIntervalsSec[WIFI_INTERVAL_COUNT] = {
  1800,  // 0: 30 мин
  3600,  // 1: 1 ч
  7200,  // 2: 2 ч
  10800  // 3: 3 ч
};

// Состояние сеансов (RAM)
uint32_t lastWiFiSessionTime = 0;
bool wifiSessionInProgress = false;
bool lastSessionFailed = false;
static bool lastScheduleTimeWasRtc = true;

// ==================== КОНСТАНТЫ ПОДМЕНЮ ПОДСВЕТКИ ====================
#define BRIGHTNESS_ITEMS_COUNT 6
#define BRIGHTNESS_VISIBLE_ITEMS 5

#define AUTO_CONFIG_ITEMS_COUNT 12
#define AUTO_CONFIG_VISIBLE_ITEMS 8

#define SENSOR_CONFIG_ITEMS_COUNT 4

#define MANUAL_ITEMS_COUNT 3

// ==================== МАССИВЫ ПУНКТОВ МЕНЮ ====================
const char* mainMenuItems[] = {
  "Подсветка",
  "Датчики",
  "Время",
  "Тренды",
  "Wi-Fi",
  "Источник прогноза",
  "Скачать логи",  // Новый пункт
  "О системе",
  "OTA обновление",
  "Выход"
};

const char* brightnessItems[] = {
  "Режим подсветки",
  "Настройка AUTO",
  "Настройка датчика",
  "Сброс настроек",
  "Сохранить всё",
  "Назад"
};

const char* autoConfigItems[] = {
  "Точка 1: lux",
  "Точка 1: яркость",
  "Точка 2: lux",
  "Точка 2: яркость",
  "Точка 3: lux",
  "Точка 3: яркость",
  "Точка 4: lux",
  "Точка 4: яркость",
  "Скорость реакции",
  "Сглаживание",
  "Сохранить",
  "Назад"
};

const char* sensorConfigItems[] = {
  "Множитель (A)",
  "Смещение (B)",
  "Сохранить",
  "Назад"
};

// ==================== КОНСТАНТЫ ПОДМЕНЮ ДАТЧИКОВ ====================
#define SENSORS_ITEMS_COUNT 11
#define SENSORS_VISIBLE_ITEMS 6

// ==================== МАССИВ ПУНКТОВ ДАТЧИКОВ ====================
const char* sensorsItems[] = {
  "Улица: Температура",
  "Улица: Влажность",
  "Улица: Давление",
  "Высота (м)",  // ← НОВЫЙ (индекс 3)
  "Дом: Температура BME280",
  "Дом: Влажность BME280",
  "Сброс калибровок (улица)",
  "Сброс калибровок (дом)",
  "Сбросить все калибровки",
  "Сохранить всё",
  "Назад"
};

// ==================== ПЕРЕМЕННЫЕ ПОДМЕНЮ ВРЕМЕНИ ====================
bool inTimeSubmenu = false;
int timeSubmenuItem = 0;
int timeScrollOffset = 0;
bool inTimeEdit = false;
int timeEditItem = 0;
bool hasTimeChanges = false;
int lastTimeItem = -1;          // ← для drawTimeMenuNav
int lastTimeScrollOffset = -1;  // ← для drawTimeMenuNav

// ==================== НАСТРОЙКИ ВРЕМЕНИ ПО УМОЛЧАНИЮ ====================
TimeConfig timeConfig = {
  .hours = 12,
  .minutes = 0,
  .seconds = 0,
  .day = 1,
  .month = 1,
  .year = 2025,
  .dayOfWeek = 0  // Пн
};

// ==================== РЕЗЕРВНАЯ КОПИЯ ====================
TimeConfig backupTimeConfig;

#define EEPROM_ADDR_TIME_CONFIG 250

// ==================== НАЗВАНИЯ ДНЕЙ НЕДЕЛИ ====================
const char* dayNames[] = {
  "Пн",
  "Вт",
  "Ср",
  "Чт",
  "Пт",
  "Сб",
  "Вс"
};

// ==================== КОНСТАНТЫ ПОДМЕНЮ ВРЕМЕНИ ====================
#define TIME_ITEMS_COUNT 10
#define TIME_VISIBLE_ITEMS 7

// ==================== МАССИВ ПУНКТОВ ВРЕМЕНИ ====================
const char* timeItems[] = {
  "Часы",
  "Минуты",
  "Секунды",
  "День",
  "Месяц",
  "Год",
  "День недели",
  "NTP-синхр.",  // Новый пункт (индекс 7)
  "Сохранить",
  "Назад"
};

// ==================== ПЕРЕМЕННЫЕ ПОДМЕНЮ ТРЕНДОВ ====================
bool inTrendsSubmenu = false;
int trendsSubmenuItem = 0;
int trendsScrollOffset = 0;
bool inTrendsEdit = false;
int trendsEditItem = 0;
bool hasTrendsChanges = false;
int trendsEditSubmenu = 0;
int trendsEditScrollOffset = 0;
int lastTrendsMainItem = -1;          // ← для drawTrendsMenuNav
int lastTrendsMainScrollOffset = -1;  // ← для drawTrendsMenuNav
int lastTrendsSubItem = -1;           // ← для drawTrendsSubMenuNav
int lastTrendsSubScrollOffset = -1;   // ← для drawTrendsSubMenuNav  // 0=температура, 1=влажность, 2=давление

// ==================== НАСТРОЙКИ ТРЕНДОВ ПО УМОЛЧАНИЮ ====================
TrendsConfig trendsConfig = {
  .tempFastUp = 0.0040f,
  .tempSlowUp = 0.0010f,
  .tempFastDown = 0.0040f,
  .tempSlowDown = 0.0010f,
  .tempFastOffRatio = 0.4f,
  .tempSlowOffRatio = 0.3f,

  .humFastUp = 0.0085f,
  .humSlowUp = 0.0015f,
  .humFastDown = 0.0085f,
  .humSlowDown = 0.0015f,
  .humFastOffRatio = 0.6f,
  .humSlowOffRatio = 0.4f,

  .presFastUp = 0.0006f,
  .presSlowUp = 0.0002f,
  .presFastDown = 0.0006f,
  .presSlowDown = 0.0002f,
  .presFastOffRatio = 0.4f,
  .presSlowOffRatio = 0.2f
};

// ==================== РЕЗЕРВНАЯ КОПИЯ ====================
TrendsConfig backupTrendsConfig;

#define EEPROM_ADDR_TRENDS_CONFIG 300

// ==================== КОНСТАНТЫ ПОДМЕНЮ ТРЕНДОВ ====================
#define TRENDS_MAIN_ITEMS_COUNT 6
#define TRENDS_MAIN_VISIBLE_ITEMS 6

#define TRENDS_SUB_ITEMS_COUNT 7
#define TRENDS_SUB_VISIBLE_ITEMS 6

// ==================== МАССИВЫ ПУНКТОВ ====================
const char* trendsMainItems[] = {
  "Температура",
  "Влажность",
  "Давление",
  "Сброс настроек трендов",
  "Сохранить всё",
  "Назад"
};

const char* trendsSubItems[] = {
  "Быстрый рост",
  "Медленный рост",
  "Быстрое падение",
  "Медленное падение",
  "Гистерезис быстр.",
  "Гистерезис медл.",
  "Назад"
};

// ===================================================================
// ПОДСКАЗКИ ДЛЯ НАСТРОЙКИ ТРЕНДОВ (постоянные)
// ===================================================================

const char* trendTooltips[3][6][2] = {
  // ===== ТЕМПЕРАТУРА (0) =====
  {
    { "Реже срабатывает", "Чаще срабатывает" },  // Быстрый рост
    { "Реже срабатывает", "Чаще срабатывает" },  // Медленный рост
    { "Реже срабатывает", "Чаще срабатывает" },  // Быстрое падение
    { "Реже срабатывает", "Чаще срабатывает" },  // Медленное падение
    { "Стабильнее", "Динамичнее" },              // Гистерезис быстр.
    { "Стабильнее", "Динамичнее" }               // Гистерезис медл.
  },
  // ===== ВЛАЖНОСТЬ (1) =====
  {
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Стабильнее", "Динамичнее" },
    { "Стабильнее", "Динамичнее" } },
  // ===== ДАВЛЕНИЕ (2) =====
  {
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Реже срабатывает", "Чаще срабатывает" },
    { "Стабильнее", "Динамичнее" },
    { "Стабильнее", "Динамичнее" } }
};

// ==================== ПЕРЕМЕННЫЕ ПОДМЕНЮ WI-FI ====================
bool inWiFiSubmenu = false;
int wifiSubmenuItem = 0;
int lastWiFiItem = -1;

#define WIFI_ITEMS_COUNT 4

// ПОДМЕНЮ: О СИСТЕМЕ
// ===================================================================
#define SYSTEM_VISIBLE_ITEMS 9
#define SYSTEM_TOTAL_LINES 23  // ← было 22 (+1 строка «SD: размер»)
#define SYSTEM_SD_LINE_INDEX 16
#define SYSTEM_SD_SIZE_LINE_INDEX 17  // ← новая строка (для справки)
int systemScrollOffset = 0;
int systemCursorPos = 0;
int lastSystemItem = -1;                   // ← для drawSystemInfoNav
int lastSystemScrollOffset = -1;           // ← для drawSystemInfoNav
char systemLines[SYSTEM_TOTAL_LINES][40];  // ← глобальный массив строк

// ==================== ПРОТОТИПЫ STATIC-ФУНКЦИЙ WI-FI ====================
static void handleWiFiValueChange(bool increase);
static void setWiFiEnabled(bool enable);
static void showWiFiDisabledHint();
static void showWiFiConfigHint();

// ==================== ПРОТОТИПЫ ФУНКЦИЙ ====================
void drawBrightnessMenu();
void handleBrightnessMenu();
void handleBrightnessValueChange(bool increase);
void enterBrightnessSubItem(int index);
void drawAutoConfigMenu();
void drawAutoConfigMenuItem(int visibleIndex, bool selected);
void drawAutoConfigMenuNav();
void handleBrightnessEdit(int key);
void editAutoValue(bool increase);
void drawSensorConfigMenu();
void drawSensorConfigMenuItem(int itemIndex, bool selected);
void drawSensorConfigMenuNav();
void handleSensorEdit(int key);
void editSensorValue(bool increase);
void saveBrightnessChanges();
void discardBrightnessChanges();
void showSaveConfirmation();
void showResetConfirmation();
void drawSensorsMenu();
void drawSensorsMenuItem(int visibleIndex, bool selected);  // ← добавить
void drawSensorsMenuNav();                                  // ← добавить
void handleSensorsMenu();
void handleSensorsValueChange(bool increase);
void handleSensorsEdit(int key);
void saveSensorChanges();
void discardSensorChanges();
void loadCalibrationConfig();
void saveCalibrationConfig();
void resetCalibrationConfig(bool resetStreet, bool resetHome);
void applyCalibrationConfig();
void showResetConfirmation(const char* title, int type);
// ==================== ПРОТОТИПЫ ФУНКЦИЙ ВРЕМЕНИ ====================
void drawTimeMenu();
void drawTimeMenuItem(int visibleIndex, bool selected);  // ← добавить
void drawTimeMenuNav();                                  // ← добавить
void handleTimeMenu();
void handleTimeValueChange(bool increase);
void loadTimeConfig();
void saveTimeConfig();
void applyTimeConfig();
void loadTimeFromRTC();

// ==================== ПРОТОТИПЫ ФУНКЦИЙ ТРЕНДОВ ====================
void loadTrendsConfig();
void saveTrendsConfig();
void applyTrendsConfig();
void resetTrendsConfig();
void drawTrendsMenu();
void drawTrendsMenuItem(int itemIndex, bool selected);  // ← добавить
void drawTrendsMenuNav();                               // ← добавить
void handleTrendsMenu();
void drawTrendsSubMenu();
void drawTrendsSubItem(int visibleIndex, bool selected);  // ← добавить
void drawTrendsSubMenuNav();                              // ← добавить
void handleTrendsEdit(int key);
float getTrendsValue(int type, int index);
void setTrendsValue(int type, int index, float val);
void saveTrendsChanges();
void discardTrendsChanges();
void showResetTrendsConfirmation();
// ==================== ПРОТОТИП ФУНКЦИИ ДЛЯ РИСОВАНИЯ СТРЕЛОК ====================
void drawUpDownArrows(int x, int y, int size, uint16_t color);
// ===================================================================

// ==================== ПРОТОТИПЫ ФУНКЦИЙ WI-FI ====================
void drawWiFiMenu();
void drawWiFiMenuItem(int itemIndex, bool selected);  // ← добавить
void drawWiFiMenuNav();                               // ← добавить
void handleWiFiMenu();
void toggleWiFi(bool enable);
void startWiFiConfigPortal();

void drawForecastSourceMenu();
void drawForecastSourceMenuItem(int visibleIndex, bool selected);  // ← добавить
void drawForecastSourceMenuNav();                                  // ← добавить
void drawSessionDiagnostics();
void handleForecastSourceMenu();

// РАБОТА С EEPROM
// ===================================================================
// ПОДСВЕТКА
void loadBrightnessConfig() {
  BrightnessConfig savedConfig;
  EEPROM.get(EEPROM_ADDR_BRIGHT_CONFIG, savedConfig);

  bool valid = true;
  if (savedConfig.autoMode != true && savedConfig.autoMode != false) valid = false;
  for (int i = 0; i < 4; i++) {
    if (savedConfig.points[i].lux < 0 || savedConfig.points[i].lux > 500) valid = false;
    if (savedConfig.points[i].brightness < 0 || savedConfig.points[i].brightness > 255) valid = false;
  }
  if (savedConfig.reactionSpeed < 1 || savedConfig.reactionSpeed > 10) valid = false;
  if (savedConfig.calibA < 1.0 || savedConfig.calibA > 20.0) valid = false;
  if (savedConfig.calibB < -10.0 || savedConfig.calibB > 10.0) valid = false;

  if (valid) {
    brightConfig = savedConfig;
    backupConfig = savedConfig;
    LOG_I("📥 Настройки подсветки загружены из EEPROM");
  } else {
    LOG_I("📥 Настройки подсветки: используется значение по умолчанию");
  }
}

void saveBrightnessConfig() {
  EEPROM.put(EEPROM_ADDR_BRIGHT_CONFIG, brightConfig);
  EEPROM.commit();
  backupConfig = brightConfig;
  hasUnsavedChanges = false;
  LOG_I("💾 Настройки подсветки сохранены в EEPROM");
}

void resetBrightnessConfig() {
  brightConfig = {
    .autoMode = false,
    .points = {
      { 1, 5 },
      { 30, 100 },
      { 100, 200 },
      { 255, 250 } },
    .reactionSpeed = 5,
    .smoothing = true,
    .calibA = 6.0,
    .calibB = 0.0,
    .autoReturn = true
  };
  saveBrightnessConfig();
  applyBrightnessConfig();
  LOG_I("🔄 Настройки подсветки сброшены к заводским");
}

void applyBrightnessConfig() {
  autoBrightness = brightConfig.autoMode;
  lightSensorCalibA = brightConfig.calibA;
  lightSensorCalibB = brightConfig.calibB;

  if (!brightConfig.autoMode) {
    uint8_t savedBrightness = EEPROM.read(0);
    if (savedBrightness != 0xFF && savedBrightness != 0 && savedBrightness <= 255) {
      brightness = savedBrightness;
      targetBrightness = savedBrightness;
      analogWrite(7, brightness);
    }
  }

  // ===== ДОПОЛНИТЕЛЬНО: обновляем глобальную переменную =====
  autoBrightness = brightConfig.autoMode;

  LOG_I("✅ Настройки подсветки применены: %s",
        brightConfig.autoMode ? "AUTO" : "Ручной");
}

// ===================================================================
// РАБОТА С EEPROM (WI-FI)
// ===================================================================

void loadWiFiConfig() {
  // ===== Загрузка времени последней NTP-синхронизации =====
  EEPROM.get(EEPROM_ADDR_NTP_TIME, lastNtpSyncTime);
  if (lastNtpSyncTime == 0xFFFFFFFF) {
    lastNtpSyncTime = 0;  // EEPROM чистая
  }
  LOG_I("📥 NTP: lastSync = %lu", (unsigned long)lastNtpSyncTime);

  WiFiConfig savedConfig;
  EEPROM.get(EEPROM_ADDR_WIFI_CONFIG, savedConfig);

  // Валидация
  bool valid = true;
  if (savedConfig.enabled != 0 && savedConfig.enabled != 1) valid = false;
  if (savedConfig.forecastSource > 2) valid = false;  // 0, 1, 2
  if (savedConfig.forecastSourceBeforeWiFiOff != 0 && savedConfig.forecastSourceBeforeWiFiOff != 1) valid = false;
  if (savedConfig.intervalIdx >= WIFI_INTERVAL_COUNT) valid = false;
  if (savedConfig.configured != 0 && savedConfig.configured != 1) {
    savedConfig.configured = 0;  // мусор → 0
  }
  // Ключ: если не заканчивается на '\0' — обнуляем
  if (savedConfig.yandexApiKey[39] != '\0') {
    memset(savedConfig.yandexApiKey, 0, 40);
  }

  // Валидация lastSessionHour/lastSessionDay
  if (savedConfig.lastSessionHour > 23 && savedConfig.lastSessionHour != 255) {
    savedConfig.lastSessionHour = 255;
  }
  if (savedConfig.lastSessionDay < 1 || savedConfig.lastSessionDay > 31) {
    savedConfig.lastSessionDay = 0;
  }

  if (valid) {
    wifiConfig = savedConfig;
    LOG_I("📥 Настройки Wi-Fi загружены из EEPROM");
  } else {
    LOG_I("📥 Настройки Wi-Fi: используется значение по умолчанию");
  }

  LOG_I("   Wi-Fi: %s, интервал: %u сек, источник: %s",
        wifiConfig.enabled ? "ВКЛ" : "ВЫКЛ",
        wifiIntervalsSec[wifiConfig.intervalIdx],
        wifiConfig.forecastSource ? "Open-Meteo" : "Свой");
}

void saveWiFiConfig() {
  EEPROM.put(EEPROM_ADDR_WIFI_CONFIG, wifiConfig);
  EEPROM.commit();
  LOG_I("💾 Настройки Wi-Fi сохранены в EEPROM");
}

void applyWiFiConfig() {

  if (wifiConfig.enabled) {
    // Wi-Fi включён — включаем радио (само подключение будет в сеансе)
    WiFi.mode(WIFI_STA);
    LOG_I("📶 Wi-Fi включён (по расписанию)");
  } else {
    // Wi-Fi выключен — глушим радио
    WiFi.mode(WIFI_OFF);

    // Если источник был Open-Meteo — принудительно «Свой»
    if (wifiConfig.forecastSource) {
      wifiConfig.forecastSourceBeforeWiFiOff = true;
      wifiConfig.forecastSource = 0;
      saveWiFiConfig();
      LOG_I("📡 Источник переключён на «Свой» (Wi-Fi выключен)");
    }
    LOG_I("📶 Wi-Fi выключен");
  }

  // Сбрасываем время последнего сеанса → первый сеанс сразу после старта
  lastWiFiSessionTime = 0;
  wifiSessionInProgress = false;
  lastSessionFailed = false;
}

// ==================== НАСТРОЙКИ МЕСТОПОЛОЖЕНИЯ ====================
#define EEPROM_ADDR_LOCATION_CONFIG 450

LocationConfig locationConfig = {
  .lat = 47.267002,  // Ростов-на-Дону по умолчанию
  .lon = 39.667836
};

void loadLocationConfig() {
  LocationConfig saved;
  EEPROM.get(EEPROM_ADDR_LOCATION_CONFIG, saved);

  // Валидация
  bool valid = true;
  if (isnan(saved.lat) || isnan(saved.lon)) valid = false;
  if (saved.lat < -90.0 || saved.lat > 90.0) valid = false;
  if (saved.lon < -180.0 || saved.lon > 180.0) valid = false;
  if (saved.lat == 0.0 && saved.lon == 0.0) valid = false;  // «пусто»

  if (valid) {
    locationConfig = saved;
    LOG_I("📥 Координаты загружены: %.6f, %.6f",
          locationConfig.lat, locationConfig.lon);
  } else {
    LOG_I("📥 Координаты: используется значение по умолчанию (Ростов-на-Дону)");
  }
}

void saveLocationConfig() {
  EEPROM.put(EEPROM_ADDR_LOCATION_CONFIG, locationConfig);
  EEPROM.commit();
  LOG_I("💾 Координаты сохранены: %.6f, %.6f",
        locationConfig.lat, locationConfig.lon);
}

void applyLocationConfig() {
  // Пока ничего не делаем — координаты используются напрямую
  // в performForecastUpdate() (шаг 5).
  LOG_I("✅ Координаты применены: %.6f, %.6f",
        locationConfig.lat, locationConfig.lon);
}

// ==================== НАСТРОЙКИ ПРОГНОЗА ====================
#define EEPROM_ADDR_FORECAST_CONFIG 470

ForecastConfig forecastConfig = {
  .forecastHourIdx = 0,  // по умолчанию «через 1 час»
  .yandexFormat = 0      // по умолчанию «по часам»
};

void loadForecastConfig() {
  ForecastConfig saved;
  EEPROM.get(EEPROM_ADDR_FORECAST_CONFIG, saved);

  bool valid = (saved.forecastHourIdx < 6) && (saved.yandexFormat <= 1);

  if (valid) {
    forecastConfig = saved;
    LOG_I("📥 Период прогноза загружен: через %d ч",
          forecastConfig.forecastHourIdx + 1);
  } else {
    LOG_I("📥 Период прогноза: по умолчанию (через 1 час)");
  }
}

void saveForecastConfig() {
  EEPROM.put(EEPROM_ADDR_FORECAST_CONFIG, forecastConfig);
  EEPROM.commit();
  LOG_I("💾 Период прогноза сохранён: через %d ч",
        forecastConfig.forecastHourIdx + 1);
}

void applyForecastConfig() {
  // Пока ничего не делаем — используется напрямую в main.ino
  LOG_I("✅ Период прогноза: через %d ч",
        forecastConfig.forecastHourIdx + 1);
}

// ===================================================================
// РАСПИСАНИЕ WI-FI И СЕАНСЫ
// ===================================================================

// Проверка, валидно ли время RTC (год >= 2024)
static bool isRtcTimeValid() {
  DateTime now = rtcClock.getTime();
  return (now.year() >= 2024 && now.year() <= 2099);
}

// Получить текущее «время» для расписания (unix-секунды).
// Если RTC сбит — возвращает millis()/1000 (fallback, задача №4i).
static uint32_t getScheduleNow() {
  if (isRtcTimeValid()) {
    return rtcClock.getTime().unixtime();
  }
  return millis() / 1000;
}

// Проверка, пора ли запускать новый сеанс
static bool isWiFiSessionDue() {
  if (!wifiConfig.enabled) return false;
  if (wifiSessionInProgress) return false;
  if (currentMode == MODE_MENU) return false;
  if (wifiConfig.forecastSource == 0) return false;

  // ===== 1. ПЕРВЫЙ СЕАНС ПОСЛЕ СТАРТА =====
  // Всегда срабатывает через 30 сек после старта,
  // независимо от lastSessionHour/Day.
  static bool firstSessionDone = false;
  static unsigned long bootTime = 0;
  if (bootTime == 0) bootTime = millis();

  if (!firstSessionDone) {
    if (millis() - bootTime < FIRST_SESSION_DELAY_MS) {
      return false;
    }
    firstSessionDone = true;
    LOG_I("⏰ Первый сеанс после старта (30 сек прошло)");
    return true;
  }

  // ===== 2. ГИБРИДНАЯ ЛОГИКА =====
  bool nowUsesRtc = isRtcTimeValid();

  if (nowUsesRtc) {
    // === Вариант A: строго в начале часа (:00) ===
    DateTime now = rtcClock.getTime();
    if (now.minute() != 0) return false;

    // Уже был сеанс в этот час?
    if (wifiConfig.lastSessionHour == now.hour() && wifiConfig.lastSessionDay == now.day()) {
      return false;
    }

    LOG_I("⏰ Сеанс в %02d:00 (начало часа)", now.hour());
    return true;
  } else {
    // === Вариант B: fallback по интервалам ===
    if (lastWiFiSessionTime == 0) return true;

    uint32_t interval = (wifiConfig.forecastSource == 2)
                          ? 3600
                          : wifiIntervalsSec[wifiConfig.intervalIdx];

    // Защита от скачка назад
    if (lastWiFiSessionTime > millis() / 1000) {
      lastWiFiSessionTime = 0;
      return true;
    }

    uint32_t elapsed = (millis() / 1000) - lastWiFiSessionTime;
    return (elapsed >= interval);
  }
}

// Один сеанс: вкл Wi-Fi → подключение → запрос → выкл Wi-Fi
bool performForecastUpdate() {
  if (wifiSessionInProgress) {
    LOG_W("⚠️ Сеанс уже идёт");
    return false;
  }

  // ===== Сохраняем информацию о сеансе =====
  lastSession.valid = true;
  lastSession.success = false;
  lastSession.unixTime = rtcClock.getTime().unixtime();
  lastSession.source = wifiConfig.forecastSource;
  lastSession.httpCode = 0;
  lastSession.bytesRead = 0;
  lastSession.ramBefore = ESP.getFreeHeap();
  lastSession.ramAfter = 0;
  lastSession.largestBlockBefore = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT | MALLOC_CAP_INTERNAL);
  lastSession.largestBlockAfter = 0;
  memset(lastSession.error, 0, sizeof(lastSession.error));

  wifiSessionInProgress = true;
  lastSessionFailed = false;
  webIndicatorDirty = true;  // ← НОВОЕ: перерисовать индикатор в начале
  bool success = false;

  LOG_I("═══════════════════════════════════════");
  LOG_I("🌐 НАЧАЛО СЕАНСА WI-FI");

  // ===== 1. ВКЛЮЧАЕМ WI-FI =====
  WiFi.mode(WIFI_STA);
  WiFi.begin();  // использует сохранённые в NVS SSID/пароль

  // ===== 2. ЖДЁМ ПОДКЛЮЧЕНИЯ =====
  const unsigned long WIFI_CONNECT_TIMEOUT_MS = 15000;  // 15 сек
  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt) < 15000) {
    delay(250);
  }

  // Небольшая пауза после цикла, чтобы Wi-Fi успел "догнать" (ESP32 так умеет)
  delay(500);

  if (WiFi.status() != WL_CONNECTED) {
    LOG_E("❌ Не удалось подключиться к Wi-Fi");
    WiFi.mode(WIFI_OFF);
    wifiSessionInProgress = false;
    lastSessionFailed = true;
    webIndicatorDirty = true;  // ← НОВОЕ: перерисовать индикатор
    lastWiFiSessionTime = getScheduleNow();
    lastScheduleTimeWasRtc = isRtcTimeValid();
    LOG_I("═══════════════════════════════════════");
    return false;
  }

  LOG_I("✅ Подключено, IP: %s", WiFi.localIP().toString().c_str());

  // ===== 3. NTP-СИНХРОНИЗАЦИЯ (раз в 24 часа) =====
  uint32_t nowUnix = rtcClock.getTime().unixtime();
  bool needNtpSync = (lastNtpSyncTime == 0) || (nowUnix - lastNtpSyncTime > 86400);

  if (needNtpSync) {
    if (syncTimeFromNTP()) {
      // Обновляем время после синхронизации
      nowUnix = rtcClock.getTime().unixtime();
      lastNtpSyncTime = nowUnix;
      EEPROM.put(EEPROM_ADDR_NTP_TIME, lastNtpSyncTime);
      EEPROM.commit();
      LOG_I("💾 NTP: время сохранено в EEPROM");
    }
  } else {
    LOG_I("⏭️ NTP: пропуск (прошло %lu сек с последней синхронизации)",
          (unsigned long)(nowUnix - lastNtpSyncTime));
  }

  // ===== 4. ЗАПРОС К ВЫБРАННОМУ ИСТОЧНИКУ =====
  if (wifiConfig.forecastSource == 1) {
    // Open-Meteo
    if (fetchOpenMeteoData(locationConfig.lat, locationConfig.lon, openMeteoData)) {
      LOG_I("✅ Open-Meteo обновлён");
      openMeteoIconsDrawn = false;
      needFullRedraw = true;
      success = true;
    } else {
      LOG_E("❌ Не удалось получить данные Open-Meteo");
      lastSessionFailed = true;
    }
  } else if (wifiConfig.forecastSource == 2) {
    // Яндекс — формат зависит от настройки
    bool includeHours = true;  // всегда запрашиваем hours (для prec_prob по частям)
    if (fetchYandexDataManual(locationConfig.lat, locationConfig.lon,
                              wifiConfig.yandexApiKey, includeHours,
                              forecastConfig.yandexFormat, yandexData)) {
      LOG_I("✅ Яндекс обновлён");
      yandexIconsDrawn = false;
      needFullRedraw = true;
      success = true;
    } else {
      LOG_E("❌ Не удалось получить данные Яндекса");
      lastSessionFailed = true;
    }
  } else {
    // RF — не должно сюда попадать
    LOG_W("⚠️ Источник RF — неожиданный вызов сеанса");
    lastSessionFailed = true;
  }

  // ===== 4. ВЫКЛЮЧАЕМ WI-FI =====
  // Даём время на докачку данных (важно для Яндекса — тяжёлый ответ)
  delay(500);
  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);
  LOG_I("📴 Wi-Fi выключен");

  // ===== 5. ОБНОВЛЯЕМ ВРЕМЯ СЕАНСА =====
  lastWiFiSessionTime = getScheduleNow();
  lastScheduleTimeWasRtc = isRtcTimeValid();
  wifiSessionInProgress = false;

  // ← НОВОЕ: гарантированно перерисовать индикатор после сеанса
  webIndicatorDirty = true;

  LOG_I("🌐 СЕАНС ЗАВЕРШЁН (%s)", success ? "OK" : "ОШИБКА");
  LOG_I("═══════════════════════════════════════");

  lastSession.success = success;
  lastSession.ramAfter = ESP.getFreeHeap();

  // Ищем самый большой блок ТОЛЬКО во внутренней SRAM (исключаем PSRAM)
  lastSession.largestBlockAfter = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT | MALLOC_CAP_INTERNAL);

  // ===== Обновляем исторические минимумы =====
  if (lastSession.ramAfter < lastSession.minRamEver) {
    lastSession.minRamEver = lastSession.ramAfter;
  }
  if (lastSession.largestBlockAfter < lastSession.minBlockEver) {
    lastSession.minBlockEver = lastSession.largestBlockAfter;
  }

  if (!success && strlen(lastSession.error) == 0) {
    strncpy(lastSession.error, "Ошибка запроса", sizeof(lastSession.error) - 1);
    lastSession.error[sizeof(lastSession.error) - 1] = '\0';  // гарантия
  }

  // ===== Обновляем lastSessionHour/Day для логики "раз в час" =====
  DateTime now = rtcClock.getTime();
  if (now.year() >= 2024 && now.year() <= 2099) {
    wifiConfig.lastSessionHour = now.hour();
    wifiConfig.lastSessionDay = now.day();
    saveWiFiConfig();
  }

  // ===== Обновляем lastWiFiSessionTime для fallback =====
  lastWiFiSessionTime = getScheduleNow();
  lastScheduleTimeWasRtc = isRtcTimeValid();

  return success;
}

// Вызывается из loop() каждый проход.
// Решает, пора ли запускать сеанс.
void updateWiFiSchedule() {
  if (isWiFiSessionDue()) {
    performForecastUpdate();
  }
}

// Диалог подтверждения + запуск сеанса (для пункта меню «Обновить сейчас»)
void confirmAndRefreshForecast() {
  if (!showConfirmDialog("Обновить прогноз?",
                         "Будет выполнен запрос",
                         "к Open-Meteo.")) {
    LOG_I("↩️ Обновление отменено");
    return;
  }

  if (!wifiConfig.enabled) {
    // Если Wi-Fi выключен в настройках — предупреждаем
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Wi-Fi выключен");
    tft.setCursor(10, 50);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.print("Сначала включите Wi-Fi");
    tft.setCursor(10, 80);
    tft.print("в настройках.");
    delay(2000);
    return;
  }

  // Показываем прогресс
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Обновление...");
  tft.setTextSize(1);
  tft.setCursor(10, 50);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.print("Подключение к Wi-Fi и запрос");
  tft.print(" к Open-Meteo");

  bool ok = performForecastUpdate();

  sessionScrollOffset = 0;
  drawSessionDiagnostics();

  while (true) {
    int key = readKeypadWithRepeat();
    if (key == KEY_OK) break;
    if (key == KEY_UP) {
      if (sessionScrollOffset > 0) {
        sessionScrollOffset--;
        drawSessionDiagnostics();
      }
    } else if (key == KEY_DOWN) {
      int maxOff = 11 - SESSION_VISIBLE_LINES;  // 12 строк максимум
      if (maxOff < 0) maxOff = 0;
      if (sessionScrollOffset < maxOff) {
        sessionScrollOffset++;
        drawSessionDiagnostics();
      }
    }
    delay(50);
  }

  lastMenuActivity = millis();  // сброс таймаута меню
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();
}
// ДАТЧИКИ
void loadCalibrationConfig() {
  // ===== ЗАГРУЖАЕМ ИЗ СТАРЫХ АДРЕСОВ =====
  // Читаем калибровки из индивидуальных адресов
  float tempOffset, humOffset, presOffset, bmeTempOffset, bmeHumOffset;

  EEPROM.get(10, tempOffset);
  EEPROM.get(20, humOffset);
  EEPROM.get(30, presOffset);
  EEPROM.get(40, bmeTempOffset);
  EEPROM.get(41, bmeHumOffset);

  // Проверяем валидность
  bool valid = true;
  if (isnan(tempOffset) || abs(tempOffset) > 20) { tempOffset = 0.0; }
  if (isnan(humOffset) || abs(humOffset) > 20) { humOffset = 0.0; }
  if (isnan(presOffset) || abs(presOffset) > 20) { presOffset = 0.0; }
  if (isnan(bmeTempOffset) || abs(bmeTempOffset) > 20) { bmeTempOffset = 0.0; }
  if (isnan(bmeHumOffset) || abs(bmeHumOffset) > 20) { bmeHumOffset = 0.0; }

  // Сохраняем в структуру
  calConfig.tempOffset = tempOffset;
  calConfig.humOffset = humOffset;
  calConfig.presOffset = presOffset;
  calConfig.bmeTempOffset = bmeTempOffset;
  calConfig.bmeHumOffset = bmeHumOffset;

  // ===== sensorHeight — из структуры CalibrationConfig (новый адрес) =====
  CalibrationConfig savedCal;
  EEPROM.get(EEPROM_ADDR_CAL_CONFIG, savedCal);
  if (!isnan(savedCal.sensorHeight) && savedCal.sensorHeight >= 0.0 && savedCal.sensorHeight <= 500.0) {
    calConfig.sensorHeight = savedCal.sensorHeight;
  } else {
    calConfig.sensorHeight = 0.0;
  }

  backupCalConfig = calConfig;

  LOG_I("📥 Калибровки загружены:");
  LOG_I("   Улица: T=%.1f, H=%.1f, P=%.1f", tempOffset, humOffset, presOffset);
  LOG_I("   BME280: T=%.1f, H=%.1f", bmeTempOffset, bmeHumOffset);
}

void saveCalibrationConfig() {
  // ===== СОХРАНЯЕМ В СТАРЫЕ АДРЕСА =====
  EEPROM.put(10, calConfig.tempOffset);
  EEPROM.put(20, calConfig.humOffset);
  EEPROM.put(30, calConfig.presOffset);
  EEPROM.put(40, calConfig.bmeTempOffset);
  EEPROM.put(41, calConfig.bmeHumOffset);

  // ===== СОХРАНЯЕМ ТАКЖЕ В НОВЫЙ АДРЕС (для резерва) =====
  EEPROM.put(EEPROM_ADDR_CAL_CONFIG, calConfig);

  EEPROM.commit();
  backupCalConfig = calConfig;
  hasSensorChanges = false;

  LOG_I("💾 Калибровки сохранены:");
  LOG_I("   Улица: T=%.1f, H=%.1f, P=%.1f",
        calConfig.tempOffset, calConfig.humOffset, calConfig.presOffset);
  LOG_I("   BME280: T=%.1f, H=%.1f",
        calConfig.bmeTempOffset, calConfig.bmeHumOffset);
}

void resetCalibrationConfig(bool resetStreet, bool resetHome) {
  if (resetStreet) {
    calConfig.tempOffset = 0.0;
    calConfig.humOffset = 0.0;
    calConfig.presOffset = 0.0;
    LOG_I("🔄 Уличные калибровки сброшены");
  }
  if (resetHome) {
    calConfig.bmeTempOffset = 0.0;
    calConfig.bmeHumOffset = 0.0;
    LOG_I("🔄 Внутренние калибровки сброшены");
  }
  saveCalibrationConfig();
  applyCalibrationConfig();
}

void applyCalibrationConfig() {
  // Проверяем и корректируем значения
  if (isnan(calConfig.tempOffset)) calConfig.tempOffset = 0.0;
  if (isnan(calConfig.humOffset)) calConfig.humOffset = 0.0;
  if (isnan(calConfig.presOffset)) calConfig.presOffset = 0.0;
  if (isnan(calConfig.bmeTempOffset)) calConfig.bmeTempOffset = 0.0;
  if (isnan(calConfig.bmeHumOffset)) calConfig.bmeHumOffset = 0.0;

  // ===== Применяем высоту над уровнем моря =====
  {
    extern float sensorHeight;  // из main.ino
    sensorHeight = calConfig.sensorHeight;
    if (sensorHeight < 0.0) sensorHeight = 0.0;
    if (sensorHeight > 500.0) sensorHeight = 500.0;
  }

  // Применяем калибровки к модулям
  tempBlock.setCalibration(calConfig.tempOffset);
  humBlock.setCalibration(calConfig.humOffset);
  presBlock.setCalibration(calConfig.presOffset);
  bmeModule.setTempCalibration(calConfig.bmeTempOffset);
  bmeModule.setHumCalibration(calConfig.bmeHumOffset);

  // ===== ПРИНУДИТЕЛЬНО ОБНОВЛЯЕМ ОТОБРАЖЕНИЕ =====
  tempBlock.forceUpdate();
  humBlock.forceUpdate();
  presBlock.forceUpdate();
  bmeModule.forceUpdate();

  LOG_I("✅ Калибровки применены к датчикам");
}

// ===================================================================
// РАБОТА С EEPROM (ВРЕМЯ)
// ===================================================================

void loadTimeConfig() {
  TimeConfig savedConfig;
  EEPROM.get(EEPROM_ADDR_TIME_CONFIG, savedConfig);

  // Проверяем валидность
  bool valid = true;
  if (savedConfig.hours > 23) valid = false;
  if (savedConfig.minutes > 59) valid = false;
  if (savedConfig.seconds > 59) valid = false;
  if (savedConfig.day < 1 || savedConfig.day > 31) valid = false;
  if (savedConfig.month < 1 || savedConfig.month > 12) valid = false;
  if (savedConfig.year < 2000 || savedConfig.year > 2099) valid = false;
  if (savedConfig.dayOfWeek > 6) valid = false;  // 0..6
                                                 // (uint8_t не может быть < 0, так что проверка < 0 не нужна —
                                                 //  но если dayOfWeek хранится как int8_t или вычисляется как -1,
                                                 //  проверьте тип в структуре TimeConfig)

  if (valid) {
    timeConfig = savedConfig;
    backupTimeConfig = savedConfig;
    LOG_I("📥 Настройки времени загружены из EEPROM");
  } else {
    LOG_I("📥 Настройки времени: используется значение по умолчанию");
  }
}

void saveTimeConfig() {
  EEPROM.put(EEPROM_ADDR_TIME_CONFIG, timeConfig);
  EEPROM.commit();
  backupTimeConfig = timeConfig;
  hasTimeChanges = false;
  LOG_I("💾 Время сохранено: %02d:%02d:%02d %02d.%02d.%04d (%s)",
        timeConfig.hours, timeConfig.minutes, timeConfig.seconds,
        timeConfig.day, timeConfig.month, timeConfig.year,
        dayNames[timeConfig.dayOfWeek]);
}

void applyTimeConfig() {
  // Устанавливаем время в RTC
  DateTime dt(timeConfig.year, timeConfig.month, timeConfig.day,
              timeConfig.hours, timeConfig.minutes, timeConfig.seconds);
  rtcClock.setDateTime(dt);
  rtcClock.forceUpdate();

  LOG_I("✅ Время применено к RTC");
}

// ===================================================================
// РАБОТА С EEPROM (ТРЕНДЫ)
// ===================================================================

void loadTrendsConfig() {
  TrendsConfig savedConfig;
  EEPROM.get(EEPROM_ADDR_TRENDS_CONFIG, savedConfig);

  bool valid = true;
  // Проверяем валидность (все значения в разумных пределах)
  float* values = (float*)&savedConfig;
  for (int i = 0; i < sizeof(TrendsConfig) / sizeof(float); i++) {
    if (isnan(values[i]) || values[i] < 0 || values[i] > 10) valid = false;
  }

  if (valid) {
    trendsConfig = savedConfig;
    backupTrendsConfig = savedConfig;
    LOG_I("📥 Настройки трендов загружены из EEPROM");
  } else {
    LOG_I("📥 Настройки трендов: используется значение по умолчанию");
  }
}

void saveTrendsConfig() {
  EEPROM.put(EEPROM_ADDR_TRENDS_CONFIG, trendsConfig);
  EEPROM.commit();
  backupTrendsConfig = trendsConfig;
  hasTrendsChanges = false;
  LOG_I("💾 Настройки трендов сохранены в EEPROM");
}

void applyTrendsConfig() {
  // Собираем структуры порогов
  TrendThresholds tempTh = {
    .fastUp = trendsConfig.tempFastUp,
    .slowUp = trendsConfig.tempSlowUp,
    .fastDown = -trendsConfig.tempFastDown,  // В меню хранятся положительные, а нужны отрицательные
    .slowDown = -trendsConfig.tempSlowDown
  };

  TrendThresholds humTh = {
    .fastUp = trendsConfig.humFastUp,
    .slowUp = trendsConfig.humSlowUp,
    .fastDown = -trendsConfig.humFastDown,
    .slowDown = -trendsConfig.humSlowDown
  };

  TrendThresholds presTh = {
    .fastUp = trendsConfig.presFastUp,
    .slowUp = trendsConfig.presSlowUp,
    .fastDown = -trendsConfig.presFastDown,
    .slowDown = -trendsConfig.presSlowDown
  };

  // Передаём в модуль трендов
  trends.setThresholds(tempTh, humTh, presTh,
                       trendsConfig.tempFastOffRatio, trendsConfig.tempSlowOffRatio,
                       trendsConfig.humFastOffRatio, trendsConfig.humSlowOffRatio,
                       trendsConfig.presFastOffRatio, trendsConfig.presSlowOffRatio);

  LOG_I("✅ Настройки трендов применены к модулю");
}

void resetTrendsConfig() {
  trendsConfig = {
    .tempFastUp = 0.0040f,
    .tempSlowUp = 0.0010f,
    .tempFastDown = 0.0040f,
    .tempSlowDown = 0.0010f,
    .tempFastOffRatio = 0.4f,
    .tempSlowOffRatio = 0.3f,

    .humFastUp = 0.0085f,
    .humSlowUp = 0.0015f,
    .humFastDown = 0.0085f,
    .humSlowDown = 0.0015f,
    .humFastOffRatio = 0.6f,
    .humSlowOffRatio = 0.4f,

    .presFastUp = 0.0006f,
    .presSlowUp = 0.0002f,
    .presFastDown = 0.0006f,
    .presSlowDown = 0.0002f,
    .presFastOffRatio = 0.4f,
    .presSlowOffRatio = 0.2f
  };
  saveTrendsConfig();
  LOG_I("🔄 Настройки трендов сброшены к заводским");
}

// ===================================================================
// СОХРАНЕНИЕ / ОТМЕНА
// ===================================================================

void saveBrightnessChanges() {
  saveBrightnessConfig();
  applyBrightnessConfig();
  hasUnsavedChanges = false;
}

void discardBrightnessChanges() {
  brightConfig = backupConfig;
  hasUnsavedChanges = false;
  LOG_I("↩️ Изменения отменены");
}

// ===================================================================
// ПЕРЕКЛЮЧЕНИЕ В РЕЖИМ МЕНЮ
// ===================================================================

void enterMenuMode() {
  currentMode = MODE_MENU;
  menuCurrentItem = 0;
  menuScrollOffset = 0;
  menuDepth = 0;
  menuChanged = true;
  lastMenuCurrentItem = -1;   // ← сброс (полная перерисовка)
  lastMenuScrollOffset = -1;  // ← сброс
  inBrightnessSubmenu = false;
  inWiFiSubmenu = false;
  inForecastSourceSubmenu = false;
  inLogsSubmenu = false;
  lastMenuActivity = millis();

  tft.fillScreen(TFT_BLACK);
  drawMenu();

  LOG_I("📋 Вход в меню");
}

// ===================================================================
// ПЕРЕКЛЮЧЕНИЕ В РЕЖИМ ГЛАВНОГО ЭКРАНА
// ===================================================================

void exitMenuMode() {
  currentMode = MODE_MAIN;
  needFullRedraw = true;
  inBrightnessSubmenu = false;
  inWiFiSubmenu = false;
  inForecastSourceSubmenu = false;
  inLogsSubmenu = false;

  // ===== СБРОС ТАЙМАУТА СИГНАЛА =====
  // Пока были в меню, loop() не принимал пакеты, lastSignalTime
  // «устарел». Без сброса loop() сразу после выхода решит «нет сигнала»
  // и нарисует «Н С» (мигание). Сбрасываем — даём 3 минуты на пакет.
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();

  // ===== СИНХРОНИЗАЦИЯ ПОДСВЕТКИ =====
  syncBrightnessConfig();

  tft.fillScreen(TFT_BLACK);

  // Сбрасываем ВСЕ кэши
  lastDisplayedTemp = -999;
  lastDisplayedHum = -999;
  lastDisplayedPres = -999;
  lastWeatherCode = -1;
  lastForecastCode = -1;
  lastForecastText[0] = '\0';
  labelsDrawn = false;
  noDataMessageShown = false;
  lastTempTrendCached = 999;
  lastHumTrendCached = 999;
  lastPresTrendCached = 999;

  // Принудительно сбрасываем все модули
  tempBlock.forceUpdate();
  humBlock.forceUpdate();
  presBlock.forceUpdate();
  bmeModule.forceUpdate();
  co2Module.forceUpdate();
  rtcClock.forceUpdate();

  // Рисуем статику
  drawStaticLabels(tft);

  // ===== ПРИНУДИТЕЛЬНАЯ ПЕРЕРИСОВКА ВСЕХ ПОКАЗАТЕЛЕЙ =====
  tempBlock.draw();  // ← ПРИНУДИТЕЛЬНО
  humBlock.draw();   // ← ПРИНУДИТЕЛЬНО
  presBlock.draw();  // ← ПРИНУДИТЕЛЬНО
  bmeModule.draw();  // ← ПРИНУДИТЕЛЬНО
  co2Module.draw();  // ← ПРИНУДИТЕЛЬНО

  // Часы
  rtcClock.update();
  rtcClock.draw(tft);

  // Индикаторы
  drawIndicator();
  drawBatteryIndicator(tft, receivedData.battery_voltage);

  // Тренды
  drawTrendIcon(441, 87, trends.getTempTrend());
  drawTrendIcon(441, 159, trends.getHumTrend());
  drawTrendIcon(441, 230, trends.getPresTrend());

  // ===== ЯВНО РИСУЕМ WEB/SENS и SD (как в redrawMainScreen) =====
  // Иначе updateDisplayIfChanged может не перерисовать из-за кэшей,
  // и после fillScreen индикаторы останутся пустыми.
  {
    tft.fillRect(1, 1, 60, 10, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(1, 1);
    if (wifiConfig.forecastSource == 0) {
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      tft.print("SENS");
    } else if (wifiConfig.forecastSource == 1) {
      bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
      bool wifiConfigured = wifiConfig.configured && coordsOk;
      tft.setTextColor(wifiConfigured ? TFT_GREEN : TFT_RED, TFT_BLACK);
      tft.print("WEB");
    } else if (wifiConfig.forecastSource == 2) {
      bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
      bool yandexConfigured = wifiConfig.configured && coordsOk && (strlen(wifiConfig.yandexApiKey) > 0);
      uint16_t color = !yandexConfigured ? TFT_RED : (lastSessionFailed ? TFT_YELLOW : TFT_GREEN);
      tft.setTextColor(color, TFT_BLACK);
      tft.print("WEB");
    }
    extern int8_t lastSdStatusDrawn;
    extern void drawSdStatus();
    lastSdStatusDrawn = -1;
    drawSdStatus();
  }

  // Прогноз (принудительно через updateDisplayIfChanged)
  updateDisplayIfChanged();

  // «Н С» больше НЕ рисуем здесь — только из loop(), чтобы не мигало.

  needFullRedraw = false;
  webIndicatorDirty = true;
  LOG_I("🏠 Выход из меню");
}

// Синхронизируем brightConfig с autoBrightness (если изменилось в главном цикле)
void syncBrightnessConfig() {
  if (brightConfig.autoMode != autoBrightness) {
    brightConfig.autoMode = autoBrightness;
    saveBrightnessConfig();
    LOG_I("🔄 Синхронизация режима подсветки");
  }
}

// ===================================================================
// ПОЛНАЯ ПЕРЕРИСОВКА ГЛАВНОГО ЭКРАНА
// ===================================================================

void redrawMainScreen() {
  if (currentMode != MODE_MAIN) return;

  tft.fillScreen(TFT_BLACK);

  drawStaticLabels(tft);

  // ===== ПРИНУДИТЕЛЬНО РИСУЕМ WEB / SENS (т.к. updateDisplayIfChanged может пропустить) =====
  tft.fillRect(1, 1, 60, 10, TFT_BLACK);  // ← очистка области (артефакт WSENS)
  tft.setTextSize(1);
  tft.setCursor(1, 1);
  if (wifiConfig.forecastSource == 0) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.print("SENS");
  } else if (wifiConfig.forecastSource == 1) {
    bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
    bool wifiConfigured = wifiConfig.configured && coordsOk;
    tft.setTextColor(wifiConfigured ? TFT_GREEN : TFT_RED, TFT_BLACK);
    tft.print("WEB");
  } else if (wifiConfig.forecastSource == 2) {
    bool coordsOk = (locationConfig.lat != 0.0 || locationConfig.lon != 0.0);
    bool yandexConfigured = wifiConfig.configured && coordsOk && (strlen(wifiConfig.yandexApiKey) > 0);
    uint16_t color = !yandexConfigured ? TFT_RED : (lastSessionFailed ? TFT_YELLOW : TFT_GREEN);
    tft.setTextColor(color, TFT_BLACK);
    tft.print("WEB");
  }
  // ===== СБРОС КЭША SD ИНДИКАТОРА (чтобы он перерисовался) =====
  extern int8_t lastSdStatusDrawn;
  extern void drawSdStatus();
  lastSdStatusDrawn = -1;
  drawSdStatus();

  // ===== СБРОС КЭШЕЙ =====
  lastDisplayedTemp = -999;
  lastDisplayedHum = -999;
  lastDisplayedPres = -999;
  lastWeatherCode = -1;
  lastForecastCode = -1;
  lastForecastText[0] = '\0';
  lastTempTrendCached = 999;
  lastHumTrendCached = 999;
  lastPresTrendCached = 999;

  // ===== ПРИНУДИТЕЛЬНАЯ ПЕРЕРИСОВКА ДАТЧИКОВ =====
  tempBlock.forceUpdate();
  humBlock.forceUpdate();
  presBlock.forceUpdate();
  bmeModule.forceUpdate();
  co2Module.forceUpdate();
  rtcClock.forceUpdate();

  tempBlock.draw();
  humBlock.draw();
  presBlock.draw();
  bmeModule.draw();
  co2Module.draw();

  // ===== ПРОГНОЗ (через updateDisplayIfChanged) =====
  updateDisplayIfChanged();

  // ===== ЧАСЫ =====
  rtcClock.update();
  rtcClock.draw(tft);

  // ===== ИНДИКАТОРЫ =====
  drawIndicator();
  drawBatteryIndicator(tft, receivedData.battery_voltage);

  // ===== ТРЕНДЫ =====
  drawTrendIcon(441, 87, trends.getTempTrend());
  drawTrendIcon(441, 159, trends.getHumTrend());
  drawTrendIcon(441, 230, trends.getPresTrend());

  // «Н С» больше НЕ рисуем здесь — только из loop(), чтобы не мигало.

  needFullRedraw = false;
}

// ===================================================================
// ОТРИСОВКА ОДНОГО ПУНКТА МЕНЮ (для навигации без мерцания)
// ===================================================================
// visibleIndex — 0..MENU_VISIBLE_ITEMS-1 (строка на экране)
// selected — рисовать ли ">" (курсор)
// ===================================================================
void drawMenuItem(int visibleIndex, bool selected) {
  int itemIndex = visibleIndex + menuScrollOffset;
  if (itemIndex < 0 || itemIndex >= MENU_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 38;
  int y = startY + visibleIndex * stepY;

  // Очистить область строки (слева, где ">" + текст)
  tft.fillRect(0, y, 460, stepY, TFT_BLACK);

  // ">" — только для выбранного
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  // Текст пункта
  bool isDisabled = (itemIndex == 6) && (!sdLoggingEnabled || !sdReady);
  tft.setTextSize(2);
  tft.setCursor(35, y);
  if (isDisabled) {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  } else if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  }
  tft.print(mainMenuItems[itemIndex]);
}

// ===================================================================
// НАВИГАЦИЯ ПО МЕНЮ (только изменившиеся строки, без мерцания)
// ===================================================================
void drawMenuNav() {
  if (!menuChanged) return;

  // ===== ПЕРЕСЧЁТ СКРОЛЛА (как в drawMenu) =====
  // Без этого menuScrollOffset не меняется при навигации,
  // и курсор уходит за видимый диапазон.
  if (menuCurrentItem < menuScrollOffset) {
    menuScrollOffset = menuCurrentItem;
  }
  if (menuCurrentItem >= menuScrollOffset + MENU_VISIBLE_ITEMS) {
    menuScrollOffset = menuCurrentItem - MENU_VISIBLE_ITEMS + 1;
  }
  if (MENU_ITEMS_COUNT <= MENU_VISIBLE_ITEMS) {
    menuScrollOffset = 0;
  }

  // Если скролл сменился — перерисовать все видимые строки + скроллбар
  if (menuScrollOffset != lastMenuScrollOffset) {
    // Стереть область пунктов
    tft.fillRect(0, 55, 480, MENU_VISIBLE_ITEMS * 38, TFT_BLACK);

    int maxItems = min(MENU_VISIBLE_ITEMS, MENU_ITEMS_COUNT - menuScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + menuScrollOffset;
      drawMenuItem(i, itemIndex == menuCurrentItem);
    }

    // Скроллбар
    if (MENU_ITEMS_COUNT > MENU_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 38;
      int scrollBarHeight = stepY * MENU_VISIBLE_ITEMS;
      int thumbHeight = (MENU_VISIBLE_ITEMS * scrollBarHeight) / MENU_ITEMS_COUNT;
      int thumbPos = (menuScrollOffset * scrollBarHeight) / MENU_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }

    lastMenuScrollOffset = menuScrollOffset;
    lastMenuCurrentItem = menuCurrentItem;
  } else {
    // Только две строки: старая (без курсора) и новая (с курсором)
    if (lastMenuCurrentItem >= 0 && lastMenuCurrentItem != menuCurrentItem) {
      int oldVisible = lastMenuCurrentItem - menuScrollOffset;
      if (oldVisible >= 0 && oldVisible < MENU_VISIBLE_ITEMS) {
        drawMenuItem(oldVisible, false);
      }
    }
    int newVisible = menuCurrentItem - menuScrollOffset;
    if (newVisible >= 0 && newVisible < MENU_VISIBLE_ITEMS) {
      drawMenuItem(newVisible, true);
    }
    lastMenuCurrentItem = menuCurrentItem;
  }

  menuChanged = false;
}

// ===================================================================
// ГЛАВНОЕ МЕНЮ
// ===================================================================

void drawMenu() {
  if (!menuChanged) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Настройки");

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setCursor(400, 12);
  tft.print("30с");

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== КОРРЕКТИРУЕМ ОФФСЕТ =====
  if (menuCurrentItem < menuScrollOffset) {
    menuScrollOffset = menuCurrentItem;
  }
  if (menuCurrentItem >= menuScrollOffset + MENU_VISIBLE_ITEMS) {
    menuScrollOffset = menuCurrentItem - MENU_VISIBLE_ITEMS + 1;
  }
  if (MENU_ITEMS_COUNT <= MENU_VISIBLE_ITEMS) {
    menuScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 38;
  int maxItems = min(MENU_VISIBLE_ITEMS, MENU_ITEMS_COUNT - menuScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + menuScrollOffset;
    int y = startY + i * stepY;

    // ===== ПРОВЕРКА ДОСТУПНОСТИ ПУНКТА "СКАЧАТЬ ЛОГИ" (индекс 6) =====
    bool isDisabled = (itemIndex == 6) && (!sdLoggingEnabled || !sdReady);

    if (itemIndex == menuCurrentItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setCursor(35, y);
    }

    // ===== ЦВЕТ ПУНКТА =====
    if (isDisabled) {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);  // Серый, если недоступен
    } else if (itemIndex == menuCurrentItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);  // Белый, если выбран
    } else {
      tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);  // Светло-серый для остальных
    }

    tft.print(mainMenuItems[itemIndex]);
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (MENU_ITEMS_COUNT > MENU_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = stepY * MENU_VISIBLE_ITEMS;
    int thumbHeight = (MENU_VISIBLE_ITEMS * scrollBarHeight) / MENU_ITEMS_COUNT;
    int thumbPos = (menuScrollOffset * scrollBarHeight) / MENU_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор");
  tft.setCursor(200, 300);
  tft.print("OK - вход/выход");

  // Синхронизация для drawMenuNav
  lastMenuCurrentItem = menuCurrentItem;
  lastMenuScrollOffset = menuScrollOffset;

  menuChanged = false;
}

void handleMenuNavigation() {
  if (checkMenuTimeout()) return;

  if (inBrightnessSubmenu) {
    handleBrightnessMenu();
    return;
  }
  if (inSensorsSubmenu) {
    handleSensorsMenu();
    return;
  }
  if (inTimeSubmenu) {
    handleTimeMenu();
    return;
  }
  if (inTrendsSubmenu) {
    handleTrendsMenu();
    return;
  }
  if (inWiFiSubmenu) {
    handleWiFiMenu();
    return;
  }
  if (inForecastSourceSubmenu) {
    handleForecastSourceMenu();
    return;
  }

  if (inLogsSubmenu) {  // ← добавить
    handleLogsMenu();
    return;
  }

  int key = readKeypadWithRepeat();
  if (key != KEY_NONE) {
    lastMenuActivity = millis();
  }

  switch (key) {
    case KEY_UP:
      menuCurrentItem--;
      if (menuCurrentItem < 0) menuCurrentItem = MENU_ITEMS_COUNT - 1;
      menuChanged = true;
      drawMenuNav();  // ← только 2 строки (или 6 при скролле)
      break;

    case KEY_DOWN:
      menuCurrentItem++;
      if (menuCurrentItem >= MENU_ITEMS_COUNT) menuCurrentItem = 0;
      menuChanged = true;
      drawMenuNav();  // ← только 2 строки
      break;

    case KEY_OK:
      handleMenuItemSelected(menuCurrentItem);
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      break;
  }
}

void handleMenuItemSelected(int index) {
  switch (index) {
    case 0:  // Подсветка
      LOG_I("🔦 Подсветка");
      inBrightnessSubmenu = true;
      brightnessSubmenuItem = 0;
      inBrightnessEdit = false;
      inSensorSubmenu = false;
      hasUnsavedChanges = false;
      backupConfig = brightConfig;
      lastBrightnessItem = -1;  // ← сброс (полная перерисовка)
      drawBrightnessMenu();
      break;

    case 1:  // Датчики
      LOG_I("📊 Датчики");
      inSensorsSubmenu = true;
      sensorsSubmenuItem = 0;
      inSensorsEdit = false;
      hasSensorChanges = false;
      backupCalConfig = calConfig;
      lastSensorsItem = -1;          // ← сброс
      lastSensorsScrollOffset = -1;  // ← сброс
      drawSensorsMenu();
      break;

    case 2:  // Время
      LOG_I("🕐 Время");
      loadTimeFromRTC();
      inTimeSubmenu = true;
      timeSubmenuItem = 0;
      timeScrollOffset = 0;
      hasTimeChanges = false;
      lastTimeItem = -1;          // ← сброс
      lastTimeScrollOffset = -1;  // ← сброс
      drawTimeMenu();
      break;

    case 3:  // Тренды
      LOG_I("📈 Тренды");
      inTrendsSubmenu = true;
      trendsSubmenuItem = 0;
      trendsScrollOffset = 0;
      inTrendsEdit = false;
      hasTrendsChanges = false;
      backupTrendsConfig = trendsConfig;
      lastTrendsMainItem = -1;
      lastTrendsSubItem = -1;
      lastTrendsSubScrollOffset = -1;
      trendsEditScrollOffset = 0;
      drawTrendsMenu();
      break;

    case 4:  // Wi-Fi
      LOG_I("📶 Wi-Fi");
      inWiFiSubmenu = true;
      wifiSubmenuItem = 0;
      lastWiFiItem = -1;  // ← сброс
      drawWiFiMenu();
      break;

    case 5:  // Источник прогноза
      LOG_I("🌐 Источник прогноза");
      inForecastSourceSubmenu = true;
      forecastSourceSubmenuItem = 0;
      forecastSourceScrollOffset = 0;
      lastForecastSourceItem = -1;
      lastForecastSourceScrollOffset = -1;
      drawForecastSourceMenu();
      break;

    case 6:  // Скачать логи
      LOG_I("🌐 Скачать логи");

      // Сначала проверяем SD, потом Wi-Fi
      if (!sdLoggingEnabled || !sdReady) {
        tft.fillScreen(TFT_BLACK);
        tft.setTextColor(TFT_RED, TFT_BLACK);
        tft.setTextSize(2);
        tft.setCursor(10, 10);
        tft.print("SD недоступна");
        tft.setCursor(10, 60);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.setTextSize(1);
        tft.print("Включите логирование в 'О системе'");
        tft.setCursor(10, 80);
        tft.print("или вставьте карту.");

        delay(2000);
        menuChanged = true;
        currentMode = MODE_MENU;
        drawMenu();
        break;
      }

      if (!wifiConfig.enabled) {
        tft.fillScreen(TFT_BLACK);
        tft.setTextColor(TFT_YELLOW, TFT_BLACK);
        tft.setTextSize(2);
        tft.setCursor(10, 10);
        tft.print("Wi-Fi выключен");
        tft.setCursor(10, 60);
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
        tft.setTextSize(1);
        tft.print("Включите Wi-Fi в настройках.");
        delay(2000);
        drawMenu();
        break;
      }

      // SD и Wi-Fi в порядке — открываем подменю
      inLogsSubmenu = true;
      logsSubmenuItem = 0;
      lastLogsItem = -1;  // ← сброс
      drawLogsMenu();
      break;

    case 7:  // О системе
      LOG_I("ℹ О системе");
      systemScrollOffset = 0;
      systemCursorPos = 0;
      handleSystemInfo();
      if (currentMode == MODE_MENU) {
        menuChanged = true;
        drawMenu();
      }
      break;

    case 8:  // OTA обновление
      LOG_I("📡 OTA обновление");
      currentMode = MODE_OTA;
      break;

    case 9:  // Выход
      exitMenuMode();
      break;
  }
}

// ===================================================================
// ПОДСВЕТКА: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawBrightnessMenuItem(int itemIndex, bool selected) {
  if (itemIndex < 0 || itemIndex >= BRIGHTNESS_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 38;
  int y = startY + itemIndex * stepY;

  // Очистить область строки
  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  // ">" для выбранного
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  // Текст пункта
  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (itemIndex == BRIGHTNESS_ITEMS_COUNT - 2) {
    // "Сохранить всё" — цвет зависит от hasUnsavedChanges
    tft.setTextColor(hasUnsavedChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
    tft.print(brightnessItems[itemIndex]);
  } else {
    if (selected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    }
    tft.print(brightnessItems[itemIndex]);
  }

  // Значение справа: режим (индекс 0) и "!" (индекс 3)
  if (itemIndex == 0) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);
    tft.print(brightConfig.autoMode ? "AUTO" : "Ручной");
  }
  if (itemIndex == 3) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(350, y);
    tft.print("!");
  }
}

// ===================================================================
// ПОДСВЕТКА: навигация (только изменившиеся строки)
// ===================================================================
void drawBrightnessMenuNav() {
  if (!inBrightnessSubmenu) return;
  if (!menuChanged) return;

  // 2 строки: старая (без курсора), новая (с курсором)
  if (lastBrightnessItem >= 0 && lastBrightnessItem != brightnessSubmenuItem) {
    drawBrightnessMenuItem(lastBrightnessItem, false);
  }
  drawBrightnessMenuItem(brightnessSubmenuItem, true);

  lastBrightnessItem = brightnessSubmenuItem;
  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: ПОДСВЕТКА
// ===================================================================

void drawBrightnessMenu() {
  if (!inBrightnessSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Подсветка");

  if (hasUnsavedChanges) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(280, 10);
    tft.print("*");
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  int startY = 55;
  int stepY = 38;

  for (int i = 0; i < BRIGHTNESS_ITEMS_COUNT; i++) {
    int y = startY + i * stepY;

    if (i == brightnessSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    // Цвет для "Сохранить всё"
    if (i == BRIGHTNESS_ITEMS_COUNT - 2) {
      tft.setTextColor(hasUnsavedChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
      tft.print(brightnessItems[i]);
    } else {
      tft.print(brightnessItems[i]);
    }

    // Показываем текущий режим
    if (i == 0) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.setCursor(350, y);
      tft.print(brightConfig.autoMode ? "AUTO" : "Ручной");
    }

    // Предупреждение для сброса
    if (i == 3) {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setCursor(350, y);
      tft.print("!");
    }
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastBrightnessItem = brightnessSubmenuItem;  // ← синхронизация для Nav
  menuChanged = false;
}

// ===================================================================
// ДАТЧИКИ: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawSensorsMenuItem(int visibleIndex, bool selected) {
  if (visibleIndex < 0 || visibleIndex >= SENSORS_VISIBLE_ITEMS) return;
  int itemIndex = visibleIndex + sensorsScrollOffset;
  if (itemIndex < 0 || itemIndex >= SENSORS_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 35;
  int y = startY + visibleIndex * stepY;

  // Очистить область строки
  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  // ">" для выбранного
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  // Текст пункта
  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (itemIndex == SENSORS_ITEMS_COUNT - 2) {
    // "Сохранить всё" — цвет зависит от hasSensorChanges
    tft.setTextColor(hasSensorChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
    tft.print(sensorsItems[itemIndex]);
  } else {
    if (selected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    }
    tft.print(sensorsItems[itemIndex]);
  }

  // Значения справа (калибровки + высота, индексы 0..4)
  if (itemIndex < 5) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);
    switch (itemIndex) {
      case 0: tft.printf("%+.1f°C", calConfig.tempOffset); break;
      case 1: tft.printf("%+.1f%%", calConfig.humOffset); break;
      case 2: tft.printf("%+.1f мм", calConfig.presOffset); break;
      case 3: tft.printf("%d м", (int)calConfig.sensorHeight); break;  // ← НОВОЕ
      case 4: tft.printf("%+.1f°C", calConfig.bmeTempOffset); break;
      case 5: tft.printf("%+.1f%%", calConfig.bmeHumOffset); break;
    }
  }

  // "!" для сбросов (индексы 6..8, были 5..7)
  if (itemIndex >= 6 && itemIndex <= 8) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(350, y);
    tft.print("!");
  }
}

// ===================================================================
// ДАТЧИКИ: навигация (только изменившиеся строки + скролл)
// ===================================================================
void drawSensorsMenuNav() {
  if (!inSensorsSubmenu) return;
  if (!menuChanged) return;

  // Пересчёт скролла
  if (sensorsSubmenuItem < sensorsScrollOffset) {
    sensorsScrollOffset = sensorsSubmenuItem;
  }
  if (sensorsSubmenuItem >= sensorsScrollOffset + SENSORS_VISIBLE_ITEMS) {
    sensorsScrollOffset = sensorsSubmenuItem - SENSORS_VISIBLE_ITEMS + 1;
  }
  if (SENSORS_ITEMS_COUNT <= SENSORS_VISIBLE_ITEMS) {
    sensorsScrollOffset = 0;
  }

  if (sensorsScrollOffset != lastSensorsScrollOffset) {
    // Скролл — перерисовать все видимые + скроллбар
    tft.fillRect(0, 55, 480, SENSORS_VISIBLE_ITEMS * 35, TFT_BLACK);
    int maxItems = min(SENSORS_VISIBLE_ITEMS, SENSORS_ITEMS_COUNT - sensorsScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + sensorsScrollOffset;
      drawSensorsMenuItem(i, itemIndex == sensorsSubmenuItem);
    }
    // Скроллбар
    if (SENSORS_ITEMS_COUNT > SENSORS_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 35;
      int scrollBarHeight = stepY * SENSORS_VISIBLE_ITEMS;
      int thumbHeight = (SENSORS_VISIBLE_ITEMS * scrollBarHeight) / SENSORS_ITEMS_COUNT;
      int thumbPos = (sensorsScrollOffset * scrollBarHeight) / SENSORS_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastSensorsScrollOffset = sensorsScrollOffset;
    lastSensorsItem = sensorsSubmenuItem;
  } else {
    // 2 строки: старая (без курсора), новая (с курсором)
    if (lastSensorsItem >= 0 && lastSensorsItem != sensorsSubmenuItem) {
      int oldVisible = lastSensorsItem - sensorsScrollOffset;
      if (oldVisible >= 0 && oldVisible < SENSORS_VISIBLE_ITEMS) {
        drawSensorsMenuItem(oldVisible, false);
      }
    }
    int newVisible = sensorsSubmenuItem - sensorsScrollOffset;
    if (newVisible >= 0 && newVisible < SENSORS_VISIBLE_ITEMS) {
      drawSensorsMenuItem(newVisible, true);
    }
    lastSensorsItem = sensorsSubmenuItem;
  }

  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: ДАТЧИКИ
// ===================================================================

void drawSensorsMenu() {
  if (!inSensorsSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Датчики");

  if (hasSensorChanges) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(280, 10);
    tft.print("*");
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== КОРРЕКТИРУЕМ ОФФСЕТ =====
  if (sensorsSubmenuItem < sensorsScrollOffset) {
    sensorsScrollOffset = sensorsSubmenuItem;
  }
  if (sensorsSubmenuItem >= sensorsScrollOffset + SENSORS_VISIBLE_ITEMS) {
    sensorsScrollOffset = sensorsSubmenuItem - SENSORS_VISIBLE_ITEMS + 1;
  }
  if (SENSORS_ITEMS_COUNT <= SENSORS_VISIBLE_ITEMS) {
    sensorsScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 35;
  int maxItems = min(SENSORS_VISIBLE_ITEMS, SENSORS_ITEMS_COUNT - sensorsScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + sensorsScrollOffset;
    int y = startY + i * stepY;

    if (itemIndex == sensorsSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    // Цвет для "Сохранить всё"
    if (itemIndex == SENSORS_ITEMS_COUNT - 2) {
      tft.setTextColor(hasSensorChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
      tft.print(sensorsItems[itemIndex]);
    } else {
      tft.print(sensorsItems[itemIndex]);
    }

    // Показываем значения калибровок + высоты
    if (itemIndex < 6) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.setCursor(350, y);

      switch (itemIndex) {
        case 0: tft.printf("%+.1f°C", calConfig.tempOffset); break;
        case 1: tft.printf("%+.1f%%", calConfig.humOffset); break;
        case 2: tft.printf("%+.1f мм", calConfig.presOffset); break;
        case 3: tft.printf("%d м", (int)calConfig.sensorHeight); break;  // ← НОВОЕ
        case 4: tft.printf("%+.1f°C", calConfig.bmeTempOffset); break;
        case 5: tft.printf("%+.1f%%", calConfig.bmeHumOffset); break;
      }
    }

    // Предупреждение для сбросов (было 5..7, стало 6..8)
    if (itemIndex >= 6 && itemIndex <= 8) {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setCursor(350, y);
      tft.print("!");
    }
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (SENSORS_ITEMS_COUNT > SENSORS_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = 35 * SENSORS_VISIBLE_ITEMS;
    int thumbHeight = (SENSORS_VISIBLE_ITEMS * scrollBarHeight) / SENSORS_ITEMS_COUNT;
    int thumbPos = (sensorsScrollOffset * scrollBarHeight) / SENSORS_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastSensorsItem = sensorsSubmenuItem;           // ← синхронизация
  lastSensorsScrollOffset = sensorsScrollOffset;  // ← синхронизация
  menuChanged = false;
}

void handleSensorsMenu() {
  if (!inSensorsSubmenu) return;

  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  lastMenuActivity = millis();

  if (inSensorsEdit) {
    handleSensorsEdit(key);
    return;
  }

  switch (key) {
    case KEY_UP:
      sensorsSubmenuItem--;
      if (sensorsSubmenuItem < 0) sensorsSubmenuItem = SENSORS_ITEMS_COUNT - 1;
      menuChanged = true;
      drawSensorsMenuNav();
      break;

    case KEY_DOWN:
      sensorsSubmenuItem++;
      if (sensorsSubmenuItem >= SENSORS_ITEMS_COUNT) sensorsSubmenuItem = 0;
      menuChanged = true;
      drawSensorsMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      if (sensorsSubmenuItem < 6) {  // ← 0..5 (калибровки + высота)
        handleSensorsValueChange(key == KEY_RIGHT);
        int visibleIndex = sensorsSubmenuItem - sensorsScrollOffset;
        if (visibleIndex >= 0 && visibleIndex < SENSORS_VISIBLE_ITEMS) {
          drawSensorsMenuItem(visibleIndex, true);
        }
      }
      break;

    case KEY_OK:
      if (sensorsSubmenuItem == SENSORS_ITEMS_COUNT - 1) {  // Назад (10)
        if (hasSensorChanges) {
          discardSensorChanges();
        }
        inSensorsSubmenu = false;
        inSensorsEdit = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход без сохранения");

      } else if (sensorsSubmenuItem == SENSORS_ITEMS_COUNT - 2) {  // Сохранить всё (9)
        if (hasSensorChanges) {
          saveSensorChanges();
          inSensorsSubmenu = false;
          inSensorsEdit = false;

          tft.fillScreen(TFT_BLACK);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Сохранено!");
          delay(800);

          menuChanged = true;
          drawMenu();
          LOG_I("💾 Все сохранено и выход");
        } else {
          tft.fillRect(200, 220, 180, 30, TFT_BLACK);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Нет изменений");
          delay(800);
          drawSensorsMenu();
        }

      } else if (sensorsSubmenuItem == 6) {  // Сброс уличных (было 5)
        showResetCalibrationConfirmation("уличных калибровок", 0);
      } else if (sensorsSubmenuItem == 7) {  // Сброс внутренних (было 6)
        showResetCalibrationConfirmation("внутренних калибровок", 1);
      } else if (sensorsSubmenuItem == 8) {  // Сброс всех (было 7)
        showResetCalibrationConfirmation("всех калибровок", 2);

      } else if (sensorsSubmenuItem == 3) {
        // «Высота (м)» — редактируется через LEFT/RIGHT (в KEY_LEFT/RIGHT),
        // OK — ничего (не входим в редактирование)
      } else {
        // Вход в режим редактирования (индексы 0,1,2,4,5)
        inSensorsEdit = true;
        sensorsEditItem = sensorsSubmenuItem;
        drawSensorsMenu();
      }
      break;
  }
}

void handleSensorsValueChange(bool increase) {
  if (sensorsSubmenuItem >= 6) return;  // Сбросы (6..8) не редактируются

  // ===== ВЫСОТА (индекс 3) — шаг 1 м, 0..500 =====
  if (sensorsSubmenuItem == 3) {
    if (increase) {
      calConfig.sensorHeight += 1.0f;
      if (calConfig.sensorHeight > 500.0f) calConfig.sensorHeight = 500.0f;
    } else {
      calConfig.sensorHeight -= 1.0f;
      if (calConfig.sensorHeight < 0.0f) calConfig.sensorHeight = 0.0f;
    }
    hasSensorChanges = true;
    LOG_D("🔧 Высота: %d м", (int)calConfig.sensorHeight);
    return;
  }

  // ===== КАЛИБРОВКИ (индексы 0,1,2,4,5) — шаг 0.1 =====
  float step = 0.1;
  float* target = nullptr;
  float minVal = -20.0;
  float maxVal = 20.0;

  switch (sensorsSubmenuItem) {
    case 0: target = &calConfig.tempOffset; break;
    case 1: target = &calConfig.humOffset; break;
    case 2: target = &calConfig.presOffset; break;
    case 4: target = &calConfig.bmeTempOffset; break;
    case 5: target = &calConfig.bmeHumOffset; break;
  }

  if (target) {
    if (increase) {
      *target += step;
      if (*target > maxVal) *target = maxVal;
    } else {
      *target -= step;
      if (*target < minVal) *target = minVal;
    }
    hasSensorChanges = true;
    LOG_D("🔧 Калибровка: %.1f", *target);
  }
}

// ===================================================================
// ПРИНУДИТЕЛЬНАЯ NTP-СИНХРОНИЗАЦИЯ
// ===================================================================
void forceNtpSync() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Синхронизация NTP");

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 60);
  tft.print("Подключение к Wi-Fi...");

  // Включаем Wi-Fi
  WiFi.mode(WIFI_STA);
  WiFi.begin();

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - startAttempt) < 15000) {
    delay(250);
  }

  if (WiFi.status() != WL_CONNECTED) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(10, 100);
    tft.print("Ошибка Wi-Fi!");
    delay(2000);
    WiFi.mode(WIFI_OFF);
    return;
  }

  tft.setCursor(10, 100);
  tft.print("Запрос времени...");

  // Смещение для вашего часового пояса (Москва/Ростов = UTC+3 = 10800 сек)
  configTime(10800, 0, "pool.ntp.org");

  struct tm timeinfo;
  if (getLocalTime(&timeinfo, 5000)) {
    DateTime dt(timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday,
                timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
    rtcClock.setDateTime(dt);
    rtcClock.forceUpdate();

    // Обновляем и время последней синхронизации в EEPROM
    lastNtpSyncTime = rtcClock.getTime().unixtime();
    EEPROM.put(EEPROM_ADDR_NTP_TIME, lastNtpSyncTime);
    EEPROM.commit();

    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setCursor(10, 140);
    tft.print("Успешно!");
    delay(1500);
  } else {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(10, 140);
    tft.print("Ошибка NTP!");
    delay(2000);
  }

  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);

  // Перечитываем время в меню, чтобы отобразить новое
  loadTimeFromRTC();
  lastMenuActivity = millis();  // сбрасываем таймаут
  extern unsigned long lastSignalTime;
  lastSignalTime = millis();  // сброс таймаута сигнала
}

// ===================================================================
// ВРЕМЯ: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawTimeMenuItem(int visibleIndex, bool selected) {
  if (visibleIndex < 0 || visibleIndex >= TIME_VISIBLE_ITEMS) return;
  int itemIndex = visibleIndex + timeScrollOffset;
  if (itemIndex < 0 || itemIndex >= TIME_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 35;
  int y = startY + visibleIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (itemIndex == TIME_ITEMS_COUNT - 2) {
    // "Сохранить" — цвет зависит от hasTimeChanges
    tft.setTextColor(hasTimeChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
    tft.print(timeItems[itemIndex]);
  } else {
    if (selected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    }
    tft.print(timeItems[itemIndex]);
  }

  // Значения справа
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setCursor(350, y);
  switch (itemIndex) {
    case 0: tft.printf("%02d", timeConfig.hours); break;
    case 1: tft.printf("%02d", timeConfig.minutes); break;
    case 2: tft.printf("%02d", timeConfig.seconds); break;
    case 3: tft.printf("%02d", timeConfig.day); break;
    case 4: tft.printf("%02d", timeConfig.month); break;
    case 5: tft.printf("%04d", timeConfig.year); break;
    case 6: tft.print(dayNames[timeConfig.dayOfWeek]); break;
    case 7: tft.print("Wi-Fi"); break;  // NTP
  }
}

// ===================================================================
// ВРЕМЯ: навигация (только изменившиеся строки + скролл)
// ===================================================================
void drawTimeMenuNav() {
  if (!inTimeSubmenu) return;
  if (!menuChanged) return;

  // Пересчёт скролла
  if (timeSubmenuItem < timeScrollOffset) {
    timeScrollOffset = timeSubmenuItem;
  }
  if (timeSubmenuItem >= timeScrollOffset + TIME_VISIBLE_ITEMS) {
    timeScrollOffset = timeSubmenuItem - TIME_VISIBLE_ITEMS + 1;
  }
  if (TIME_ITEMS_COUNT <= TIME_VISIBLE_ITEMS) {
    timeScrollOffset = 0;
  }

  if (timeScrollOffset != lastTimeScrollOffset) {
    // Скролл — перерисовать все видимые + скроллбар
    tft.fillRect(0, 55, 480, TIME_VISIBLE_ITEMS * 35, TFT_BLACK);
    int maxItems = min(TIME_VISIBLE_ITEMS, TIME_ITEMS_COUNT - timeScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + timeScrollOffset;
      drawTimeMenuItem(i, itemIndex == timeSubmenuItem);
    }
    // Скроллбар
    if (TIME_ITEMS_COUNT > TIME_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 35;
      int scrollBarHeight = stepY * TIME_VISIBLE_ITEMS;
      int thumbHeight = (TIME_VISIBLE_ITEMS * scrollBarHeight) / TIME_ITEMS_COUNT;
      int thumbPos = (timeScrollOffset * scrollBarHeight) / TIME_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastTimeScrollOffset = timeScrollOffset;
    lastTimeItem = timeSubmenuItem;
  } else {
    // 2 строки
    if (lastTimeItem >= 0 && lastTimeItem != timeSubmenuItem) {
      int oldVisible = lastTimeItem - timeScrollOffset;
      if (oldVisible >= 0 && oldVisible < TIME_VISIBLE_ITEMS) {
        drawTimeMenuItem(oldVisible, false);
      }
    }
    int newVisible = timeSubmenuItem - timeScrollOffset;
    if (newVisible >= 0 && newVisible < TIME_VISIBLE_ITEMS) {
      drawTimeMenuItem(newVisible, true);
    }
    lastTimeItem = timeSubmenuItem;
  }

  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: ВРЕМЯ
// ===================================================================

void drawTimeMenu() {
  if (!inTimeSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  // ===== ЗАГОЛОВОК С ТЕКУЩИМ ВРЕМЕНЕМ =====
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Время");

  // Показываем текущее время (для справки)
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(350, 10);
  tft.printf("%02d:%02d", timeConfig.hours, timeConfig.minutes);

  if (hasTimeChanges) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(280, 10);
    tft.print("*");
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // Корректируем оффсет для прокрутки
  if (timeSubmenuItem < timeScrollOffset) {
    timeScrollOffset = timeSubmenuItem;
  }
  if (timeSubmenuItem >= timeScrollOffset + TIME_VISIBLE_ITEMS) {
    timeScrollOffset = timeSubmenuItem - TIME_VISIBLE_ITEMS + 1;
  }
  if (TIME_ITEMS_COUNT <= TIME_VISIBLE_ITEMS) {
    timeScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 35;
  int maxItems = min(TIME_VISIBLE_ITEMS, TIME_ITEMS_COUNT - timeScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + timeScrollOffset;
    int y = startY + i * stepY;

    if (itemIndex == timeSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    // Цвет для "Сохранить"
    if (itemIndex == TIME_ITEMS_COUNT - 2) {
      tft.setTextColor(hasTimeChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
      tft.print(timeItems[itemIndex]);
    } else {
      tft.print(timeItems[itemIndex]);
    }

    // Показываем значения (кроме пункта NTP)
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);

    switch (itemIndex) {
      case 0: tft.printf("%02d", timeConfig.hours); break;
      case 1: tft.printf("%02d", timeConfig.minutes); break;
      case 2: tft.printf("%02d", timeConfig.seconds); break;
      case 3: tft.printf("%02d", timeConfig.day); break;
      case 4: tft.printf("%02d", timeConfig.month); break;
      case 5: tft.printf("%04d", timeConfig.year); break;
      case 6: tft.print(dayNames[timeConfig.dayOfWeek]); break;
      case 7: tft.print("Wi-Fi"); break;  // Подсказка для NTP
    }
  }

  // Индикатор прокрутки
  if (TIME_ITEMS_COUNT > TIME_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = 35 * TIME_VISIBLE_ITEMS;
    int thumbHeight = (TIME_VISIBLE_ITEMS * scrollBarHeight) / TIME_ITEMS_COUNT;
    int thumbPos = (timeScrollOffset * scrollBarHeight) / TIME_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastTimeItem = timeSubmenuItem;
  lastTimeScrollOffset = timeScrollOffset;
  menuChanged = false;
}

// ===================================================================
// ТРЕНДЫ (главное): отрисовка одной строки
// ===================================================================
void drawTrendsMenuItem(int itemIndex, bool selected) {
  if (itemIndex < 0 || itemIndex >= TRENDS_MAIN_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 38;
  int y = startY + itemIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (itemIndex == TRENDS_MAIN_ITEMS_COUNT - 2) {
    tft.setTextColor(hasTrendsChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
    tft.print(trendsMainItems[itemIndex]);
  } else {
    if (selected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    }
    tft.print(trendsMainItems[itemIndex]);
  }

  // "!" для сброса (индекс 3)
  if (itemIndex == 3) {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(350, y);
    tft.print("!");
  }
}

// ===================================================================
// ТРЕНДЫ (главное): навигация (2 строки, без скролла)
// ===================================================================
void drawTrendsMenuNav() {
  if (!inTrendsSubmenu) return;
  if (!menuChanged) return;

  if (lastTrendsMainItem >= 0 && lastTrendsMainItem != trendsSubmenuItem) {
    drawTrendsMenuItem(lastTrendsMainItem, false);
  }
  drawTrendsMenuItem(trendsSubmenuItem, true);

  lastTrendsMainItem = trendsSubmenuItem;
  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: ТРЕНДЫ (ГЛАВНОЕ)
// ===================================================================

void drawTrendsMenu() {
  if (!inTrendsSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Тренды");

  if (hasTrendsChanges) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(280, 10);
    tft.print("*");
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== КОРРЕКТИРУЕМ ОФФСЕТ =====
  if (trendsSubmenuItem < trendsScrollOffset) {
    trendsScrollOffset = trendsSubmenuItem;
  }
  if (trendsSubmenuItem >= trendsScrollOffset + TRENDS_MAIN_VISIBLE_ITEMS) {
    trendsScrollOffset = trendsSubmenuItem - TRENDS_MAIN_VISIBLE_ITEMS + 1;
  }
  if (TRENDS_MAIN_ITEMS_COUNT <= TRENDS_MAIN_VISIBLE_ITEMS) {
    trendsScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 38;
  int maxItems = min(TRENDS_MAIN_VISIBLE_ITEMS, TRENDS_MAIN_ITEMS_COUNT - trendsScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + trendsScrollOffset;
    int y = startY + i * stepY;

    if (itemIndex == trendsSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    // Цвет для "Сохранить всё"
    if (itemIndex == TRENDS_MAIN_ITEMS_COUNT - 2) {
      tft.setTextColor(hasTrendsChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
      tft.print(trendsMainItems[itemIndex]);
    } else {
      tft.print(trendsMainItems[itemIndex]);
    }

    // Предупреждение для сброса
    if (itemIndex == 3) {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setCursor(350, y);
      tft.print("!");
    }
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (TRENDS_MAIN_ITEMS_COUNT > TRENDS_MAIN_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = 38 * TRENDS_MAIN_VISIBLE_ITEMS;
    int thumbHeight = (TRENDS_MAIN_VISIBLE_ITEMS * scrollBarHeight) / TRENDS_MAIN_ITEMS_COUNT;
    int thumbPos = (trendsScrollOffset * scrollBarHeight) / TRENDS_MAIN_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    OK - вход");

  lastTrendsMainItem = trendsSubmenuItem;
  menuChanged = false;
}

void handleTrendsMenu() {
  if (!inTrendsSubmenu) return;

  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  lastMenuActivity = millis();

  if (inTrendsEdit) {
    handleTrendsEdit(key);
    return;
  }

  switch (key) {
    case KEY_UP:
      trendsSubmenuItem--;
      if (trendsSubmenuItem < 0) trendsSubmenuItem = TRENDS_MAIN_ITEMS_COUNT - 1;
      menuChanged = true;
      drawTrendsMenuNav();
      break;

    case KEY_DOWN:
      trendsSubmenuItem++;
      if (trendsSubmenuItem >= TRENDS_MAIN_ITEMS_COUNT) trendsSubmenuItem = 0;
      menuChanged = true;
      drawTrendsMenuNav();
      break;

    case KEY_OK:
      if (trendsSubmenuItem == TRENDS_MAIN_ITEMS_COUNT - 1) {  // Назад
        if (hasTrendsChanges) {
          discardTrendsChanges();
        }
        inTrendsSubmenu = false;
        inTrendsEdit = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход без сохранения");

      } else if (trendsSubmenuItem == TRENDS_MAIN_ITEMS_COUNT - 2) {  // Сохранить всё
        if (hasTrendsChanges) {
          saveTrendsChanges();
          inTrendsSubmenu = false;
          inTrendsEdit = false;

          tft.fillScreen(TFT_BLACK);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Сохранено!");
          delay(800);

          menuChanged = true;
          drawMenu();
          LOG_I("💾 Настройки трендов сохранены");
        } else {
          tft.fillRect(200, 220, 180, 30, TFT_BLACK);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Нет изменений");
          delay(800);
          drawTrendsMenu();
        }

      } else if (trendsSubmenuItem == 3) {  // Сброс настроек
        showResetTrendsConfirmation();

      } else {
        // Вход в подменю (температура/влажность/давление)
        inTrendsEdit = true;
        trendsEditSubmenu = trendsSubmenuItem;
        if (trendsEditSubmenu < 0 || trendsEditSubmenu > 2) trendsEditSubmenu = 0;
        trendsEditItem = 0;
        trendsEditScrollOffset = 0;
        lastTrendsSubItem = -1;
        lastTrendsSubScrollOffset = -1;
        drawTrendsSubMenu();
      }
      break;
  }
}

// ===================================================================
// ТРЕНДЫ (подменю): отрисовка одной строки
// ===================================================================
void drawTrendsSubItem(int visibleIndex, bool selected) {
  if (visibleIndex < 0 || visibleIndex >= TRENDS_SUB_VISIBLE_ITEMS) return;
  int itemIndex = visibleIndex + trendsEditScrollOffset;
  if (itemIndex < 0 || itemIndex >= TRENDS_SUB_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 35;
  int y = startY + visibleIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  }
  tft.print(trendsSubItems[itemIndex]);

  if (itemIndex < TRENDS_SUB_ITEMS_COUNT - 1) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);
    float val = getTrendsValue(trendsEditSubmenu, itemIndex);
    if (itemIndex < 4) {
      tft.printf("%.4f", val);
    } else {
      tft.printf("%.1f", val);
    }
  }
}

void drawTrendsSubMenuNav() {
  if (!inTrendsEdit) return;
  if (!menuChanged) return;

  if (trendsEditItem < trendsEditScrollOffset) {
    trendsEditScrollOffset = trendsEditItem;
  }
  if (trendsEditItem >= trendsEditScrollOffset + TRENDS_SUB_VISIBLE_ITEMS) {
    trendsEditScrollOffset = trendsEditItem - TRENDS_SUB_VISIBLE_ITEMS + 1;
  }
  if (TRENDS_SUB_ITEMS_COUNT <= TRENDS_SUB_VISIBLE_ITEMS) {
    trendsEditScrollOffset = 0;
  }

  if (trendsEditScrollOffset != lastTrendsSubScrollOffset) {
    tft.fillRect(0, 55, 480, TRENDS_SUB_VISIBLE_ITEMS * 35, TFT_BLACK);
    int maxItems = min(TRENDS_SUB_VISIBLE_ITEMS, TRENDS_SUB_ITEMS_COUNT - trendsEditScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + trendsEditScrollOffset;
      drawTrendsSubItem(i, itemIndex == trendsEditItem);
    }
    if (TRENDS_SUB_ITEMS_COUNT > TRENDS_SUB_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 35;
      int scrollBarHeight = stepY * TRENDS_SUB_VISIBLE_ITEMS;
      int thumbHeight = (TRENDS_SUB_VISIBLE_ITEMS * scrollBarHeight) / TRENDS_SUB_ITEMS_COUNT;
      int thumbPos = (trendsEditScrollOffset * scrollBarHeight) / TRENDS_SUB_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastTrendsSubScrollOffset = trendsEditScrollOffset;
    lastTrendsSubItem = trendsEditItem;
  } else {
    if (lastTrendsSubItem >= 0 && lastTrendsSubItem != trendsEditItem) {
      int oldVisible = lastTrendsSubItem - trendsEditScrollOffset;
      if (oldVisible >= 0 && oldVisible < TRENDS_SUB_VISIBLE_ITEMS) {
        drawTrendsSubItem(oldVisible, false);
      }
    }
    int newVisible = trendsEditItem - trendsEditScrollOffset;
    if (newVisible >= 0 && newVisible < TRENDS_SUB_VISIBLE_ITEMS) {
      drawTrendsSubItem(newVisible, true);
    }
    lastTrendsSubItem = trendsEditItem;
  }

  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: НАСТРОЙКА ПАРАМЕТРА ТРЕНДА
// ===================================================================

void drawTrendsSubMenu() {
  if (!inTrendsEdit) return;

  tft.fillScreen(TFT_BLACK);

  const char* titles[] = { "Температура", "Влажность", "Давление" };
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.printf("%s", titles[trendsEditSubmenu]);

  if (hasTrendsChanges) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setCursor(280, 10);
    tft.print("*");
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== ПРОКРУТКА ДЛЯ ПОДМЕНЮ (глобальный trendsEditScrollOffset) =====
  if (trendsEditItem < trendsEditScrollOffset) {
    trendsEditScrollOffset = trendsEditItem;
  }
  if (trendsEditItem >= trendsEditScrollOffset + TRENDS_SUB_VISIBLE_ITEMS) {
    trendsEditScrollOffset = trendsEditItem - TRENDS_SUB_VISIBLE_ITEMS + 1;
  }
  if (TRENDS_SUB_ITEMS_COUNT <= TRENDS_SUB_VISIBLE_ITEMS) {
    trendsEditScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 35;
  int maxItems = min(TRENDS_SUB_VISIBLE_ITEMS, TRENDS_SUB_ITEMS_COUNT - trendsEditScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + trendsEditScrollOffset;
    int y = startY + i * stepY;

    if (itemIndex == trendsEditItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    tft.print(trendsSubItems[itemIndex]);

    // Показываем значения (кроме пункта "Назад")
    if (itemIndex < TRENDS_SUB_ITEMS_COUNT - 1) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.setCursor(350, y);

      float val = getTrendsValue(trendsEditSubmenu, itemIndex);
      if (itemIndex < 4) {
        tft.printf("%.4f", val);
      } else {
        tft.printf("%.1f", val);
      }
    }
  }
  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (TRENDS_SUB_ITEMS_COUNT > TRENDS_SUB_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = 35 * TRENDS_SUB_VISIBLE_ITEMS;
    int thumbHeight = (TRENDS_SUB_VISIBLE_ITEMS * scrollBarHeight) / TRENDS_SUB_ITEMS_COUNT;
    int thumbPos = (trendsEditScrollOffset * scrollBarHeight) / TRENDS_SUB_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  // ================================================================
  // ===== ПОДСКАЗКА ВНИЗУ (ДЛЯ ЭКРАНА 480x320) =====
  // ================================================================

  if (trendsEditItem < TRENDS_SUB_ITEMS_COUNT - 1) {
    // Очищаем нижнюю область (Y: 280-320)
    tft.fillRect(10, 255, 460, 40, TFT_BLACK);

    // Рамка
    tft.drawRect(10, 255, 460, 40, TFT_DARKGREY);

    // Название параметра (серым)
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(15, 260);
    tft.print(trendsSubItems[trendsEditItem]);
    tft.print(":");

    // Стрелка влево (уменьшение) — красным
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.setCursor(15, 277);
    tft.print("< ");
    tft.print(trendTooltips[trendsEditSubmenu][trendsEditItem][1]);

    // Разделитель
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.setCursor(230, 277);
    tft.print("|");

    // Стрелка вправо (увеличение) — зелёным
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setCursor(250, 277);
    tft.print("> ");
    tft.print(trendTooltips[trendsEditSubmenu][trendsEditItem][0]);
  } else {
    // Если выбран "Назад" — очищаем подсказку
    tft.fillRect(10, 255, 460, 40, TFT_BLACK);
  }

  // ===== НИЖНЯЯ СТРОКА С УПРАВЛЕНИЕМ =====
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);  // Шрифт 1 для экономии места
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastTrendsSubItem = trendsEditItem;
  lastTrendsSubScrollOffset = trendsEditScrollOffset;
  menuChanged = false;
}

float getTrendsValue(int type, int index) {
  switch (type) {
    case 0:  // Температура
      switch (index) {
        case 0: return trendsConfig.tempFastUp;
        case 1: return trendsConfig.tempSlowUp;
        case 2: return trendsConfig.tempFastDown;
        case 3: return trendsConfig.tempSlowDown;
        case 4: return trendsConfig.tempFastOffRatio;
        case 5: return trendsConfig.tempSlowOffRatio;
      }
      break;
    case 1:  // Влажность
      switch (index) {
        case 0: return trendsConfig.humFastUp;
        case 1: return trendsConfig.humSlowUp;
        case 2: return trendsConfig.humFastDown;
        case 3: return trendsConfig.humSlowDown;
        case 4: return trendsConfig.humFastOffRatio;
        case 5: return trendsConfig.humSlowOffRatio;
      }
      break;
    case 2:  // Давление
      switch (index) {
        case 0: return trendsConfig.presFastUp;
        case 1: return trendsConfig.presSlowUp;
        case 2: return trendsConfig.presFastDown;
        case 3: return trendsConfig.presSlowDown;
        case 4: return trendsConfig.presFastOffRatio;
        case 5: return trendsConfig.presSlowOffRatio;
      }
      break;
  }
  return 0;
}

void setTrendsValue(int type, int index, float val) {
  switch (type) {
    case 0:  // Температура
      switch (index) {
        case 0: trendsConfig.tempFastUp = val; break;
        case 1: trendsConfig.tempSlowUp = val; break;
        case 2: trendsConfig.tempFastDown = val; break;
        case 3: trendsConfig.tempSlowDown = val; break;
        case 4: trendsConfig.tempFastOffRatio = val; break;
        case 5: trendsConfig.tempSlowOffRatio = val; break;
      }
      break;
    case 1:  // Влажность
      switch (index) {
        case 0: trendsConfig.humFastUp = val; break;
        case 1: trendsConfig.humSlowUp = val; break;
        case 2: trendsConfig.humFastDown = val; break;
        case 3: trendsConfig.humSlowDown = val; break;
        case 4: trendsConfig.humFastOffRatio = val; break;
        case 5: trendsConfig.humSlowOffRatio = val; break;
      }
      break;
    case 2:  // Давление
      switch (index) {
        case 0: trendsConfig.presFastUp = val; break;
        case 1: trendsConfig.presSlowUp = val; break;
        case 2: trendsConfig.presFastDown = val; break;
        case 3: trendsConfig.presSlowDown = val; break;
        case 4: trendsConfig.presFastOffRatio = val; break;
        case 5: trendsConfig.presSlowOffRatio = val; break;
      }
      break;
  }
}

void handleTrendsEdit(int key) {
  switch (key) {
    case KEY_UP:
      trendsEditItem--;
      if (trendsEditItem < 0) trendsEditItem = TRENDS_SUB_ITEMS_COUNT - 1;
      menuChanged = true;
      drawTrendsSubMenuNav();
      break;

    case KEY_DOWN:
      trendsEditItem++;
      if (trendsEditItem >= TRENDS_SUB_ITEMS_COUNT) trendsEditItem = 0;
      menuChanged = true;
      drawTrendsSubMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      if (trendsEditItem < TRENDS_SUB_ITEMS_COUNT - 1) {
        float step = (trendsEditItem < 4) ? 0.0001f : 0.1f;
        float val = getTrendsValue(trendsEditSubmenu, trendsEditItem);
        float minVal = (trendsEditItem < 4) ? 0.0001f : 0.1f;
        float maxVal = (trendsEditItem < 4) ? 0.1f : 1.0f;

        if (key == KEY_RIGHT) {
          val += step;
          if (val > maxVal) val = maxVal;
        } else {
          val -= step;
          if (val < minVal) val = minVal;
        }
        setTrendsValue(trendsEditSubmenu, trendsEditItem, val);
        hasTrendsChanges = true;
        // Перерисовать ТОЛЬКО текущую строку (без мерцания)
        {
          int visibleIndex = trendsEditItem - trendsEditScrollOffset;
          if (visibleIndex >= 0 && visibleIndex < TRENDS_SUB_VISIBLE_ITEMS) {
            drawTrendsSubItem(visibleIndex, true);
          }
        }
      }
      break;

    case KEY_OK:
      if (trendsEditItem == TRENDS_SUB_ITEMS_COUNT - 1) {  // Назад
        inTrendsEdit = false;
        drawTrendsMenu();
      }
      break;
  }
}

void saveTrendsChanges() {
  saveTrendsConfig();
  applyTrendsConfig();
  hasTrendsChanges = false;
}

void discardTrendsChanges() {
  trendsConfig = backupTrendsConfig;
  hasTrendsChanges = false;
  LOG_I("↩️ Изменения трендов отменены");
}

void showResetTrendsConfirmation() {
  if (showConfirmDialog("Сбросить тренды?",
                        "Все пороги трендов будут",
                        "сброшены к заводским.")) {
    resetTrendsConfig();
    hasTrendsChanges = false;
    LOG_I("🔄 Настройки трендов сброшены");
    drawTrendsMenu();

    tft.fillRect(200, 220, 120, 30, TFT_BLACK);
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(205, 225);
    tft.print("Сброшено!");
    delay(800);
    drawTrendsMenu();
  } else {
    drawTrendsMenu();
  }
}

// ===================================================================
// ЗАГРУЗКА ТЕКУЩЕГО ВРЕМЕНИ ИЗ RTC
// ===================================================================

void loadTimeFromRTC() {
  LOG_D("🕐 loadTimeFromRTC: START");

  // ===== ИСПОЛЬЗУЕМ ГЛОБАЛЬНЫЙ rtcClock =====
  // НЕ создаём второй RTC_DS3231 на той же шине — это конфликт
  // (повторный begin() на занятой rtcWire может уронить ESP32-S3).
  rtcClock.forceUpdate();
  DateTime now = rtcClock.getTime();

  timeConfig.hours = now.hour();
  timeConfig.minutes = now.minute();
  timeConfig.seconds = now.second();
  timeConfig.day = now.day();
  timeConfig.month = now.month();
  timeConfig.year = now.year();

  // ===== ФИКС ВОСКРЕСЕНЬЯ =====
  // RTClib: dayOfTheWeek() = 0 (Вс), 1 (Пн), ..., 6 (Сб).
  // dayNames[]: 0 = Пн, ..., 6 = Вс.
  // Старое `- 1` давало -1 для воскресенья → dayNames[-1] → выход за границы.
  timeConfig.dayOfWeek = (now.dayOfTheWeek() + 6) % 7;

  backupTimeConfig = timeConfig;

  LOG_I("📥 Текущее время из RTC: %02d:%02d:%02d %02d.%02d.%04d (%s)",
        timeConfig.hours, timeConfig.minutes, timeConfig.seconds,
        timeConfig.day, timeConfig.month, timeConfig.year,
        dayNames[timeConfig.dayOfWeek]);
}

void handleTimeValueChange(bool increase) {
  int idx = timeSubmenuItem;

  switch (idx) {
    case 0:  // Часы (0-23)
      if (increase) {
        timeConfig.hours = (timeConfig.hours + 1) % 24;
      } else {
        timeConfig.hours = (timeConfig.hours == 0) ? 23 : timeConfig.hours - 1;
      }
      break;

    case 1:  // Минуты (0-59)
      if (increase) {
        timeConfig.minutes = (timeConfig.minutes + 1) % 60;
      } else {
        timeConfig.minutes = (timeConfig.minutes == 0) ? 59 : timeConfig.minutes - 1;
      }
      break;

    case 2:  // Секунды (0-59)
      if (increase) {
        timeConfig.seconds = (timeConfig.seconds + 1) % 60;
      } else {
        timeConfig.seconds = (timeConfig.seconds == 0) ? 59 : timeConfig.seconds - 1;
      }
      break;

    case 3:  // День (1-31)
      if (increase) {
        timeConfig.day++;
        if (timeConfig.day > 31) timeConfig.day = 1;
      } else {
        timeConfig.day--;
        if (timeConfig.day < 1) timeConfig.day = 31;
      }
      break;

    case 4:  // Месяц (1-12)
      if (increase) {
        timeConfig.month = (timeConfig.month % 12) + 1;
      } else {
        timeConfig.month = (timeConfig.month == 1) ? 12 : timeConfig.month - 1;
      }
      break;

    case 5:  // Год (2000-2099)
      if (increase) {
        timeConfig.year++;
        if (timeConfig.year > 2099) timeConfig.year = 2000;
      } else {
        timeConfig.year--;
        if (timeConfig.year < 2000) timeConfig.year = 2099;
      }
      break;

    case 6:  // День недели (0-6)
      if (increase) {
        timeConfig.dayOfWeek = (timeConfig.dayOfWeek + 1) % 7;
      } else {
        timeConfig.dayOfWeek = (timeConfig.dayOfWeek == 0) ? 6 : timeConfig.dayOfWeek - 1;
      }
      break;
  }

  hasTimeChanges = true;
}

void handleTimeMenu() {
  if (!inTimeSubmenu) return;

  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  lastMenuActivity = millis();

  switch (key) {
    case KEY_UP:
      timeSubmenuItem--;
      if (timeSubmenuItem < 0) timeSubmenuItem = TIME_ITEMS_COUNT - 1;
      menuChanged = true;
      drawTimeMenuNav();
      break;

    case KEY_DOWN:
      timeSubmenuItem++;
      if (timeSubmenuItem >= TIME_ITEMS_COUNT) timeSubmenuItem = 0;
      menuChanged = true;
      drawTimeMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      handleTimeValueChange(key == KEY_RIGHT);
      // Перерисовать ТОЛЬКО текущую строку (без мерцания)
      {
        int visibleIndex = timeSubmenuItem - timeScrollOffset;
        if (visibleIndex >= 0 && visibleIndex < TIME_VISIBLE_ITEMS) {
          drawTimeMenuItem(visibleIndex, true);
        }
      }
      break;

    case KEY_OK:
      if (timeSubmenuItem == TIME_ITEMS_COUNT - 1) {  // Назад
        if (hasTimeChanges) {
          // Отменяем изменения
          timeConfig = backupTimeConfig;
          hasTimeChanges = false;
        }
        inTimeSubmenu = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход без сохранения");

      } else if (timeSubmenuItem == 7) {  // NTP-синхронизация
        forceNtpSync();
        drawTimeMenu();  // перерисовываем меню с новым временем

      } else if (timeSubmenuItem == TIME_ITEMS_COUNT - 2) {  // Сохранить
        if (hasTimeChanges) {
          saveTimeConfig();
          applyTimeConfig();
          inTimeSubmenu = false;

          tft.fillScreen(TFT_BLACK);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Сохранено!");
          delay(800);

          menuChanged = true;
          drawMenu();
          LOG_I("💾 Время сохранено и выход");
        } else {
          tft.fillRect(200, 220, 180, 30, TFT_BLACK);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Нет изменений");
          delay(800);
          drawTimeMenu();
        }
      }
      break;
  }
}

void handleSensorsEdit(int key) {
  if (checkMenuTimeout()) return;

  switch (key) {
    case KEY_UP:
      sensorsSubmenuItem--;
      if (sensorsSubmenuItem < 0) sensorsSubmenuItem = SENSORS_ITEMS_COUNT - 1;
      drawSensorsMenu();
      break;

    case KEY_DOWN:
      sensorsSubmenuItem++;
      if (sensorsSubmenuItem >= SENSORS_ITEMS_COUNT) sensorsSubmenuItem = 0;
      drawSensorsMenu();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      handleSensorsValueChange(key == KEY_RIGHT);
      drawSensorsMenu();
      break;

    case KEY_OK:
      // Выход из режима редактирования
      inSensorsEdit = false;
      drawSensorsMenu();
      break;
  }
}

void saveSensorChanges() {
  saveCalibrationConfig();
  applyCalibrationConfig();
  hasSensorChanges = false;
}

void discardSensorChanges() {
  calConfig = backupCalConfig;
  hasSensorChanges = false;
  LOG_I("↩️ Изменения калибровок отменены");
}

void handleBrightnessMenu() {
  if (!inBrightnessSubmenu) return;

  // Проверяем таймаут
  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  // Обновляем время активности при нажатии
  lastMenuActivity = millis();

  // ===== ПРОВЕРКА: МЫ В РЕДАКТИРОВАНИИ =====
  if (inBrightnessEdit) {
    if (inSensorSubmenu) {
      handleSensorEdit(key);
    } else {
      handleBrightnessEdit(key);
    }
    return;
  }

  // ===== ОБЫЧНАЯ НАВИГАЦИЯ В ПОДМЕНЮ "ПОДСВЕТКА" =====
  switch (key) {
    case KEY_UP:
      brightnessSubmenuItem--;
      if (brightnessSubmenuItem < 0) brightnessSubmenuItem = BRIGHTNESS_ITEMS_COUNT - 1;
      menuChanged = true;
      drawBrightnessMenuNav();
      break;

    case KEY_DOWN:
      brightnessSubmenuItem++;
      if (brightnessSubmenuItem >= BRIGHTNESS_ITEMS_COUNT) brightnessSubmenuItem = 0;
      menuChanged = true;
      drawBrightnessMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      handleBrightnessValueChange(key == KEY_RIGHT);
      drawBrightnessMenu();
      break;

    case KEY_OK:
      if (brightnessSubmenuItem == BRIGHTNESS_ITEMS_COUNT - 1) {  // Назад
        if (hasUnsavedChanges) {
          discardBrightnessChanges();
        }
        inBrightnessSubmenu = false;
        inBrightnessEdit = false;
        inSensorSubmenu = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход без сохранения");

      } else if (brightnessSubmenuItem == BRIGHTNESS_ITEMS_COUNT - 2) {  // Сохранить всё
        if (hasUnsavedChanges) {
          saveBrightnessChanges();
          inBrightnessSubmenu = false;
          inBrightnessEdit = false;
          inSensorSubmenu = false;

          tft.fillScreen(TFT_BLACK);
          tft.setTextColor(TFT_GREEN, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Сохранено!");
          delay(800);

          menuChanged = true;
          drawMenu();
          LOG_I("💾 Все сохранено и выход");
        } else {
          tft.fillRect(200, 220, 180, 30, TFT_BLACK);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(205, 225);
          tft.print("Нет изменений");
          delay(800);
          drawBrightnessMenu();
        }

      } else if (brightnessSubmenuItem == 3) {  // Сброс настроек
        showResetConfirmation();

      } else {
        enterBrightnessSubItem(brightnessSubmenuItem);
      }
      break;
  }
}

void handleBrightnessValueChange(bool increase) {
  switch (brightnessSubmenuItem) {
    case 0:  // Режим подсветки — сохраняется сразу
      brightConfig.autoMode = !brightConfig.autoMode;
      // Синхронизируем глобальную переменную
      autoBrightness = brightConfig.autoMode;
      hasUnsavedChanges = false;
      LOG_I("🔄 Режим: %s", brightConfig.autoMode ? "AUTO" : "Ручной");
      saveBrightnessConfig();
      applyBrightnessConfig();
      break;

    default:
      hasUnsavedChanges = true;
      break;
  }
}

void enterBrightnessSubItem(int index) {
  switch (index) {
    case 1:  // Настройка AUTO
      LOG_I("🔧 Вход в настройку AUTO");
      inBrightnessEdit = true;
      inSensorSubmenu = false;
      brightnessEditItem = 0;
      autoScrollOffset = 0;
      lastAutoItem = -1;          // ← сброс
      lastAutoScrollOffset = -1;  // ← сброс
      drawAutoConfigMenu();
      break;

    case 2:  // Настройка датчика
      LOG_I("🔧 Вход в настройку датчика");
      inBrightnessEdit = true;
      inSensorSubmenu = true;
      brightnessEditItem = 0;
      lastSensorCfgItem = -1;  // ← сброс
      drawSensorConfigMenu();
      break;

    case 3:  // Сброс настроек — обрабатывается в handleBrightnessMenu
      break;

    default:
      break;
  }
}

// ===================================================================
// AUTO: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawAutoConfigMenuItem(int visibleIndex, bool selected) {
  if (visibleIndex < 0 || visibleIndex >= AUTO_CONFIG_VISIBLE_ITEMS) return;
  int itemIndex = visibleIndex + autoScrollOffset;
  if (itemIndex < 0 || itemIndex >= AUTO_CONFIG_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 32;
  int y = startY + visibleIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);
  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  }
  tft.print(autoConfigItems[itemIndex]);

  // Значение справа
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setCursor(350, y);
  if (itemIndex < 8) {
    int pointIdx = itemIndex / 2;
    bool isLux = (itemIndex % 2 == 0);
    tft.print(isLux ? brightConfig.points[pointIdx].lux : brightConfig.points[pointIdx].brightness);
  } else if (itemIndex == 8) {
    tft.print(brightConfig.reactionSpeed);
  } else if (itemIndex == 9) {
    tft.print(brightConfig.smoothing ? "Вкл" : "Выкл");
  }
}

void drawAutoConfigMenuNav() {
  if (!inBrightnessEdit) return;
  if (!menuChanged) return;

  // Пересчёт скролла
  if (brightnessEditItem < autoScrollOffset) {
    autoScrollOffset = brightnessEditItem;
  }
  if (brightnessEditItem >= autoScrollOffset + AUTO_CONFIG_VISIBLE_ITEMS) {
    autoScrollOffset = brightnessEditItem - AUTO_CONFIG_VISIBLE_ITEMS + 1;
  }
  if (AUTO_CONFIG_ITEMS_COUNT <= AUTO_CONFIG_VISIBLE_ITEMS) {
    autoScrollOffset = 0;
  }

  if (autoScrollOffset != lastAutoScrollOffset) {
    // Скролл — перерисовать все видимые + скроллбар
    tft.fillRect(0, 55, 480, AUTO_CONFIG_VISIBLE_ITEMS * 32, TFT_BLACK);
    int maxItems = min(AUTO_CONFIG_VISIBLE_ITEMS, AUTO_CONFIG_ITEMS_COUNT - autoScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + autoScrollOffset;
      drawAutoConfigMenuItem(i, itemIndex == brightnessEditItem);
    }
    // Скроллбар
    if (AUTO_CONFIG_ITEMS_COUNT > AUTO_CONFIG_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 32;
      int scrollBarHeight = stepY * AUTO_CONFIG_VISIBLE_ITEMS;
      int thumbHeight = (AUTO_CONFIG_VISIBLE_ITEMS * scrollBarHeight) / AUTO_CONFIG_ITEMS_COUNT;
      int thumbPos = (autoScrollOffset * scrollBarHeight) / AUTO_CONFIG_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastAutoScrollOffset = autoScrollOffset;
    lastAutoItem = brightnessEditItem;
  } else {
    // 2 строки
    if (lastAutoItem >= 0 && lastAutoItem != brightnessEditItem) {
      int oldVisible = lastAutoItem - autoScrollOffset;
      if (oldVisible >= 0 && oldVisible < AUTO_CONFIG_VISIBLE_ITEMS) {
        drawAutoConfigMenuItem(oldVisible, false);
      }
    }
    int newVisible = brightnessEditItem - autoScrollOffset;
    if (newVisible >= 0 && newVisible < AUTO_CONFIG_VISIBLE_ITEMS) {
      drawAutoConfigMenuItem(newVisible, true);
    }
    lastAutoItem = brightnessEditItem;
  }

  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: НАСТРОЙКА AUTO
// ===================================================================

void drawAutoConfigMenu() {
  if (!inBrightnessEdit) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Настройка AUTO");

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setCursor(400, 12);
  tft.printf("%d/%d", brightnessEditItem + 1, AUTO_CONFIG_ITEMS_COUNT);

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  if (brightnessEditItem < autoScrollOffset) autoScrollOffset = brightnessEditItem;
  if (brightnessEditItem >= autoScrollOffset + AUTO_CONFIG_VISIBLE_ITEMS) {
    autoScrollOffset = brightnessEditItem - AUTO_CONFIG_VISIBLE_ITEMS + 1;
  }
  if (AUTO_CONFIG_ITEMS_COUNT <= AUTO_CONFIG_VISIBLE_ITEMS) autoScrollOffset = 0;

  int startY = 55;
  int stepY = 32;
  int maxItems = min(AUTO_CONFIG_VISIBLE_ITEMS, AUTO_CONFIG_ITEMS_COUNT - autoScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + autoScrollOffset;
    int y = startY + i * stepY;

    if (itemIndex == brightnessEditItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    tft.print(autoConfigItems[itemIndex]);

    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);

    if (itemIndex < 8) {
      int pointIdx = itemIndex / 2;
      bool isLux = (itemIndex % 2 == 0);
      tft.print(isLux ? brightConfig.points[pointIdx].lux : brightConfig.points[pointIdx].brightness);
    } else if (itemIndex == 8) {
      tft.print(brightConfig.reactionSpeed);
    } else if (itemIndex == 9) {
      tft.print(brightConfig.smoothing ? "Вкл" : "Выкл");
    }
  }

  // Индикатор прокрутки
  if (AUTO_CONFIG_ITEMS_COUNT > AUTO_CONFIG_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = 32 * AUTO_CONFIG_VISIBLE_ITEMS;
    int thumbHeight = (AUTO_CONFIG_VISIBLE_ITEMS * scrollBarHeight) / AUTO_CONFIG_ITEMS_COUNT;
    int thumbPos = (autoScrollOffset * scrollBarHeight) / AUTO_CONFIG_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 460);
  tft.print("▲▼ Выбор    <> Изменить    OK");

  lastAutoItem = brightnessEditItem;        // ← синхронизация
  lastAutoScrollOffset = autoScrollOffset;  // ← синхронизация
  menuChanged = false;
}

void handleBrightnessEdit(int key) {
  // Проверяем таймаут
  if (checkMenuTimeout()) return;

  int idx = brightnessEditItem;

  // Обновляем время активности при нажатии
  lastMenuActivity = millis();

  switch (key) {
    case KEY_UP:
      brightnessEditItem--;
      if (brightnessEditItem < 0) brightnessEditItem = AUTO_CONFIG_ITEMS_COUNT - 1;
      menuChanged = true;
      drawAutoConfigMenuNav();
      break;

    case KEY_DOWN:
      brightnessEditItem++;
      if (brightnessEditItem >= AUTO_CONFIG_ITEMS_COUNT) brightnessEditItem = 0;
      menuChanged = true;
      drawAutoConfigMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      editAutoValue(key == KEY_RIGHT);
      hasUnsavedChanges = true;
      // Перерисовать ТОЛЬКО текущую строку (без мерцания всего экрана)
      {
        int visibleIndex = brightnessEditItem - autoScrollOffset;
        if (visibleIndex >= 0 && visibleIndex < AUTO_CONFIG_VISIBLE_ITEMS) {
          drawAutoConfigMenuItem(visibleIndex, true);
        }
      }
      break;

    case KEY_OK:
      if (idx == AUTO_CONFIG_ITEMS_COUNT - 2) {  // Сохранить
        saveBrightnessChanges();
        inBrightnessEdit = false;
        inSensorSubmenu = false;
        inBrightnessSubmenu = false;

        // Показать «Сохранено!» на чистом экране
        tft.fillScreen(TFT_BLACK);
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setTextSize(2);
        tft.setCursor(205, 225);
        tft.print("✅ Сохранено!");
        delay(800);

        // Выход в меню (перерисует всё, «Сохранено!» исчезнет)
        menuChanged = true;
        drawMenu();
        LOG_I("💾 Сохранено в AUTO и выход в меню");

      } else if (idx == AUTO_CONFIG_ITEMS_COUNT - 1) {  // Назад
        if (hasUnsavedChanges) {
          discardBrightnessChanges();
        }
        inBrightnessEdit = false;
        drawBrightnessMenu();
        LOG_I("↩️ Выход без сохранения");
      }
      break;
  }
}

void editAutoValue(bool increase) {
  int idx = brightnessEditItem;

  if (idx < 8) {
    int pointIdx = idx / 2;
    bool isLux = (idx % 2 == 0);

    if (isLux) {
      //int step = (pointIdx == 0) ? 1 : 5;
      int step = 1;
      if (increase) brightConfig.points[pointIdx].lux += step;
      else if (brightConfig.points[pointIdx].lux > step) brightConfig.points[pointIdx].lux -= step;

      if (pointIdx == 0) {
        if (brightConfig.points[0].lux < 1) brightConfig.points[0].lux = 1;
        if (brightConfig.points[0].lux > 15) brightConfig.points[0].lux = 15;
      } else if (pointIdx == 1) {
        if (brightConfig.points[1].lux < 15) brightConfig.points[1].lux = 15;
        if (brightConfig.points[1].lux > 60) brightConfig.points[1].lux = 60;
      } else if (pointIdx == 2) {
        if (brightConfig.points[2].lux < 60) brightConfig.points[2].lux = 60;
        if (brightConfig.points[2].lux > 200) brightConfig.points[2].lux = 200;
      } else if (pointIdx == 3) {
        if (brightConfig.points[3].lux < 200) brightConfig.points[3].lux = 200;
        if (brightConfig.points[3].lux > 500) brightConfig.points[3].lux = 500;
      }
    } else {
      int step = 1;
      if (increase) brightConfig.points[pointIdx].brightness += step;
      else if (brightConfig.points[pointIdx].brightness > step) brightConfig.points[pointIdx].brightness -= step;

      if (pointIdx == 0) {
        if (brightConfig.points[0].brightness < 0) brightConfig.points[0].brightness = 0;
        if (brightConfig.points[0].brightness > 50) brightConfig.points[0].brightness = 50;
      } else if (pointIdx == 1) {
        if (brightConfig.points[1].brightness < 30) brightConfig.points[1].brightness = 30;
        if (brightConfig.points[1].brightness > 100) brightConfig.points[1].brightness = 100;
      } else if (pointIdx == 2) {
        if (brightConfig.points[2].brightness < 50) brightConfig.points[2].brightness = 50;
        if (brightConfig.points[2].brightness > 150) brightConfig.points[2].brightness = 150;
      } else if (pointIdx == 3) {
        if (brightConfig.points[3].brightness < 80) brightConfig.points[3].brightness = 80;
        if (brightConfig.points[3].brightness > 255) brightConfig.points[3].brightness = 255;
      }
    }

  } else if (idx == 8) {
    if (increase) {
      if (brightConfig.reactionSpeed < 10) brightConfig.reactionSpeed++;
    } else {
      if (brightConfig.reactionSpeed > 1) brightConfig.reactionSpeed--;
    }

  } else if (idx == 9) {
    brightConfig.smoothing = !brightConfig.smoothing;
  }
}

// ===================================================================
// ДАТЧИК: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawSensorConfigMenuItem(int itemIndex, bool selected) {
  if (itemIndex < 0 || itemIndex >= SENSOR_CONFIG_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 38;
  int y = startY + itemIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (itemIndex == SENSOR_CONFIG_ITEMS_COUNT - 2) {
    tft.setTextColor(hasUnsavedChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
    tft.print(sensorConfigItems[itemIndex]);
  } else {
    if (selected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    }
    tft.print(sensorConfigItems[itemIndex]);
  }

  if (itemIndex < 2) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setCursor(350, y);
    tft.print(itemIndex == 0 ? brightConfig.calibA : brightConfig.calibB, 1);
  }
}

// ===================================================================
// ДАТЧИК: навигация (2 строки)
// ===================================================================
void drawSensorConfigMenuNav() {
  if (!inBrightnessEdit || !inSensorSubmenu) return;
  if (!menuChanged) return;

  if (lastSensorCfgItem >= 0 && lastSensorCfgItem != brightnessEditItem) {
    drawSensorConfigMenuItem(lastSensorCfgItem, false);
  }
  drawSensorConfigMenuItem(brightnessEditItem, true);

  lastSensorCfgItem = brightnessEditItem;
  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: НАСТРОЙКА ДАТЧИКА
// ===================================================================

void drawSensorConfigMenu() {
  if (!inBrightnessEdit || !inSensorSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Настройка датчика");

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  int startY = 55;
  int stepY = 38;

  for (int i = 0; i < SENSOR_CONFIG_ITEMS_COUNT; i++) {
    int y = startY + i * stepY;

    if (i == brightnessEditItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
    }

    // Цвет для "Сохранить"
    if (i == SENSOR_CONFIG_ITEMS_COUNT - 2) {
      tft.setTextColor(hasUnsavedChanges ? TFT_GREEN : TFT_DARKGREY, TFT_BLACK);
      tft.setCursor(35, y);
      tft.print(sensorConfigItems[i]);
    } else {
      tft.print(sensorConfigItems[i]);
    }

    if (i < 2) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.setCursor(350, y);
      tft.print(i == 0 ? brightConfig.calibA : brightConfig.calibB, 1);
    }
  }

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 460);
  tft.print("▲▼ Выбор    <> Изменить    OK");

  lastSensorCfgItem = brightnessEditItem;  // ← синхронизация
  menuChanged = false;
}

void handleSensorEdit(int key) {
  int idx = brightnessEditItem;

  switch (key) {
    case KEY_UP:
      brightnessEditItem--;
      if (brightnessEditItem < 0) brightnessEditItem = SENSOR_CONFIG_ITEMS_COUNT - 1;
      menuChanged = true;
      drawSensorConfigMenuNav();
      break;

    case KEY_DOWN:
      brightnessEditItem++;
      if (brightnessEditItem >= SENSOR_CONFIG_ITEMS_COUNT) brightnessEditItem = 0;
      menuChanged = true;
      drawSensorConfigMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      editSensorValue(key == KEY_RIGHT);
      hasUnsavedChanges = true;
      // Перерисовать ТОЛЬКО текущую строку
      if (brightnessEditItem >= 0 && brightnessEditItem < SENSOR_CONFIG_ITEMS_COUNT) {
        drawSensorConfigMenuItem(brightnessEditItem, true);
      }
      break;

    case KEY_OK:
      if (idx == SENSOR_CONFIG_ITEMS_COUNT - 2) {  // Сохранить
        saveBrightnessChanges();
        inBrightnessEdit = false;
        inSensorSubmenu = false;
        inBrightnessSubmenu = false;

        tft.fillScreen(TFT_BLACK);
        tft.setTextColor(TFT_GREEN, TFT_BLACK);
        tft.setTextSize(2);
        tft.setCursor(205, 225);
        tft.print("✅ Сохранено!");
        delay(800);

        menuChanged = true;
        drawMenu();
        LOG_I("💾 Сохранено в датчике и выход в меню");

      } else if (idx == SENSOR_CONFIG_ITEMS_COUNT - 1) {  // Назад
        if (hasUnsavedChanges) {
          discardBrightnessChanges();
        }
        inBrightnessEdit = false;
        inSensorSubmenu = false;
        drawBrightnessMenu();
        LOG_I("↩️ Выход без сохранения");
      }
      break;
  }
}

void editSensorValue(bool increase) {
  int idx = brightnessEditItem;
  float step = 0.1;

  if (idx == 0) {
    if (increase) {
      brightConfig.calibA += step;
      if (brightConfig.calibA > 20.0) brightConfig.calibA = 20.0;
    } else {
      brightConfig.calibA -= step;
      if (brightConfig.calibA < 1.0) brightConfig.calibA = 1.0;
    }

  } else if (idx == 1) {
    if (increase) {
      brightConfig.calibB += step;
      if (brightConfig.calibB > 10.0) brightConfig.calibB = 10.0;
    } else {
      brightConfig.calibB -= step;
      if (brightConfig.calibB < -10.0) brightConfig.calibB = -10.0;
    }
  }
}

// ===================================================================
// О СИСТЕМЕ: заполнение глобального systemLines[] (один раз)
// ===================================================================
void rebuildSystemLines() {
  int lineIdx = 0;

  strncpy(systemLines[lineIdx++], "ДИАГНОСТИКА СЕАНСА:", 40);
  strncpy(systemLines[lineIdx++], "  Открыть", 40);
  strncpy(systemLines[lineIdx++], "", 40);

  strncpy(systemLines[lineIdx++], "ПЛАТФОРМА:", 40);
  snprintf(systemLines[lineIdx++], 40, "  ESP32-S3  %u МГц", ESP.getCpuFreqMHz());
  snprintf(systemLines[lineIdx++], 40, "  RAM: %u K", (unsigned)(ESP.getFreeHeap() / 1024));
  strncpy(systemLines[lineIdx++], "", 40);

  unsigned long uptime = millis() / 1000;
  int days = uptime / 86400;
  int hours = (uptime % 86400) / 3600;
  int mins = (uptime % 3600) / 60;
  strncpy(systemLines[lineIdx++], "АПТАЙМ:", 40);
  snprintf(systemLines[lineIdx++], 40, "  %dд %dч %dм", days, hours, mins);
  strncpy(systemLines[lineIdx++], "", 40);

  strncpy(systemLines[lineIdx++], "МОДУЛИ:", 40);
  strncpy(systemLines[lineIdx++], "   DS3231", 40);
  strncpy(systemLines[lineIdx++], "   NRF24L01", 40);
  strncpy(systemLines[lineIdx++], "   BME280", 40);
  strncpy(systemLines[lineIdx++], "   SCD40", 40);
  strncpy(systemLines[lineIdx++], "   TEMT6000", 40);
  strncpy(systemLines[lineIdx++], sdLoggingEnabled ? "   SD-карта [Вкл]" : "   SD-карта [Выкл]", 40);
  // Размер карты / свободно
  if (sdReady) {
    uint64_t total = SD.totalBytes();
    uint64_t used = SD.usedBytes();
    uint64_t freeBytes = total - used;
    double totalGB = total / (1024.0 * 1024.0 * 1024.0);
    double freeGB = freeBytes / (1024.0 * 1024.0 * 1024.0);
    snprintf(systemLines[lineIdx++], 40, "   %.1f ГБ, своб. %.1f ГБ", totalGB, freeGB);
  } else {
    strncpy(systemLines[lineIdx++], "   —", 40);
  }
  strncpy(systemLines[lineIdx++], "", 40);

  strncpy(systemLines[lineIdx++], "УЛИЧНЫЙ МОДУЛЬ:", 40);
  strncpy(systemLines[lineIdx++], isNoSignalWarningActive ? "  Нет сигнала" : "  Подключен", 40);
  strncpy(systemLines[lineIdx++], "", 40);

  strncpy(systemLines[lineIdx++], "НАЗАД", 40);
}

// ===================================================================
// О СИСТЕМЕ: отрисовка одной строки (по абсолютному idx 0..21)
// ===================================================================
void drawSystemInfoLine(int idx, bool selected) {
  if (idx < 0 || idx >= SYSTEM_TOTAL_LINES) return;
  if (idx < systemScrollOffset || idx >= systemScrollOffset + SYSTEM_VISIBLE_ITEMS) return;

  int visibleIndex = idx - systemScrollOffset;
  int startY = 55;
  int lineHeight = 26;
  int y = startY + visibleIndex * lineHeight;

  const char* line = systemLines[idx];

  // Очистить область строки (с запасом сверху — подсветка рисуется на y-2)
  tft.fillRect(0, y - 2, 470, lineHeight + 2, TFT_BLACK);

  // ">" для выбранного (кроме "НАЗАД")
  if (selected && strcmp(line, "НАЗАД") != 0) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(5, y);
    tft.print(">");
  }

  // "НАЗАД" — отдельно (TFT_BLUE, без ">")
  if (strcmp(line, "НАЗАД") == 0) {
    if (selected) {
      tft.fillRect(20, y - 2, 120, 24, TFT_BLUE);
      tft.setTextColor(TFT_WHITE, TFT_BLUE);
    } else {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    }
    tft.setTextSize(2);
    tft.setCursor(25, y);
    tft.print("НАЗАД");
    return;
  }

  // Пустая строка — ничего
  if (line[0] == '\0') return;

  // Цвет (как в drawSystemInfo)
  if (strncmp(line, "ПЛАТФОРМА:", 10) == 0 || strncmp(line, "АПТАЙМ:", 7) == 0 || strncmp(line, "МОДУЛИ:", 7) == 0 || strncmp(line, "УЛИЧНЫЙ МОДУЛЬ:", 15) == 0) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setTextSize(2);
  } else if (strstr(line, "SD-карта") != nullptr) {
    tft.setTextColor(sdReady ? TFT_GREEN : TFT_RED, TFT_BLACK);
    tft.setTextSize(2);
  } else {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
  }

  // Подсветка выбранной (TFT_NAVY)
  if (selected) {
    tft.fillRect(20, y - 2, 440, 24, TFT_NAVY);
    tft.setTextColor(TFT_WHITE, TFT_NAVY);
    tft.setCursor(25, y);
  } else {
    tft.setCursor(25, y);
  }
  tft.print(line);
}

// ===================================================================
// О СИСТЕМЕ: навигация (2 строки / 9 при скролле)
// ===================================================================
void drawSystemInfoNav() {
  if (!menuChanged) return;

  // Пересчёт скролла
  if (systemCursorPos < systemScrollOffset) {
    systemScrollOffset = systemCursorPos;
  }
  if (systemCursorPos >= systemScrollOffset + SYSTEM_VISIBLE_ITEMS) {
    systemScrollOffset = systemCursorPos - SYSTEM_VISIBLE_ITEMS + 1;
  }
  if (SYSTEM_TOTAL_LINES <= SYSTEM_VISIBLE_ITEMS) {
    systemScrollOffset = 0;
  }

  if (systemScrollOffset != lastSystemScrollOffset) {
    // Скролл — все видимые + скроллбар
    tft.fillRect(0, 55, 480, SYSTEM_VISIBLE_ITEMS * 26, TFT_BLACK);
    for (int i = 0; i < SYSTEM_VISIBLE_ITEMS; i++) {
      int idx = i + systemScrollOffset;
      if (idx >= SYSTEM_TOTAL_LINES) break;
      drawSystemInfoLine(idx, idx == systemCursorPos);
    }
    // Скроллбар
    if (SYSTEM_TOTAL_LINES > SYSTEM_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int lineHeight = 26;
      int scrollBarHeight = lineHeight * SYSTEM_VISIBLE_ITEMS;
      int thumbHeight = (SYSTEM_VISIBLE_ITEMS * scrollBarHeight) / SYSTEM_TOTAL_LINES;
      int thumbPos = (systemScrollOffset * scrollBarHeight) / SYSTEM_TOTAL_LINES;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastSystemScrollOffset = systemScrollOffset;
    lastSystemItem = systemCursorPos;
  } else {
    // 2 строки
    if (lastSystemItem >= 0 && lastSystemItem != systemCursorPos) {
      drawSystemInfoLine(lastSystemItem, false);
    }
    drawSystemInfoLine(systemCursorPos, true);
    lastSystemItem = systemCursorPos;
  }

  menuChanged = false;
}

// ===================================================================
// ПОДМЕНЮ: О СИСТЕМЕ
// ===================================================================

void drawSystemInfo() {
  tft.fillScreen(TFT_BLACK);

  // ===== ЗАГОЛОВОК =====
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Метеостанция");

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setCursor(350, 10);
  tft.print("v2.3.8 b");

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== ПОДГОТОВКА ДАННЫХ =====
  rebuildSystemLines();

  // ===== КОРРЕКТИРОВКА ОФФСЕТА =====
  int maxOffset = SYSTEM_TOTAL_LINES - SYSTEM_VISIBLE_ITEMS;
  if (maxOffset < 0) maxOffset = 0;
  if (systemScrollOffset > maxOffset) systemScrollOffset = maxOffset;
  if (systemScrollOffset < 0) systemScrollOffset = 0;

  // ===== ОТОБРАЖЕНИЕ =====
  int startY = 55;
  int lineHeight = 26;

  for (int i = 0; i < SYSTEM_VISIBLE_ITEMS && (i + systemScrollOffset) < SYSTEM_TOTAL_LINES; i++) {
    int idx = i + systemScrollOffset;
    int y = startY + i * lineHeight;
    const char* line = systemLines[idx];

    // Проверяем, выбран ли текущий пункт
    bool isSelected = (idx == systemCursorPos);

    // Рисуем стрелку курсора
    if (isSelected) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setTextSize(2);
      tft.setCursor(5, y);
      tft.print(">");  // Стрелка вправо
    } else {
      // Очищаем место для стрелки
      tft.fillRect(5, y, 15, 24, TFT_BLACK);
    }

    if (strcmp(line, "НАЗАД") == 0) {
      if (isSelected) {
        // Подсвечиваем выбранный пункт
        tft.fillRect(20, y - 2, 120, 24, TFT_BLUE);
        tft.setTextColor(TFT_WHITE, TFT_BLUE);
      } else {
        tft.setTextColor(TFT_WHITE, TFT_BLACK);
      }
      tft.setTextSize(2);
      tft.setCursor(25, y);
      tft.print("НАЗАД");
      continue;
    } else if (strncmp(line, "ПЛАТФОРМА:", 10) == 0 || strncmp(line, "АПТАЙМ:", 7) == 0 || strncmp(line, "МОДУЛИ:", 7) == 0 || strncmp(line, "УЛИЧНЫЙ МОДУЛЬ:", 15) == 0) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.setTextSize(2);
    } else if (strstr(line, "SD-карта") != nullptr) {
      // Специально для SD-карты: цвет зависит от sdReady
      tft.setTextColor(sdReady ? TFT_GREEN : TFT_RED, TFT_BLACK);
      tft.setTextSize(2);
    } else if (strstr(line, "●") != nullptr) {
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      tft.setTextSize(2);
    } else if (strstr(line, "○") != nullptr) {
      tft.setTextColor(TFT_RED, TFT_BLACK);
      tft.setTextSize(2);
    } else if (line[0] == '\0') {
      continue;
    } else {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setTextSize(2);
    }

    // Если строка выбрана, но не "НАЗАД" - подсвечиваем
    if (isSelected && strcmp(line, "НАЗАД") != 0) {
      tft.fillRect(20, y - 2, 440, 24, TFT_NAVY);  // Темно-синий фон
      tft.setTextColor(TFT_WHITE, TFT_NAVY);
      tft.setCursor(25, y);
    } else {
      tft.setCursor(25, y);
    }
    tft.print(line);
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (SYSTEM_TOTAL_LINES > SYSTEM_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = SYSTEM_VISIBLE_ITEMS * lineHeight;
    int thumbHeight = (SYSTEM_VISIBLE_ITEMS * scrollBarHeight) / SYSTEM_TOTAL_LINES;
    int thumbPos = (systemScrollOffset * scrollBarHeight) / SYSTEM_TOTAL_LINES;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  // ===== ПОДСКАЗКА =====
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    OK - выход");
}

// ===================================================================
// ОБРАБОТЧИК ЭКРАНА "О СИСТЕМЕ"
// ===================================================================

void handleSystemInfo() {
  systemCursorPos = SYSTEM_TOTAL_LINES - 1;
  systemScrollOffset = 0;
  lastSystemItem = -1;
  lastSystemScrollOffset = -1;

  checkSD();  // принудительно проверяем карту перед входом

  drawSystemInfo();

  while (true) {
    if (checkMenuTimeout()) {
      // Не вызываем exitMenuMode() здесь
      // Просто выходим из функции, перерисовка будет в handleMenuItemSelected
      LOG_D("⏰ Таймаут в О системе");
      return;
    }

    int key = readKeypadWithRepeat();
    if (key == KEY_NONE) {
      delay(50);
      continue;
    }

    lastMenuActivity = millis();

    // ОТЛАДКА
    LOG_D("🔑 Клавиша: %d, systemCursorPos: %d, НАЗАД: %d",
          key, systemCursorPos, SYSTEM_TOTAL_LINES - 1);

    switch (key) {
      case KEY_UP:
        systemCursorPos--;
        if (systemCursorPos < 0) systemCursorPos = SYSTEM_TOTAL_LINES - 1;
        menuChanged = true;
        drawSystemInfoNav();
        break;

      case KEY_DOWN:
        systemCursorPos++;
        if (systemCursorPos >= SYSTEM_TOTAL_LINES) systemCursorPos = 0;
        menuChanged = true;
        drawSystemInfoNav();
        break;

      case KEY_LEFT:
      case KEY_RIGHT:
        {
          // Ищем строку с SD-карта в текущем списке (примерный индекс 13)
          // Проще всего проверить, наведен ли курсор на строку, содержащую "SD-карта"
          // Так как мы знаем порядок, это индекс: ДИАГНОСТИКА (0,1,2) + ПЛАТФОРМА (3,4,5,6) + АПТАЙМ (7,8,9,10) + МОДУЛИ (11) + 5 модулей (12-16) + SD (17).
          // Давайте сделаем проверку надежнее, вычислив позицию SD.
          // Но так как у нас есть `systemCursorPos`, мы можем просто проверить, совпадает ли текущая позиция с SD.
          // Для простоты: если текст текущей строки содержит "SD-карта"

          // Чтобы не усложнять, просто проверим позицию (индекс 17, если я правильно посчитал).
          // Но лучше сделать это явно.
          // Найдем индекс SD в массиве lines (в drawSystemInfo он 17-й, считая с 0).

          if (systemCursorPos == SYSTEM_SD_LINE_INDEX) {
            sdLoggingEnabled = !sdLoggingEnabled;
            saveSdConfig();

            if (sdLoggingEnabled) {
              initSD();  // Пытаемся включить
            } else {
              deinitSD();  // Выключаем
              // Стираем индикатор с главного экрана (если он там)
              extern int8_t lastSdStatusDrawn;
              lastSdStatusDrawn = -1;
            }
            drawSystemInfo();  // Перерисовываем меню
          }
        }
        break;

      case KEY_OK:
        // ===== ПУНКТ «ОТКРЫТЬ» (строка 1 — «  Открыть») =====
        if (systemCursorPos == 1) {
          sessionScrollOffset = 0;
          drawSessionDiagnostics();
          while (true) {
            int k = readKeypadWithRepeat();
            if (k == KEY_OK) break;
            if (k == KEY_UP && sessionScrollOffset > 0) {
              sessionScrollOffset--;
              drawSessionDiagnostics();
            } else if (k == KEY_DOWN) {
              int maxOff = 11 - SESSION_VISIBLE_LINES;
              if (maxOff < 0) maxOff = 0;
              if (sessionScrollOffset < maxOff) {
                sessionScrollOffset++;
                drawSessionDiagnostics();
              }
            }
            delay(50);
          }
          drawSystemInfo();
        } else if (systemCursorPos == SYSTEM_TOTAL_LINES - 1) {
          // Выход — ТОЛЬКО на строке «НАЗАД» (последняя)
          lastMenuActivity = millis();  // сброс таймаута меню
          LOG_I("🚪 Выход из системы");
          return;
        }
        // На остальных строках OK ничего не делает
        break;
    }
  }
}

// ===================================================================
// ПОДТВЕРЖДЕНИЕ СБРОСА КАЛИБРОВОК
// ===================================================================
void showResetConfirmation() {
  if (showConfirmDialog("Сбросить настройки?",
                        "Все настройки подсветки",
                        "будут сброшены.")) {
    resetBrightnessConfig();
    hasUnsavedChanges = false;
    LOG_I("🔄 Настройки подсветки сброшены");
    drawBrightnessMenu();

    tft.fillRect(200, 220, 120, 30, TFT_BLACK);
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(205, 225);
    tft.print("Сброшено!");
    delay(800);
    drawBrightnessMenu();
  } else {
    drawBrightnessMenu();
  }
}

void showResetCalibrationConfirmation(const char* title, int type) {
  char line1[64];
  snprintf(line1, sizeof(line1), "Все калибровки:");
  // Можно передать title в line2
  if (showConfirmDialog("Сбросить калибровки?",
                        line1,
                        "будут сброшены.")) {
    switch (type) {
      case 0: resetCalibrationConfig(true, false); break;
      case 1: resetCalibrationConfig(false, true); break;
      case 2: resetCalibrationConfig(true, true); break;
    }
    hasSensorChanges = false;
    LOG_I("🔄 Калибровки сброшены");
    drawSensorsMenu();

    tft.fillRect(200, 220, 120, 30, TFT_BLACK);
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(205, 225);
    tft.print("Сброшено!");
    delay(800);
    drawSensorsMenu();
  } else {
    drawSensorsMenu();
  }
}

// ===================================================================
// ПОДМЕНЮ: WI-FI
// ===================================================================

// Названия интервалов (для отображения)
const char* wifiIntervalNames[WIFI_INTERVAL_COUNT] = {
  "30 мин",
  "1 час",
  "2 часа",
  "3 часа"
};

// Индексы пунктов меню Wi-Fi
#define WIFI_ITEM_MODE 0      // Wi-Fi Вкл/Выкл
#define WIFI_ITEM_INTERVAL 1  // Интервал
#define WIFI_ITEM_REFRESH 2   // Обновить сейчас
#define WIFI_ITEM_CONFIG 3    // Настроить Wi-Fi
#define WIFI_ITEM_BACK 4      // Назад
#define WIFI_ITEMS_COUNT 5

const char* wifiSubmenuItems[] = {
  "Wi-Fi",
  "Интервал",
  "Обновить сейчас",
  "Настроить Wi-Fi",
  "Назад"
};

// ===================================================================
// WI-FI: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawWiFiMenuItem(int itemIndex, bool selected) {
  if (itemIndex < 0 || itemIndex >= WIFI_ITEMS_COUNT) return;

  int startY = 60;
  int stepY = 40;
  int y = startY + itemIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  // Disabled?
  bool disabled = false;
  if (itemIndex == WIFI_ITEM_REFRESH && !wifiConfig.enabled) disabled = true;
  if (itemIndex == WIFI_ITEM_INTERVAL && !wifiConfig.enabled) disabled = true;
  if (itemIndex == WIFI_ITEM_INTERVAL && wifiConfig.forecastSource == 2) disabled = true;

  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (disabled) {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  } else if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  }
  tft.print(wifiSubmenuItems[itemIndex]);

  // Значения справа
  tft.setCursor(300, y);
  if (itemIndex == WIFI_ITEM_MODE) {
    tft.setTextColor(wifiConfig.enabled ? TFT_GREEN : TFT_RED, TFT_BLACK);
    tft.print(wifiConfig.enabled ? "Вкл" : "Выкл");
  } else if (itemIndex == WIFI_ITEM_INTERVAL) {
    if (!wifiConfig.enabled) {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.print("-");
    } else if (wifiConfig.forecastSource == 2) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.print("1 час (Яндекс)");
    } else {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.print(wifiIntervalNames[wifiConfig.intervalIdx]);
    }
  }
}

// ===================================================================
// WI-FI: навигация (2 строки, без скролла)
// ===================================================================
void drawWiFiMenuNav() {
  if (!inWiFiSubmenu) return;
  if (!menuChanged) return;

  if (lastWiFiItem >= 0 && lastWiFiItem != wifiSubmenuItem) {
    drawWiFiMenuItem(lastWiFiItem, false);
  }
  drawWiFiMenuItem(wifiSubmenuItem, true);

  lastWiFiItem = wifiSubmenuItem;
  menuChanged = false;
}

void drawWiFiMenu() {
  if (!inWiFiSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Wi-Fi");

  // ===== СТАТУС В ПРАВОМ ВЕРХУ =====
  // Показываем статус «по настройке» (задача №4f):
  // не фактическое состояние радио, а то, что выбрал пользователь.
  tft.setCursor(280, 10);
  if (wifiConfig.enabled) {
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.print("ON ");
  } else {
    tft.setTextColor(TFT_RED, TFT_BLACK);
    tft.print("OFF");
  }

  // ===== ИНДИКАЦИЯ ПРОБЛЕМЫ ПОСЛЕДНЕГО СЕАНСА =====
  if (wifiConfig.enabled && lastSessionFailed) {
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(10, 35);
    tft.print("! последний сеанс: ошибка");
    tft.setTextSize(2);
  } else if (wifiConfig.enabled && wifiSessionInProgress) {
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(10, 35);
    tft.print("... идёт сеанс связи");
    tft.setTextSize(2);
  }

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== ПУНКТЫ =====
  int startY = 60;
  int stepY = 40;

  for (int i = 0; i < WIFI_ITEMS_COUNT; i++) {
    int y = startY + i * stepY;

    // ===== ПУНКТ «ОБНОВИТЬ СЕЙЧАС» — только если Wi-Fi включён =====
    bool disabled = false;
    if (i == WIFI_ITEM_REFRESH && !wifiConfig.enabled) {
      disabled = true;
    }

    // ===== ПУНКТ «ИНТЕРВАЛ» — только если Wi-Fi включён =====
    if (i == WIFI_ITEM_INTERVAL && !wifiConfig.enabled) {
      disabled = true;
    }
    // ===== ПУНКТ «ИНТЕРВАЛ» — серый при источнике Яндекс =====
    if (i == WIFI_ITEM_INTERVAL && wifiConfig.forecastSource == 2) {
      disabled = true;
    }

    // ===== СТРЕЛКА КУРСОРА =====
    if (i == wifiSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setCursor(35, y);
    }

    // ===== ЦВЕТ ТЕКСТА ПУНКТА =====
    if (disabled) {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    } else if (i == wifiSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    }

    tft.print(wifiSubmenuItems[i]);

    // ===== ЗНАЧЕНИЕ СПРАВА =====
    tft.setCursor(300, y);

    if (i == WIFI_ITEM_MODE) {
      // Wi-Fi: Вкл / Выкл
      tft.setTextColor(wifiConfig.enabled ? TFT_GREEN : TFT_RED, TFT_BLACK);
      tft.print(wifiConfig.enabled ? "Вкл" : "Выкл");

    } else if (i == WIFI_ITEM_INTERVAL) {
      // Интервал: 30 мин / 1 час / 2 часа / 3 часа
      if (!wifiConfig.enabled) {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.print("-");
      } else if (wifiConfig.forecastSource == 2) {
        tft.setTextColor(TFT_CYAN, TFT_BLACK);
        tft.print("1 час (Яндекс)");
      } else {
        tft.setTextColor(TFT_CYAN, TFT_BLACK);
        tft.print(wifiIntervalNames[wifiConfig.intervalIdx]);
      }
    }
  }

  // ===== ПОДСКАЗКА ВНИЗУ =====
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastWiFiItem = wifiSubmenuItem;  // ← синхронизация
  menuChanged = false;
}

void handleWiFiMenu() {
  if (!inWiFiSubmenu) return;
  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  lastMenuActivity = millis();

  switch (key) {
    case KEY_UP:
      wifiSubmenuItem--;
      if (wifiSubmenuItem < 0) wifiSubmenuItem = WIFI_ITEMS_COUNT - 1;
      menuChanged = true;
      drawWiFiMenuNav();
      break;

    case KEY_DOWN:
      wifiSubmenuItem++;
      if (wifiSubmenuItem >= WIFI_ITEMS_COUNT) wifiSubmenuItem = 0;
      menuChanged = true;
      drawWiFiMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      handleWiFiValueChange(key == KEY_RIGHT);
      // Если меняется Wi-Fi Вкл/Выкл (индекс 0) — перерисовать ВСЁ
      // (меняется disabled-статус строк 1, 2)
      if (wifiSubmenuItem == WIFI_ITEM_MODE) {
        drawWiFiMenu();
      } else {
        // Иначе — только текущую строку
        if (wifiSubmenuItem >= 0 && wifiSubmenuItem < WIFI_ITEMS_COUNT) {
          drawWiFiMenuItem(wifiSubmenuItem, true);
        }
      }
      break;

    case KEY_OK:
      // Пункт «Назад»
      if (wifiSubmenuItem == WIFI_ITEM_BACK) {
        inWiFiSubmenu = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход из Wi-Fi");
        break;
      }

      // Пункт «Обновить сейчас»
      if (wifiSubmenuItem == WIFI_ITEM_REFRESH) {
        if (!wifiConfig.enabled) {
          showWiFiDisabledHint();
          break;
        }
        confirmAndRefreshForecast();
        drawWiFiMenu();
        break;
      }

      // Пункт «Настроить Wi-Fi»
      if (wifiSubmenuItem == WIFI_ITEM_CONFIG) {
        showWiFiConfigHint();
        break;
      }

      // Остальные пункты — вход не нужен, они меняются через <>
      break;

    case KEY_NONE:
      break;
  }
}

// Обработка изменений через <>
static void handleWiFiValueChange(bool increase) {
  // ===== Wi-Fi Вкл/Выкл =====
  if (wifiSubmenuItem == WIFI_ITEM_MODE) {
    bool newState = !wifiConfig.enabled;
    setWiFiEnabled(newState);
    return;
  }

  // ===== Интервал =====
  if (wifiSubmenuItem == WIFI_ITEM_INTERVAL) {
    if (!wifiConfig.enabled) return;             // неактивен при Wi-Fi выкл
    if (wifiConfig.forecastSource == 2) return;  // неактивен для Яндекса
    if (increase) {
      wifiConfig.intervalIdx++;
      if (wifiConfig.intervalIdx >= WIFI_INTERVAL_COUNT)
        wifiConfig.intervalIdx = 0;
    } else {
      if (wifiConfig.intervalIdx == 0)
        wifiConfig.intervalIdx = WIFI_INTERVAL_COUNT - 1;
      else
        wifiConfig.intervalIdx--;
    }
    saveWiFiConfig();
    LOG_I("⏱ Интервал: %s", wifiIntervalNames[wifiConfig.intervalIdx]);
  }
}

// Изменение состояния Wi-Fi с логикой связки источника
static void setWiFiEnabled(bool enable) {
  if (wifiConfig.enabled == enable) return;

  wifiConfig.enabled = enable;

  if (!enable) {
    // ===== Wi-Fi ВЫКЛЮЧАЕМ =====
    // Запоминаем текущий источник
    wifiConfig.forecastSourceBeforeWiFiOff = wifiConfig.forecastSource;

    // Принудительно — «Свой»
    wifiConfig.forecastSource = 0;

    // Глушим радио
    WiFi.disconnect(false);
    WiFi.mode(WIFI_OFF);

    LOG_I("📶 Wi-Fi ВЫКЛ");
    LOG_I("📡 Источник → Свой (был: %s)",
          wifiConfig.forecastSourceBeforeWiFiOff ? "Open-Meteo" : "Свой");
  } else {
    // ===== Wi-Fi ВКЛЮЧАЕМ =====
    // Восстанавливаем источник, если он был Open-Meteo
    if (wifiConfig.forecastSourceBeforeWiFiOff) {
      wifiConfig.forecastSource = 1;
      LOG_I("🌐 Источник → Open-Meteo (восстановлен)");
    }
    wifiConfig.forecastSourceBeforeWiFiOff = 0;

    // Включаем радио
    WiFi.mode(WIFI_STA);

    // Сбрасываем таймер, чтобы сеанс пошёл сразу
    lastWiFiSessionTime = 0;

    LOG_I("📶 Wi-Fi ВКЛ (сеанс запустится сразу)");
  }

  saveWiFiConfig();
  wifiSubmenuItem = WIFI_ITEM_MODE;  // возврат на первый пункт
}

// Подсказка «Сначала включите Wi-Fi»
static void showWiFiDisabledHint() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Wi-Fi выключен");
  tft.setCursor(10, 60);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(1);
  tft.print("Включите Wi-Fi в пункте «Wi-Fi»,");
  tft.setCursor(10, 80);
  tft.print("затем повторите.");
  delay(1800);
  drawWiFiMenu();
}

// ===================================================================
// ПОРТАЛ НАСТРОЙКИ WI-FI И КООРДИНАТ
// ===================================================================
static void showWiFiConfigHint() {
  LOG_I("🌐 Запуск портала настройки Wi-Fi...");

  // ===== 1. ЗАПОЛНЯЕМ ПОЛЯ ТЕКУЩИМИ ЗНАЧЕНИЯМИ =====
  char latStr[16];
  char lonStr[16];
  snprintf(latStr, sizeof(latStr), "%.6f", locationConfig.lat);
  snprintf(lonStr, sizeof(lonStr), "%.6f", locationConfig.lon);

  // API-ключ Яндекса: берём из wifiConfig
  char apiKeyStr[41];
  strncpy(apiKeyStr, wifiConfig.yandexApiKey, 40);
  apiKeyStr[40] = '\0';

  WiFiManagerParameter param_lat("lat", "Широта (latitude)", latStr, 15);
  WiFiManagerParameter param_lon("lon", "Долгота (longitude)", lonStr, 15);
  WiFiManagerParameter param_api("ykey", "API-ключ Яндекса", apiKeyStr, 40);

  // ===== 2. СОЗДАЁМ WiFiManager =====
  WiFiManager wm;
  wm.setDebugOutput(false);        // отключить спам в Serial
  wm.setConfigPortalTimeout(300);  // 5 минут

  wm.addParameter(&param_lat);
  wm.addParameter(&param_lon);
  wm.addParameter(&param_api);

  // ===== 3. КОЛБЭК СОХРАНЕНИЯ ПАРАМЕТРОВ =====
  wm.setSaveParamsCallback([&param_lat, &param_lon, &param_api]() {
    float newLat = atof(param_lat.getValue());
    float newLon = atof(param_lon.getValue());

    bool ok = true;
    if (isnan(newLat) || isnan(newLon)) ok = false;
    if (newLat < -90.0 || newLat > 90.0) ok = false;
    if (newLon < -180.0 || newLon > 180.0) ok = false;
    if (newLat == 0.0 && newLon == 0.0) ok = false;

    if (ok) {
      locationConfig.lat = newLat;
      locationConfig.lon = newLon;
      saveLocationConfig();
      LOG_I("📍 Координаты обновлены: %.6f, %.6f", newLat, newLon);
    } else {
      LOG_W("⚠️ Некорректные координаты — игнорируем");
    }

    // ===== API-ключ Яндекса =====
    const char* newKey = param_api.getValue();
    if (newKey != nullptr) {
      strncpy(wifiConfig.yandexApiKey, newKey, 39);
      wifiConfig.yandexApiKey[39] = '\0';
      LOG_I("🔑 API-ключ Яндекса: %s...",
            String(wifiConfig.yandexApiKey).substring(0, 8).c_str());
    }

    wifiConfig.configured = true;
    saveWiFiConfig();
    LOG_I("✅ Флаг 'configured' установлен");
  });

  // ===== 4. ЭКРАН ПРИГЛАШЕНИЯ =====
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Настройка Wi-Fi");

  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 60);
  tft.print("1. Подключитесь к сети:");
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setCursor(20, 90);
  tft.print("MeteoStation-Setup");

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 130);
  tft.print("2. Откройте в браузере:");
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setCursor(20, 160);
  tft.print("192.168.4.1");

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(10, 200);
  tft.print("3. Выберите сеть, введите");
  tft.setCursor(20, 230);
  tft.print("пароль и координаты.");

  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.setTextSize(1);
  tft.setCursor(10, 270);
  tft.print("Таймаут: 5 минут. Затем - автовыход.");

  tft.setTextSize(2);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.setCursor(10, 295);
  tft.print("Ожидание подключения...");

  // ===== 5. ЗАПУСКАЕМ ПОРТАЛ (НЕБЛОКИРУЮЩИЙ) =====
  wm.setConfigPortalBlocking(false);
  wm.startConfigPortal("MeteoStation-Setup");

  LOG_I("▶️ Портал активен. OK — выход.");

  // ===== 6. КРУТИМ ЦИКЛ, ПОКА ПОРТАЛ АКТИВЕН =====
  unsigned long portalStart = millis();
  bool userAbort = false;

  while (wm.getConfigPortalActive()) {
    // Обслуживаем портал (обрабатываем HTTP-запросы)
    wm.process();

    // Проверяем кнопку OK (выход)
    int key = readKeypad();
    if (key == KEY_OK) {
      userAbort = true;
      LOG_I("⏹ Выход по кнопке OK");
      break;
    }

    // Обновляем надпись «Осталось: N сек» раз в секунду
    static unsigned long lastUpdate = 0;
    if (millis() - lastUpdate >= 1000) {
      lastUpdate = millis();
      unsigned long elapsed = (millis() - portalStart) / 1000;
      unsigned long remaining = (300 > elapsed) ? (300 - elapsed) : 0;

      // Рисуем строку внизу
      tft.fillRect(10, 295, 460, 25, TFT_BLACK);
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      tft.setTextSize(2);
      tft.setCursor(10, 297);
      tft.printf("OK-выход   %lu сек", remaining);
    }

    delay(20);
  }

  // Принудительно закрываем портал, если вышли по кнопке
  if (userAbort && wm.getConfigPortalActive()) {
    wm.stopConfigPortal();
  }

  // Небольшая пауза, чтобы WiFiManager «успокоился»
  delay(500);

  // ===== 7. ОПРЕДЕЛЯЕМ РЕЗУЛЬТАТ =====
  // Читаем SSID прямо из NVS — работает даже при выключенном радио
  wifi_config_t conf;
  bool ssidSaved = false;
  if (esp_wifi_get_config(WIFI_IF_STA, &conf) == ESP_OK) {
    ssidSaved = (strlen((char*)conf.sta.ssid) > 0);
  }

  tft.fillScreen(TFT_BLACK);
  if (ssidSaved) {
    LOG_I("✅ Портал завершён: сеть настроена");
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Wi-Fi настроен!");
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(10, 60);
    tft.print("Сеть сохранена в NVS.");
    tft.setCursor(10, 80);
    tft.print("Первый сеанс начнётся");
    tft.setCursor(10, 100);
    tft.print("автоматически.");
  } else {
    LOG_W("⚠️ Портал закрыт без сохранения");
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, 10);
    tft.print("Портал закрыт");
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(10, 60);
    tft.print("Настройка не завершена.");
    tft.setCursor(10, 80);
    tft.print("Попробуйте ещё раз.");
  }

  // ===== 8. ВОЗВРАЩАЕМСЯ В ПОДМЕНЮ =====
  lastMenuActivity = millis();  // сбрасываем таймаут меню
  delay(2000);
  drawWiFiMenu();
}

// ===================================================================
// ПОДМЕНЮ: ИСТОЧНИК ПРОГНОЗА
// ===================================================================

// Индексы пунктов
#define FORECAST_ITEM_RF 0         // Свой (RF)
#define FORECAST_ITEM_OPENMETEO 1  // Интернет (Open-Meteo)
#define FORECAST_ITEM_YANDEX 2     // Яндекс
#define FORECAST_ITEM_FORMAT 3     // Формат Яндекса
#define FORECAST_ITEM_PERIOD 4     // Период прогноза
#define FORECAST_ITEM_REFRESH 5    // Обновить сейчас
#define FORECAST_ITEM_BACK 6       // Назад
#define FORECAST_SOURCE_ITEMS_COUNT 7

#define FORECAST_SOURCE_VISIBLE_ITEMS 6  // сколько видно без прокрутки

const char* forecastSourceItems[] = {
  "Свой (RF)",
  "Open-Meteo",
  "Яндекс",
  "Формат Яндекса",
  "Период прогноза",
  "Обновить сейчас",
  "Назад"
};

// ===================================================================
// ИСТОЧНИК: отрисовка одной строки (для навигации без мерцания)
// ===================================================================
void drawForecastSourceMenuItem(int visibleIndex, bool selected) {
  if (visibleIndex < 0 || visibleIndex >= FORECAST_SOURCE_VISIBLE_ITEMS) return;
  int itemIndex = visibleIndex + forecastSourceScrollOffset;
  if (itemIndex < 0 || itemIndex >= FORECAST_SOURCE_ITEMS_COUNT) return;

  int startY = 55;
  int stepY = 35;
  int y = startY + visibleIndex * stepY;

  tft.fillRect(0, y, 470, stepY, TFT_BLACK);

  if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(">");
  }

  // Disabled?
  bool disabled = false;
  if (itemIndex == FORECAST_ITEM_OPENMETEO && !wifiConfig.enabled) disabled = true;
  if (itemIndex == FORECAST_ITEM_YANDEX && !wifiConfig.enabled) disabled = true;
  if (itemIndex == FORECAST_ITEM_REFRESH && !wifiConfig.enabled) disabled = true;
  if (itemIndex == FORECAST_ITEM_FORMAT && wifiConfig.forecastSource != 2) disabled = true;
  if (itemIndex == FORECAST_ITEM_PERIOD) {
    bool periodActive = (wifiConfig.forecastSource == 1) || (wifiConfig.forecastSource == 2 && forecastConfig.yandexFormat == 0);
    if (!periodActive) disabled = true;
  }

  tft.setTextSize(2);
  tft.setCursor(35, y);

  if (disabled) {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  } else if (selected) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
  } else {
    tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  }
  tft.print(forecastSourceItems[itemIndex]);

  // Значения справа
  if (itemIndex == FORECAST_ITEM_FORMAT) {
    tft.setCursor(330, y);
    if (wifiConfig.forecastSource == 2) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.print(forecastConfig.yandexFormat == 0 ? "Часы" : "Сутки");
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.print("-");
    }
  } else if (itemIndex == FORECAST_ITEM_PERIOD) {
    tft.setCursor(330, y);
    bool periodActive = (wifiConfig.forecastSource == 1) || (wifiConfig.forecastSource == 2 && forecastConfig.yandexFormat == 0);
    if (periodActive) {
      tft.setTextColor(TFT_CYAN, TFT_BLACK);
      tft.printf("%d ч", forecastConfig.forecastHourIdx + 1);
    } else {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.print("-");
    }
  }

  // Точка активного источника
  bool isActive = false;
  if (itemIndex == FORECAST_ITEM_RF && wifiConfig.forecastSource == 0) isActive = true;
  if (itemIndex == FORECAST_ITEM_OPENMETEO && wifiConfig.forecastSource == 1) isActive = true;
  if (itemIndex == FORECAST_ITEM_YANDEX && wifiConfig.forecastSource == 2) isActive = true;

  if (isActive && !disabled) {
    tft.fillCircle(455, y + 12, 5, TFT_GREEN);
  }
}

// ===================================================================
// ИСТОЧНИК: навигация (с скроллом)
// ===================================================================
void drawForecastSourceMenuNav() {
  if (!inForecastSourceSubmenu) return;
  if (!menuChanged) return;

  // Пересчёт скролла
  if (forecastSourceSubmenuItem < forecastSourceScrollOffset) {
    forecastSourceScrollOffset = forecastSourceSubmenuItem;
  }
  if (forecastSourceSubmenuItem >= forecastSourceScrollOffset + FORECAST_SOURCE_VISIBLE_ITEMS) {
    forecastSourceScrollOffset = forecastSourceSubmenuItem - FORECAST_SOURCE_VISIBLE_ITEMS + 1;
  }
  if (FORECAST_SOURCE_ITEMS_COUNT <= FORECAST_SOURCE_VISIBLE_ITEMS) {
    forecastSourceScrollOffset = 0;
  }

  if (forecastSourceScrollOffset != lastForecastSourceScrollOffset) {
    // Скролл — все видимые + скроллбар
    tft.fillRect(0, 55, 480, FORECAST_SOURCE_VISIBLE_ITEMS * 35, TFT_BLACK);
    int maxItems = min(FORECAST_SOURCE_VISIBLE_ITEMS, FORECAST_SOURCE_ITEMS_COUNT - forecastSourceScrollOffset);
    for (int i = 0; i < maxItems; i++) {
      int itemIndex = i + forecastSourceScrollOffset;
      drawForecastSourceMenuItem(i, itemIndex == forecastSourceSubmenuItem);
    }
    // Скроллбар
    if (FORECAST_SOURCE_ITEMS_COUNT > FORECAST_SOURCE_VISIBLE_ITEMS) {
      int scrollBarY = 55;
      int stepY = 35;
      int scrollBarHeight = stepY * FORECAST_SOURCE_VISIBLE_ITEMS;
      int thumbHeight = (FORECAST_SOURCE_VISIBLE_ITEMS * scrollBarHeight) / FORECAST_SOURCE_ITEMS_COUNT;
      int thumbPos = (forecastSourceScrollOffset * scrollBarHeight) / FORECAST_SOURCE_ITEMS_COUNT;
      tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
      tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
    }
    lastForecastSourceScrollOffset = forecastSourceScrollOffset;
    lastForecastSourceItem = forecastSourceSubmenuItem;
  } else {
    // 2 строки
    if (lastForecastSourceItem >= 0 && lastForecastSourceItem != forecastSourceSubmenuItem) {
      int oldVisible = lastForecastSourceItem - forecastSourceScrollOffset;
      if (oldVisible >= 0 && oldVisible < FORECAST_SOURCE_VISIBLE_ITEMS) {
        drawForecastSourceMenuItem(oldVisible, false);
      }
    }
    int newVisible = forecastSourceSubmenuItem - forecastSourceScrollOffset;
    if (newVisible >= 0 && newVisible < FORECAST_SOURCE_VISIBLE_ITEMS) {
      drawForecastSourceMenuItem(newVisible, true);
    }
    lastForecastSourceItem = forecastSourceSubmenuItem;
  }

  menuChanged = false;
}

void drawForecastSourceMenu() {
  if (!inForecastSourceSubmenu) return;

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Источник прогноза");

  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  // ===== КОРРЕКТИРУЕМ ОФФСЕТ =====
  if (forecastSourceSubmenuItem < forecastSourceScrollOffset) {
    forecastSourceScrollOffset = forecastSourceSubmenuItem;
  }
  if (forecastSourceSubmenuItem >= forecastSourceScrollOffset + FORECAST_SOURCE_VISIBLE_ITEMS) {
    forecastSourceScrollOffset = forecastSourceSubmenuItem - FORECAST_SOURCE_VISIBLE_ITEMS + 1;
  }
  if (FORECAST_SOURCE_ITEMS_COUNT <= FORECAST_SOURCE_VISIBLE_ITEMS) {
    forecastSourceScrollOffset = 0;
  }

  int startY = 55;
  int stepY = 35;
  int maxItems = min(FORECAST_SOURCE_VISIBLE_ITEMS,
                     FORECAST_SOURCE_ITEMS_COUNT - forecastSourceScrollOffset);

  for (int i = 0; i < maxItems; i++) {
    int itemIndex = i + forecastSourceScrollOffset;
    int y = startY + i * stepY;

    // ===== АКТИВНОСТЬ ПУНКТОВ =====
    bool disabled = false;
    if (itemIndex == FORECAST_ITEM_OPENMETEO && !wifiConfig.enabled) disabled = true;
    if (itemIndex == FORECAST_ITEM_YANDEX && !wifiConfig.enabled) disabled = true;
    if (itemIndex == FORECAST_ITEM_REFRESH && !wifiConfig.enabled) disabled = true;
    if (itemIndex == FORECAST_ITEM_FORMAT && wifiConfig.forecastSource != 2) disabled = true;
    if (itemIndex == FORECAST_ITEM_PERIOD) {
      // Активен для Open-Meteo или (Яндекс + формат Часы)
      bool periodActive = (wifiConfig.forecastSource == 1) || (wifiConfig.forecastSource == 2 && forecastConfig.yandexFormat == 0);
      if (!periodActive) disabled = true;
    }

    // ===== СТРЕЛКА КУРСОРА =====
    if (itemIndex == forecastSourceSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setCursor(10, y);
      tft.print(">");
      tft.setCursor(35, y);
    } else {
      tft.setCursor(35, y);
    }

    // ===== ЦВЕТ ТЕКСТА =====
    if (disabled) {
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    } else if (itemIndex == forecastSourceSubmenuItem) {
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
    } else {
      tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
    }

    tft.print(forecastSourceItems[itemIndex]);

    // ===== ЗНАЧЕНИЕ СПРАВА =====
    if (itemIndex == FORECAST_ITEM_FORMAT) {
      tft.setCursor(330, y);
      if (wifiConfig.forecastSource == 2) {
        tft.setTextColor(TFT_CYAN, TFT_BLACK);
        tft.print(forecastConfig.yandexFormat == 0 ? "Часы" : "Сутки");
      } else {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.print("-");
      }
    } else if (itemIndex == FORECAST_ITEM_PERIOD) {
      tft.setCursor(330, y);
      bool periodActive = (wifiConfig.forecastSource == 1) || (wifiConfig.forecastSource == 2 && forecastConfig.yandexFormat == 0);
      if (periodActive) {
        tft.setTextColor(TFT_CYAN, TFT_BLACK);
        tft.printf("%d ч", forecastConfig.forecastHourIdx + 1);
      } else {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.print("-");
      }
    }

    // ===== ТОЧКА АКТИВНОГО ИСТОЧНИКА =====
    bool isActive = false;
    if (itemIndex == FORECAST_ITEM_RF && wifiConfig.forecastSource == 0) isActive = true;
    if (itemIndex == FORECAST_ITEM_OPENMETEO && wifiConfig.forecastSource == 1) isActive = true;
    if (itemIndex == FORECAST_ITEM_YANDEX && wifiConfig.forecastSource == 2) isActive = true;

    if (isActive && !disabled) {
      tft.fillCircle(455, y + 12, 5, TFT_GREEN);
    }
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (FORECAST_SOURCE_ITEMS_COUNT > FORECAST_SOURCE_VISIBLE_ITEMS) {
    int scrollBarY = 55;
    int scrollBarHeight = stepY * FORECAST_SOURCE_VISIBLE_ITEMS;
    int thumbHeight = (FORECAST_SOURCE_VISIBLE_ITEMS * scrollBarHeight) / FORECAST_SOURCE_ITEMS_COUNT;
    int thumbPos = (forecastSourceScrollOffset * scrollBarHeight) / FORECAST_SOURCE_ITEMS_COUNT;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  // ===== ПОДСКАЗКА =====
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Выбор    <> Изменить    OK");

  lastForecastSourceItem = forecastSourceSubmenuItem;
  lastForecastSourceScrollOffset = forecastSourceScrollOffset;
  menuChanged = false;
}

void handleForecastSourceMenu() {
  if (!inForecastSourceSubmenu) return;
  if (checkMenuTimeout()) return;

  int key = readKeypadWithRepeat();
  if (key == KEY_NONE) return;

  lastMenuActivity = millis();

  switch (key) {
    case KEY_UP:
      forecastSourceSubmenuItem--;
      if (forecastSourceSubmenuItem < 0)
        forecastSourceSubmenuItem = FORECAST_SOURCE_ITEMS_COUNT - 1;
      menuChanged = true;
      drawForecastSourceMenuNav();
      break;

    case KEY_DOWN:
      forecastSourceSubmenuItem++;
      if (forecastSourceSubmenuItem >= FORECAST_SOURCE_ITEMS_COUNT)
        forecastSourceSubmenuItem = 0;
      menuChanged = true;
      drawForecastSourceMenuNav();
      break;

    case KEY_LEFT:
    case KEY_RIGHT:
      // ===== ИЗМЕНЕНИЕ ЧЕРЕЗ <> =====
      if (forecastSourceSubmenuItem == FORECAST_ITEM_FORMAT) {
        if (wifiConfig.forecastSource != 2) break;
        // Переключаем Часы ↔ Сутки
        forecastConfig.yandexFormat = (forecastConfig.yandexFormat == 0) ? 1 : 0;
        saveForecastConfig();
        needFullRedraw = true;
        // Меняется disabled «Период» (4) — перерисовать всё
        drawForecastSourceMenu();
        LOG_I("📅 Формат Яндекса: %s",
              forecastConfig.yandexFormat == 0 ? "Часы" : "Сутки");
      } else if (forecastSourceSubmenuItem == FORECAST_ITEM_PERIOD) {
        bool periodActive = (wifiConfig.forecastSource == 1) || (wifiConfig.forecastSource == 2 && forecastConfig.yandexFormat == 0);
        if (!periodActive) break;
        // Меняем индекс часа
        if (key == KEY_RIGHT) {
          forecastConfig.forecastHourIdx++;
          if (forecastConfig.forecastHourIdx >= 6) forecastConfig.forecastHourIdx = 0;
        } else {
          if (forecastConfig.forecastHourIdx == 0)
            forecastConfig.forecastHourIdx = 5;
          else
            forecastConfig.forecastHourIdx--;
        }
        saveForecastConfig();
        needFullRedraw = true;
        // Меняется только значение справа — перерисовать ТОЛЬКО строку 4
        {
          int visibleIndex = forecastSourceSubmenuItem - forecastSourceScrollOffset;
          if (visibleIndex >= 0 && visibleIndex < FORECAST_SOURCE_VISIBLE_ITEMS) {
            drawForecastSourceMenuItem(visibleIndex, true);
          }
        }
        LOG_I("⏱ Период прогноза: через %d ч",
              forecastConfig.forecastHourIdx + 1);
      }
      break;

    case KEY_OK:
      // ===== ВЫБОР ИСТОЧНИКА =====
      if (forecastSourceSubmenuItem == FORECAST_ITEM_RF) {
        if (wifiConfig.forecastSource != 0) {
          wifiConfig.forecastSource = 0;
          saveWiFiConfig();
          needFullRedraw = true;
          LOG_I("📡 Источник: Свой (RF)");
        }
        drawForecastSourceMenu();
        break;
      }

      if (forecastSourceSubmenuItem == FORECAST_ITEM_OPENMETEO) {
        if (!wifiConfig.enabled) {
          showWiFiDisabledHint();
          break;
        }
        if (wifiConfig.forecastSource != 1) {
          wifiConfig.forecastSource = 1;
          saveWiFiConfig();
          openMeteoIconsDrawn = false;
          openMeteoFirstUpdate = true;
          lastWiFiSessionTime = 0;  // запросить сразу
          needFullRedraw = true;
          LOG_I("🌐 Источник: Open-Meteo");
        }
        drawForecastSourceMenu();
        break;
      }

      if (forecastSourceSubmenuItem == FORECAST_ITEM_YANDEX) {
        if (!wifiConfig.enabled) {
          showWiFiDisabledHint();
          break;
        }
        if (strlen(wifiConfig.yandexApiKey) == 0) {
          // Ключ не задан — подсказка
          tft.fillScreen(TFT_BLACK);
          tft.setTextColor(TFT_YELLOW, TFT_BLACK);
          tft.setTextSize(2);
          tft.setCursor(10, 10);
          tft.print("Нет API-ключа");
          tft.setTextColor(TFT_WHITE, TFT_BLACK);
          tft.setTextSize(1);
          tft.setCursor(10, 60);
          tft.print("Задайте ключ в:");
          tft.setCursor(10, 80);
          tft.print("Меню -> Wi-Fi -> Настроить Wi-Fi");
          delay(2500);
          drawForecastSourceMenu();
          break;
        }
        if (wifiConfig.forecastSource != 2) {
          wifiConfig.forecastSource = 2;
          saveWiFiConfig();
          yandexIconsDrawn = false;
          yandexFirstUpdate = true;
          lastWiFiSessionTime = 0;  // запросить сразу
          needFullRedraw = true;
          LOG_I("🌍 Источник: Яндекс");
        }
        drawForecastSourceMenu();
        break;
      }

      if (forecastSourceSubmenuItem == FORECAST_ITEM_REFRESH) {
        if (!wifiConfig.enabled) {
          showWiFiDisabledHint();
          break;
        }
        confirmAndRefreshForecast();
        inForecastSourceSubmenu = true;
        drawForecastSourceMenu();
        break;
      }

      if (forecastSourceSubmenuItem == FORECAST_ITEM_BACK) {
        inForecastSourceSubmenu = false;
        menuChanged = true;
        drawMenu();
        LOG_I("↩️ Выход из Источника прогноза");
        break;
      }
      break;
  }
}

// ===================================================================
// ОБЩИЙ ДИАЛОГ ПОДТВЕРЖДЕНИЯ
// ===================================================================
// Возвращает true, если пользователь выбрал «Да».
// KEY_LEFT / KEY_RIGHT — переключение кнопок.
// KEY_OK — подтвердить выбор.
// Таймаут (MENU_TIMEOUT) — выход из диалога (возврат false).
// ===================================================================
bool showConfirmDialog(const char* title, const char* line1, const char* line2) {
  int choice = 0;  // 0 = Нет, 1 = Да
  int lastChoice = -1;

  while (true) {
    if (checkMenuTimeout()) return false;

    if (choice != lastChoice) {
      lastChoice = choice;

      tft.fillScreen(TFT_BLACK);

      // ===== ЗАГОЛОВОК =====
      tft.setTextColor(TFT_YELLOW, TFT_BLACK);
      tft.setTextSize(2);
      tft.setCursor(10, 10);
      tft.print(title);

      tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

      // ===== ТЕКСТ =====
      tft.setTextColor(TFT_WHITE, TFT_BLACK);
      tft.setTextSize(2);
      tft.setCursor(50, 100);
      tft.print(line1);
      tft.setCursor(50, 130);
      tft.print(line2);

      // ===== КНОПКИ =====
      int btnY = 220;

      // Кнопка "Нет"
      if (choice == 0) {
        tft.setTextColor(TFT_WHITE, TFT_BLUE);
        tft.fillRect(100, btnY, 100, 35, TFT_BLUE);
      } else {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.fillRect(100, btnY, 100, 35, TFT_BLACK);
      }
      tft.drawRect(100, btnY, 100, 35, TFT_WHITE);
      tft.setCursor(140, btnY + 7);
      tft.print("Нет");

      // Кнопка "Да"
      if (choice == 1) {
        tft.setTextColor(TFT_WHITE, TFT_RED);
        tft.fillRect(280, btnY, 100, 35, TFT_RED);
      } else {
        tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
        tft.fillRect(280, btnY, 100, 35, TFT_BLACK);
      }
      tft.drawRect(280, btnY, 100, 35, TFT_WHITE);
      tft.setCursor(320, btnY + 7);
      tft.print("Да");

      // ===== ПОДСКАЗКА =====
      tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
      tft.setTextSize(2);
      tft.setCursor(10, 300);
      tft.print("<> Выбор    OK - подтвердить");
    }

    int key = readKeypadWithRepeat();
    if (key != KEY_NONE) {
      lastMenuActivity = millis();
      switch (key) {
        case KEY_LEFT: choice = 0; break;
        case KEY_RIGHT: choice = 1; break;
        case KEY_OK: return (choice == 1);
      }
    }
    delay(50);
  }
}

// ===================================================================
// ЭКРАН ДИАГНОСТИКИ СЕАНСА
// ===================================================================
void drawSessionDiagnostics() {
  tft.fillScreen(TFT_BLACK);

  // ===== ШАПКА =====
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.print("Диагностика сеанса");
  tft.drawLine(10, 40, 470, 40, TFT_DARKGREY);

  if (!lastSession.valid) {
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.setCursor(10, 70);
    tft.print("Сеансов не было");
    tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
    tft.setCursor(10, 300);
    tft.print("OK - выход");
    return;
  }

  // ===== ГОТОВИМ СТРОКИ =====
  const int MAX_LINES = 16;
  char lines[MAX_LINES][48];
  uint16_t colors[MAX_LINES];
  int n = 0;

  // 1. Unix-время
  snprintf(lines[n], 48, "Unix: %lu", (unsigned long)lastSession.unixTime);
  colors[n++] = TFT_WHITE;

  // 2. Источник
  {
    const char* srcName = "RF";
    if (lastSession.source == 1) srcName = "Open-Meteo";
    else if (lastSession.source == 2) srcName = "Яндекс";
    snprintf(lines[n], 48, "Источник: %s", srcName);
    colors[n++] = TFT_WHITE;
  }

  // 3. HTTP-код
  snprintf(lines[n], 48, "HTTP: %d", lastSession.httpCode);
  colors[n++] = lastSession.success ? TFT_GREEN : TFT_RED;

  // 4. Байты
  snprintf(lines[n], 48, "Байт: %d", lastSession.bytesRead);
  colors[n++] = TFT_WHITE;

  // 5. RAM-заголовок
  snprintf(lines[n], 48, "RAM (heap):");
  colors[n++] = TFT_CYAN;

  // 6. RAM-значения
  snprintf(lines[n], 48, "%d -> %d", lastSession.ramBefore, lastSession.ramAfter);
  colors[n++] = TFT_WHITE;

  // 7. Delta
  {
    int ramDiff = lastSession.ramAfter - lastSession.ramBefore;
    snprintf(lines[n], 48, "Delta: %d", ramDiff);
    if (ramDiff < 0) colors[n] = TFT_RED;
    else if (ramDiff > 0) colors[n] = TFT_GREEN;
    else colors[n] = TFT_DARKGREY;
    n++;
  }

  // 8. Block
  snprintf(lines[n], 48, "Block: %d -> %d",
           lastSession.largestBlockBefore, lastSession.largestBlockAfter);
  colors[n++] = TFT_WHITE;

  // ===== НОВОЕ: исторические минимумы =====
  snprintf(lines[n], 48, "Min RAM: %d b", lastSession.minRamEver);
  colors[n++] = (lastSession.minRamEver < 50000) ? TFT_RED : TFT_YELLOW;

  snprintf(lines[n], 48, "Min Block: %d b", lastSession.minBlockEver);
  colors[n++] = (lastSession.minBlockEver < 20000) ? TFT_RED : TFT_YELLOW;

  // 9. Ошибка (если есть)
  if (strlen(lastSession.error) > 0) {
    snprintf(lines[n], 48, "! %s", lastSession.error);
    colors[n++] = TFT_RED;
  }

  // 10. Пустая строка для красоты
  lines[n][0] = '\0';
  colors[n++] = TFT_WHITE;

  // 11. Доп. инфо (можно дополнять)
  snprintf(lines[n], 48, "Free heap now:");
  colors[n++] = TFT_CYAN;
  snprintf(lines[n], 48, "%lu bytes", (unsigned long)ESP.getFreeHeap());
  colors[n++] = TFT_WHITE;

  // ===== КОРРЕКТИРУЕМ ОФФСЕТ =====
  int maxOffset = n - SESSION_VISIBLE_LINES;
  if (maxOffset < 0) maxOffset = 0;
  if (sessionScrollOffset > maxOffset) sessionScrollOffset = maxOffset;
  if (sessionScrollOffset < 0) sessionScrollOffset = 0;

  // ===== РИСУЕМ ВИДИМЫЕ СТРОКИ =====
  int startY = 55;
  for (int i = 0; i < SESSION_VISIBLE_LINES; i++) {
    int idx = i + sessionScrollOffset;
    if (idx >= n) break;

    int y = startY + i * SESSION_LINE_HEIGHT;
    tft.setTextColor(colors[idx], TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(10, y);
    tft.print(lines[idx]);
  }

  // ===== ИНДИКАТОР ПРОКРУТКИ =====
  if (n > SESSION_VISIBLE_LINES) {
    int scrollBarY = 55;
    int scrollBarHeight = SESSION_VISIBLE_LINES * SESSION_LINE_HEIGHT;
    int thumbHeight = (SESSION_VISIBLE_LINES * scrollBarHeight) / n;
    int thumbPos = (sessionScrollOffset * scrollBarHeight) / n;
    tft.fillRect(470, scrollBarY, 5, scrollBarHeight, TFT_DARKGREY);
    tft.fillRect(470, scrollBarY + thumbPos, 5, thumbHeight, TFT_WHITE);
  }

  // ===== ПОДСКАЗКА =====
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  drawUpDownArrows(20, 306, 6, TFT_DARKGREY);
  tft.setTextSize(2);
  tft.setCursor(50, 300);
  tft.print("Прокрутка    OK - выход");
}

// Рисуем две стрелки рядом по горизонтали
void drawUpDownArrows(int x, int y, int size, uint16_t color) {
  // Стрелка вверх (треугольник острием вверх)
  tft.fillTriangle(x - size, y + size,
                   x + size, y + size,
                   x, y - size, color);

  // Стрелка вниз (треугольник острием вниз, правее)
  int offset = size * 2 + 4;  // Отступ между стрелками
  tft.fillTriangle(x + offset - size, y - size,
                   x + offset + size, y - size,
                   x + offset, y + size, color);
}