// keypad_module.cpp
#include "keypad_module.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

// ==================== ОСНОВНЫЕ ФУНКЦИИ ====================

int readKeypad() {
  int value = analogRead(KEYPAD_PIN);

#ifdef KEYPAD_DEBUG
  static int lastValue = -1;
  if (abs(value - lastValue) > 10) {
    HWSerial.printf("📊 ADC: %4d\n", value);
    lastValue = value;
  }
#endif

  if (value >= BTN_UP_MIN && value <= BTN_UP_MAX) return KEY_UP;
  if (value >= BTN_RIGHT_MIN && value <= BTN_RIGHT_MAX) return KEY_RIGHT;
  if (value >= BTN_LEFT_MIN && value <= BTN_LEFT_MAX) return KEY_LEFT;
  if (value >= BTN_DOWN_MIN && value <= BTN_DOWN_MAX) return KEY_DOWN;
  if (value >= BTN_OK_MIN && value <= BTN_OK_MAX) return KEY_OK;

  return KEY_NONE;
}

void waitKeyRelease() {
  while (readKeypad() != KEY_NONE) {
    delay(10);
  }
  delay(DEBOUNCE_DELAY);
}

bool isKeyPressed(int expectedKey) {
  int key = readKeypad();
  if (key == expectedKey) {
    delay(DEBOUNCE_DELAY);
    if (readKeypad() == expectedKey) {
#ifdef KEYPAD_DEBUG
      HWSerial.printf("✅ Кнопка %d подтверждена\n", expectedKey);
#endif
      return true;
    }
  }
  return false;
}

int waitForKey(unsigned long timeout) {
  unsigned long start = millis();
  int key = KEY_NONE;

#ifdef KEYPAD_DEBUG
  HWSerial.println("⏳ Ожидание нажатия кнопки...");
#endif

  while (millis() - start < timeout) {
    key = readKeypad();
    if (key != KEY_NONE) {
      delay(DEBOUNCE_DELAY);
      if (readKeypad() == key) {
#ifdef KEYPAD_DEBUG
        HWSerial.printf("🔴 Нажата кнопка: %d (ADC: %d)\n", key, analogRead(KEYPAD_PIN));
#endif
        waitKeyRelease();
        return key;
      }
    }
    delay(10);
  }

#ifdef KEYPAD_DEBUG
  HWSerial.println("⏰ Таймаут ожидания");
#endif

  return KEY_NONE;
}

// ==================== АВТОПОВТОР ====================

int readKeypadWithRepeat() {
  static int lastKey = KEY_NONE;
  static unsigned long lastPressTime = 0;
  static bool isRepeating = false;

  int currentKey = readKeypad();
  unsigned long now = millis();

  // Если кнопка отпущена — сбрасываем состояние
  if (currentKey == KEY_NONE) {
    lastKey = KEY_NONE;
    isRepeating = false;
    return KEY_NONE;
  }

  // Новая кнопка — сразу возвращаем
  if (currentKey != lastKey) {
    lastKey = currentKey;
    lastPressTime = now;
    isRepeating = false;
#ifdef KEYPAD_DEBUG
    HWSerial.printf("🆕 Новая кнопка: %d\n", currentKey);
#endif
    return currentKey;
  }

  // Та же кнопка — проверяем автоповтор
  if (currentKey == lastKey) {
    unsigned long elapsed = now - lastPressTime;

    // Первый повтор после задержки
    if (!isRepeating && elapsed >= REPEAT_DELAY) {
      isRepeating = true;
      lastPressTime = now;
#ifdef KEYPAD_DEBUG
      HWSerial.printf("🔁 Повтор: %d\n", currentKey);
#endif
      return currentKey;
    }

    // Последующие повторы
    if (isRepeating && elapsed >= REPEAT_INTERVAL) {
      lastPressTime = now;
#ifdef KEYPAD_DEBUG
      HWSerial.printf("🔁 Повтор: %d\n", currentKey);
#endif
      return currentKey;
    }
  }

  return KEY_NONE;
}

// ==================== ОТЛАДОЧНЫЕ ФУНКЦИИ ====================

#ifdef KEYPAD_DEBUG

void printKeypadDebug() {
  int value = analogRead(KEYPAD_PIN);
  int key = readKeypad();

  HWSerial.print("ADC: ");
  HWSerial.print(value);
  HWSerial.print("  |  Кнопка: ");

  switch (key) {
    case KEY_UP: HWSerial.println("ВВЕРХ"); break;
    case KEY_DOWN: HWSerial.println("ВНИЗ"); break;
    case KEY_LEFT: HWSerial.println("ВЛЕВО"); break;
    case KEY_RIGHT: HWSerial.println("ВПРАВО"); break;
    case KEY_OK: HWSerial.println("OK"); break;
    default: HWSerial.println("НЕТ НАЖАТИЯ"); break;
  }
}

void printKeypadValue() {
  int value = analogRead(KEYPAD_PIN);
  HWSerial.printf("ADC: %4d\n", value);
}

#endif