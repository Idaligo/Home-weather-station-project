#include <LittleFS.h>
#include "rtc_module.h"
#include "logger.h"

#if ARDUINO_USB_CDC_ON_BOOT
#define HWSerial Serial0
#else
#define HWSerial Serial
#endif

RTCModule::RTCModule() {
  isFirstDraw = true;
  lastDow = -1;
  lastDateDay = -1;
  lastDateMonth = -1;
  lastDateYear = -1;
  frameDrawn = false;
  lastHours[0] = '\0';
  lastMinutes[0] = '\0';
  colonDrawn = false;
  _wire = &Wire;
}

bool RTCModule::isRunning() {
  return !rtc.lostPower();
}

void RTCModule::begin(TwoWire& wire, uint8_t addr, int sda, int scl) {
  _wire = &wire;
  _wire->begin(sda, scl);

  if (!rtc.begin(_wire)) {
    LOG_E("RTC not found!");
  }
  //delay(250);
  lastUpdate = millis();
  isFirstDraw = true;
}

void RTCModule::begin(uint8_t addr, int sda, int scl) {
  begin(Wire, addr, sda, scl);
}

void RTCModule::forceUpdate() {
  // Сброс кэша отрисовки (чтобы draw() перерисовал всё)
  isFirstDraw = true;
  lastDow = -1;
  lastDateDay = -1;
  lastDateMonth = -1;
  lastDateYear = -1;
  frameDrawn = false;
  lastHours[0] = '\0';
  lastMinutes[0] = '\0';
  colonDrawn = false;
  lastUpdate = 0;

  // Принудительное чтение из RTC — иначе getTime() вернёт старое now
  // (2000-01-01 при старте), и restore* посчитают RTC невалидным.
  now = rtc.now();
}

void RTCModule::setDateTime(DateTime dt) {
  rtc.adjust(dt);
  now = rtc.now();
}

void RTCModule::update() {
  now = rtc.now();
}

const DateTime& RTCModule::getTime() const {
  return now;
}

// ==================== draw() ====================
void RTCModule::draw(TFT_eSPI& tft) {
  const int FRAME_THICKNESS = 1;
  const int FRAME_COLOR = TFT_WHITE;
  const int Y_POSTime = 0;
  const int TIMEFrame_X = 90;
  const int RIGHT_BORDER = 390;
  const int BLOCK_HEIGHT = 30;

  const int Y_POS = 2;
  const int TIME_X = 100;
  const int DOW_X = 200;
  const int DATE_X = 250;
  const int COLON_PADDING = 8;

  // ===== 1. ГОТОВИМ БУФЕРЫ ЗНАЧЕНИЙ =====
  char hoursBuf[3], minutesBuf[3];
  snprintf(hoursBuf, sizeof(hoursBuf), "%02d", now.hour());
  snprintf(minutesBuf, sizeof(minutesBuf), "%02d", now.minute());

  char dowBuf[8];
  getDayOfWeekString(dowBuf);

  char dateBuf[15];
  snprintf(dateBuf, sizeof(dateBuf), "%02d.%02d.%04d", now.day(), now.month(), now.year());

  // ===== 2. ПРОВЕРЯЕМ, ЧТО РЕАЛЬНО ИЗМЕНИЛОСЬ =====
  bool needFrame = (!frameDrawn || isFirstDraw);
  bool hoursChanged = (strcmp(hoursBuf, lastHours) != 0);
  bool minutesChanged = (strcmp(minutesBuf, lastMinutes) != 0);
  bool dowChanged = (now.dayOfTheWeek() != lastDow);
  bool dateChanged = (now.day() != lastDateDay || now.month() != lastDateMonth || now.year() != lastDateYear);

  // Мигание двоеточия ОТКЛЮЧЕНО — рисуем один раз
  bool colonNeedsDraw = (!colonDrawn || isFirstDraw);
  /*
// ===== ОТЛАДКА =====
    HWSerial.printf("DOW='%s'(len=%d) DATE='%s'(len=%d) dowCh=%d dateCh=%d first=%d\n",
                    dowBuf, (int)strlen(dowBuf),
                    dateBuf, (int)strlen(dateBuf),
                    (int)dowChanged, (int)dateChanged, (int)isFirstDraw);
*/
  // ===== 3. ЕСЛИ НИЧЕГО НЕ ИЗМЕНИЛОСЬ — ВЫХОДИМ СРАЗУ =====
  // (без loadFont/unloadFont, без отрисовки)
  if (!needFrame && !hoursChanged && !minutesChanged && !dowChanged && !dateChanged && !colonNeedsDraw) {
    isFirstDraw = false;
    return;
  }

  // ===== 4. ЕСТЬ ЧТО РИСОВАТЬ — ГРУЗИМ ШРИФТ =====
  tft.loadFont("cambriai28", LittleFS);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);

  // ===== 5. РАМКА =====
  if (needFrame) {
    tft.fillRect(TIMEFrame_X, Y_POSTime, FRAME_THICKNESS, BLOCK_HEIGHT, FRAME_COLOR);
    tft.fillRect(RIGHT_BORDER, Y_POSTime, FRAME_THICKNESS, BLOCK_HEIGHT, FRAME_COLOR);
    int bottomWidth = RIGHT_BORDER - TIMEFrame_X;
    tft.fillRect(TIMEFrame_X, Y_POSTime + BLOCK_HEIGHT - FRAME_THICKNESS, bottomWidth, FRAME_THICKNESS, FRAME_COLOR);
    frameDrawn = true;
  }

  // ===== 6. ЧАСЫ =====
  if (hoursChanged || isFirstDraw) {
    int width = tft.textWidth("00") + 8;
    tft.fillRect(TIME_X, Y_POS - 1, width, 27, TFT_BLACK);
    tft.setCursor(TIME_X, Y_POS);
    tft.print(hoursBuf);
    strncpy(lastHours, hoursBuf, sizeof(lastHours) - 1);
    lastHours[sizeof(lastHours) - 1] = '\0';
  }

  // ===== 7. ДВОЕТОЧИЕ (статичное) =====
  int colonX = TIME_X + tft.textWidth(lastHours) + COLON_PADDING;
  if (colonNeedsDraw) {
    tft.fillRect(colonX - 1, Y_POS, 15, 26, TFT_BLACK);
    tft.setCursor(colonX, Y_POS);
    tft.print(":");
    colonDrawn = true;
  }

  // ===== 8. МИНУТЫ =====
  int minutesStartX = colonX + 15;
  if (minutesChanged || isFirstDraw) {
    int width = tft.textWidth("00") + 5;
    tft.fillRect(minutesStartX - 1, Y_POS - 1, width, 27, TFT_BLACK);
    tft.setCursor(minutesStartX, Y_POS);
    tft.print(minutesBuf);
    strncpy(lastMinutes, minutesBuf, sizeof(lastMinutes) - 1);
    lastMinutes[sizeof(lastMinutes) - 1] = '\0';
  }

  // ===== 9. ДЕНЬ НЕДЕЛИ =====
  if (dowChanged || isFirstDraw) {
    int maxDowWidth = max(tft.textWidth("Ср"), tft.textWidth("Пт"));
    int clearWidth = maxDowWidth + 15;
    tft.fillRect(DOW_X, Y_POS - 1, clearWidth, 27, TFT_BLACK);
    tft.setCursor(DOW_X, Y_POS);
    tft.print(dowBuf);
    lastDow = now.dayOfTheWeek();
  }

  // ===== 10. ДАТА =====
  if (dateChanged || isFirstDraw) {
    int dateWidth = tft.textWidth("31.12.2099") + 6;
    tft.fillRect(DATE_X, Y_POS - 1, dateWidth, 27, TFT_BLACK);
    tft.setCursor(DATE_X, Y_POS);
    tft.print(dateBuf);
    lastDateDay = now.day();
    lastDateMonth = now.month();
    lastDateYear = now.year();
  }

  // ===== 11. ВЫГРУЖАЕМ ШРИФТ =====
  tft.unloadFont();

  isFirstDraw = false;
}

void RTCModule::getDayOfWeekString(char* buffer) {
  switch (now.dayOfTheWeek()) {
    case 1: strcpy(buffer, "Пн"); break;
    case 2: strcpy(buffer, "Вт"); break;
    case 3: strcpy(buffer, "Ср"); break;
    case 4: strcpy(buffer, "Чт"); break;
    case 5: strcpy(buffer, "Пт"); break;
    case 6: strcpy(buffer, "Сб"); break;
    default: strcpy(buffer, "Вс"); break;
  }
}