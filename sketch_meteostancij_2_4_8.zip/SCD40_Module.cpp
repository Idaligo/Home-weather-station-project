#include <LittleFS.h>
#include "SCD40_Module.h"

extern uint16_t interpolateColor(uint16_t, uint16_t, float);

// Определение статической константы класса
const char SCD40Module::UNIT_LABEL[] = "ppm";

// ==================== КОНСТРУКТОР ====================
SCD40Module::SCD40Module(TFT_eSPI& tft_ref)
  : tft(tft_ref),
    spriteCO2(&tft_ref) {
  isNewDataAvailable = false;
  filterIndex = 0;
  spritesInitialized = false;
  isFirstDraw = true;
  lastDisplayedValue = 0;
  lastDrawTime = 0;

  // Инициализируем массив фильтра значением "чистого воздуха"
  for (int i = 0; i < 5; i++) {
    co2Values[i] = 400;
  }
}

// ==================== ИНИЦИАЛИЗАЦИЯ СПРАЙТОВ ====================
void SCD40Module::initSprites() {
  if (spritesInitialized) return;

  // Вычисляем максимальную ширину текста для CO2 (0-5000)
  tft.loadFont("cambriai48", LittleFS);
  String maxStr = "5000";
  int textWidth = tft.textWidth(maxStr);
  tft.unloadFont();

  // Создаём спрайт для цифр CO2
  spriteCO2.setColorDepth(16);
  spriteCO2.createSprite(textWidth + 9, 38);
  spriteCO2.setSwapBytes(true);
  spriteCO2.loadFont("cambriai48");

  spritesInitialized = true;
}

// ==================== РИСОВАНИЕ ЦИФР В СПРАЙТЕ ====================
void SCD40Module::drawNumber() {
  uint16_t avgValue = calculateAverage();

  char newStr[8];
  snprintf(newStr, sizeof(newStr), "%u", avgValue);

  // Проверяем, изменилось ли значение
  if (!isFirstDraw && strcmp(newStr, lastDrawnStr) == 0 && avgValue == lastDisplayedValue) {
    return;
  }

  uint16_t textColor = getCO2Color(avgValue);

  // Рисуем в спрайте
  spriteCO2.fillSprite(TFT_BLACK);
  spriteCO2.setTextColor(textColor, TFT_BLACK);
  spriteCO2.setCursor(0, 0);
  spriteCO2.print(newStr);

  // Выводим на экран
  spriteCO2.pushSprite(CO2_X, CO2_Y);

  strncpy(lastDrawnStr, newStr, sizeof(lastDrawnStr) - 1);
  lastDrawnStr[sizeof(lastDrawnStr) - 1] = '\0';
  lastDisplayedValue = avgValue;
}

// ==================== РИСОВАНИЕ ЕДИНИЦ (стандартным шрифтом) ====================
void SCD40Module::drawUnit() {
  uint16_t avgValue = calculateAverage();
  uint16_t textColor = getCO2Color(avgValue);

  // Очищаем область под единицы
  tft.fillRect(UNIT_X - 2, UNIT_Y - 2, 45, 22, TFT_BLACK);

  // Рисуем единицы
  tft.setTextSize(2);
  tft.setTextColor(textColor, TFT_BLACK);
  tft.setCursor(UNIT_X, UNIT_Y);
  tft.print(UNIT_LABEL);
}

// ==================== ОСНОВНОЙ DRAW (с ограничением 1 раз в минуту) ====================
void SCD40Module::draw() {
  // Проверяем, есть ли новые данные
  if (!isNewDataAvailable && !isFirstDraw) {
    return;
  }

  // Ограничиваем частоту обновления (раз в минуту)
  unsigned long now = millis();
  if (!isFirstDraw && (now - lastDrawTime) < DRAW_INTERVAL) {
    isNewDataAvailable = false;  // Сбрасываем флаг, но не рисуем
    return;
  }

  // Инициализируем спрайты при первом вызове
  initSprites();

  // Рисуем обновлённые данные
  drawNumber();
  drawUnit();

  // Обновляем таймер и сбрасываем флаги
  lastDrawTime = now;
  isNewDataAvailable = false;
  isFirstDraw = false;
}

// ==================== ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ ====================
void SCD40Module::forceUpdate() {
  isFirstDraw = true;
  lastDrawnStr[0] = '\0';
  lastDisplayedValue = 0;
  lastDrawTime = 0;
}

// ==================== ЗАПРОС ИЗМЕРЕНИЯ ====================
void SCD40Module::requestMeasurement(SCD4x& sensor) {
  if (sensor.readMeasurement()) {
    uint16_t rawCo2 = sensor.getCO2();
    if (rawCo2 >= 400 && rawCo2 <= 5000) {
      addSample(rawCo2);
      isNewDataAvailable = true;
    }
  }
}

// ==================== ЦВЕТ ДЛЯ CO2 (градиент) ====================
uint16_t SCD40Module::getCO2Color(uint16_t co2) {
  const uint16_t SAFE_MAX = 800;
  const uint16_t WARNING_MAX = 1200;

  if (co2 <= SAFE_MAX) {
    return TFT_GREEN;
  }
  if (co2 >= WARNING_MAX) {
    return TFT_RED;
  }

  float range = WARNING_MAX - SAFE_MAX;
  float posInRange = (co2 - SAFE_MAX) / range;

  return interpolateColor(TFT_GREEN, TFT_ORANGE, posInRange);
}

// ==================== ФИЛЬТРАЦИЯ ====================
uint16_t SCD40Module::calculateAverage() {
  uint32_t sum = 0;
  for (int i = 0; i < 5; i++) {
    sum += co2Values[i];
  }
  return sum / 5;
}

void SCD40Module::addSample(uint16_t sample) {
  co2Values[filterIndex++] = sample;
  if (filterIndex >= 5) {
    filterIndex = 0;
  }
}