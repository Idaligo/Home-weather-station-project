// sd_module.h
#ifndef SD_MODULE_H
#define SD_MODULE_H

#include <Arduino.h>
#include <SD.h>
#include <FS.h>

// ==================== ПИНЫ SD (VSPI, отдельно от TFT/nRF) ====================
#define SD_SCK 39
#define SD_MISO 41
#define SD_MOSI 40
#define SD_CS 6

// ==================== СОСТОЯНИЕ ====================
extern bool sdReady;
extern bool sdSafeToRemove;
extern bool sdLoggingEnabled;  // Вкл/Выкл логирование (сохраняется в EEPROM)

// ==================== БУФЕР СЫРЫХ ДАННЫХ ====================
#define SD_BUFFER_SIZE 50

struct RawData {
  uint32_t unixTime;  // unix-время (RTC)
  float temp;
  float hum;
  float pres;
};

// ==================== ФУНКЦИИ ====================
bool initSD(bool isSilent = false);
bool testSD();
bool checkSD();
void deinitSD();

// Загрузка/сохранение настройки логирования (EEPROM 500)
void loadSdConfig();
void saveSdConfig();

// ==================== ВОССТАНОВЛЕНИЕ ПРИ СТАРТЕ ====================
void restoreCurrentHour();
void restoreDailyStats();

// ==================== ЛОГИРОВАНИЕ ====================
void saveRawData(float temp, float hum, float pres);  // в RAM-буфер (калиброванные)
void flushBufferToSD();
void saveHourlyArchive(uint32_t unixTime, float temp, float hum, float pres);
void clearRawHourly();  // Очистка сырых данных в начале нового часа
void saveDailyArchive(uint32_t unixTime,
                      float tempAvg, float tempMin, float tempMax,
                      float humAvg, float humMin, float humMax,
                      float presAvg, float presMin, float presMax, int count);
void writeLog(uint32_t unixTime, float temp, float hum, float pres);

// ==================== СРАВНЕНИЕ (вчера в тот же час) ====================
// Возвращает true, если найдена запись за вчера в указанный час
bool loadHourlyForCompare(uint8_t hour, float* t, float* h, float* p);

// ==================== ВСПОМОГАТЕЛЬНЫЕ ====================
void getArchiveFileName(char* buf, size_t bufSize, const char* type, int year, int month);
void getLogFileName(char* buf, size_t bufSize, int year, int month);
int getBufferCount();

// ===================================================================
// УТИЛИТА: чтение файла с конца блоками
// ===================================================================
// Читает файл с конца блоками по blockSize, разбивает на строки
// и вызывает callback для каждой строки в порядке от конца к началу.
// Callback возвращает true, если нужно прекратить чтение.
// Возвращает true, если чтение было прервано callback'ом.
bool readFileBackwards(File& f, bool (*callback)(const char* line, void* ctx),
                       void* ctx, size_t blockSize = 256);

#endif  // SD_MODULE_H