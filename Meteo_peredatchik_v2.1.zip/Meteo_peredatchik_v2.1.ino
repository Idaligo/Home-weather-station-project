// ===================================================================
// ПЕРЕДАТЧИК ESP32-S3 МЕТЕОСТАНЦИИ (ATMega328P + nRF24L01 + BME280)
// Версия: 2.1 (bi-color LED, кнопка отладки, отладочный режим)
// База: v2.0 (проверенная, рабочая)
// ===================================================================
/*
D2  ──[ 470 Ом ]──▶ Анод 1 (красный)
D3  ──[ 470 Ом ]──▶ Анод 2 (зелёный)
GND ───────────────▶ Общий катод
D4  ──── Кнопка ────▶ GND (внутренний pull-up)
D7  ──── BME_POWER_PIN
D9  ──── nRF24 CE
D10 ──── nRF24 CSN
D11 ──── nRF24 MOSI
D12 ──── nRF24 MISO
D13 ──── nRF24 SCK
A1  ──── Батарея (делитель)
A4  ──── BME280 SDA
A5  ──── BME280 SCL
Команды
d	- Вкл/выкл подробные логи
q	- Выход из отладочного режима
r	- Reset (программный)
i	- Вывести текущие данные
tN - Изменить интервал эмуляции сна. Например t5 — цикл каждые 5 сек, вместо 60
*/
#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
#include <Adafruit_BME280.h>
#include <LowPower.h>

// ==================== НАСТРОЙКИ ПИНОВ ====================
const int BME_POWER_PIN = 7;
const int LED_RED_PIN   = 2;   // анод красного (через 470 Ом)
const int LED_GREEN_PIN = 3;   // анод зелёного (через 470 Ом)
const int BUTTON_PIN    = 4;   // кнопка (на GND, внутренний pull-up)

// ==================== НАСТРОЙКИ ВРЕМЕНИ ====================
const unsigned long PRE_POWER_DELAY = 150;
const unsigned long SLEEP_INTERVAL_MS = 60000;   // 60 сек
const unsigned long RADIO_STABILIZE_DELAY = 10;

// ==================== НАСТРОЙКИ БАТАРЕИ ====================
const int BATTERY_PIN = A1;
const float V_REF = 5.0;
const float R1 = 100000.0;
const float R2 = 100000.0;
const float CALIBRATION_FACTOR = 1.0;
const float DIVIDER_RATIO = (R1 + R2) / R2;
const float ADC_STEP = V_REF / 1024.0;
const float BATTERY_MIN_VALID = 4.0;
const float BATTERY_MAX_VALID = 10.0;

// ==================== ГЛОБАЛЬНЫЕ ====================
bool adcEnabled = true;
bool debugMode = false;          // отладочный режим (не спим)
bool debugVerbose = false;       // подробные логи (команда 'd')
unsigned long sleepIntervalMs = SLEEP_INTERVAL_MS;
unsigned long packetsSent = 0;
unsigned long packetsFailed = 0;
unsigned long cycleCount = 0;

// ==================== СВЕТОДИОД (bi-color, общий катод) ====================
void ledRed(bool on)   { digitalWrite(LED_RED_PIN,   on ? HIGH : LOW); }
void ledGreen(bool on) { digitalWrite(LED_GREEN_PIN, on ? HIGH : LOW); }
void ledOff() { ledRed(false); ledGreen(false); }

void ledFlashColor(bool red, bool green, int duration, int count) {
  for (int i = 0; i < count; i++) {
    ledRed(red); ledGreen(green);
    delay(duration);
    ledOff();
    delay(duration);
  }
}

// ==================== ОБЪЕКТЫ ====================
RF24 radio(9, 10);
Adafruit_BME280 bme;
const uint64_t pipe = 0x1234567890LL;

struct DataStruct {
  float temperature;
  float humidity;
  float pressure;
  float battery_voltage;
} data;

// ==================== ПРОТОТИПЫ ====================
float readBatteryVoltage();
void enableADC();
void disableADC();
void enableRadio();
void disableRadio();
void enterDeepSleep(unsigned long sleepDurationMs);
void logHeader();
void logRadioInit();
void logData();
void logSend(bool sent);
void logSummary();
void printHelp();
void handleSerialCommands();
bool doMeasurementAndSend();

// ==================== ЛОГИ ====================
void logHeader() {
  if (!debugMode) return;
  Serial.println(F("=== SYSTEM START (FW v2.1 debug) ==="));
  Serial.println(F("[I] Serial: 9600"));
  Serial.println(F("[I] BME_POWER_PIN (D7): OUTPUT, LOW"));
  Serial.println(F("[I] LED: D2 (red), D3 (green), общий катод"));
  Serial.println(F("[I] BUTTON: D4 (pull-up, нажат = debug)"));
  Serial.println(F("[I] ADC: enabled"));
}

void logRadioInit() {
  if (!debugMode) return;
  Serial.println(F("[I] radio.begin(): OK"));
  Serial.println(F("[I] radio: channel=0x7A, rate=250KBPS, PA=LOW"));
  Serial.println(F("[I] nRF24: pipe=0x1234567890, powerDown"));
}

void logData() {
  if (!debugMode) return;
  Serial.print(F("[I] T=")); Serial.print(data.temperature, 1);
  Serial.print(F("C H=")); Serial.print(data.humidity, 1);
  Serial.print(F("% P=")); Serial.print(data.pressure, 1);
  Serial.print(F(" Bat=")); Serial.print(data.battery_voltage, 2);
  Serial.println(F("V"));
}

void logSend(bool sent) {
  if (!debugMode) return;
  if (sent) Serial.println(F("[I] ✅ Отправлено"));
  else      Serial.println(F("[E] ❌ radio.write(): FAIL"));
}

void logSummary() {
  if (!debugMode) return;
  if (cycleCount % 10 != 0) return;
  Serial.print(F("[I] 📊 Сводка: uptime="));
  Serial.print(millis() / 1000);
  Serial.print(F("с, packets="));
  Serial.print(packetsSent);
  Serial.print(F(", errors="));
  Serial.println(packetsFailed);
}

// ==================== АЦП ====================
float readBatteryVoltage() {
  enableADC();
  long sum = 0;
  for (int i = 0; i < 5; i++) { sum += analogRead(BATTERY_PIN); delay(1); }
  int adcValue = sum / 5;
  float rawVoltageAtAdc = adcValue * ADC_STEP;
  float calculatedBatteryVoltage = rawVoltageAtAdc * DIVIDER_RATIO;
  return calculatedBatteryVoltage * CALIBRATION_FACTOR;
}

void enableADC() {
  if (!adcEnabled) {
#if defined(__AVR__) && defined(ADEN)
    ADCSRA |= _BV(ADEN);
    delay(1);
    adcEnabled = true;
#endif
  }
}

void disableADC() {
  if (adcEnabled) {
#if defined(__AVR__) && defined(ADEN)
    ADCSRA &= ~_BV(ADEN);
    adcEnabled = false;
#endif
  }
}

// ==================== РАДИО ====================
void enableRadio() { radio.powerUp(); delay(RADIO_STABILIZE_DELAY); }
void disableRadio() { radio.powerDown(); }

// ==================== СОН ====================
void enterDeepSleep(unsigned long sleepDurationMs) {
  unsigned long remaining = sleepDurationMs;

  while (remaining >= 8000) { noInterrupts(); LowPower.powerDown(SLEEP_8S, ADC_OFF, BOD_OFF); interrupts(); remaining -= 8000; }
  if (remaining >= 4000) { noInterrupts(); LowPower.powerDown(SLEEP_4S, ADC_OFF, BOD_OFF); interrupts(); remaining -= 4000; }
  if (remaining >= 2000) { noInterrupts(); LowPower.powerDown(SLEEP_2S, ADC_OFF, BOD_OFF); interrupts(); remaining -= 2000; }
  if (remaining >= 1000) { noInterrupts(); LowPower.powerDown(SLEEP_1S, ADC_OFF, BOD_OFF); interrupts(); remaining -= 1000; }
  if (remaining >= 500)  { noInterrupts(); LowPower.powerDown(SLEEP_500MS, ADC_OFF, BOD_OFF); interrupts(); remaining -= 500; }
  if (remaining >= 250)  { noInterrupts(); LowPower.powerDown(SLEEP_250MS, ADC_OFF, BOD_OFF); interrupts(); remaining -= 250; }
  if (remaining >= 120)  { noInterrupts(); LowPower.powerDown(SLEEP_120MS, ADC_OFF, BOD_OFF); interrupts(); remaining -= 120; }
  if (remaining >= 60)   { noInterrupts(); LowPower.powerDown(SLEEP_60MS, ADC_OFF, BOD_OFF); interrupts(); remaining -= 60; }
  if (remaining >= 30)   { noInterrupts(); LowPower.powerDown(SLEEP_30MS, ADC_OFF, BOD_OFF); }
  else if (remaining >= 15) { noInterrupts(); LowPower.powerDown(SLEEP_15MS, ADC_OFF, BOD_OFF); interrupts(); }

  adcEnabled = false;
}

// ==================== ОТЛАДОЧНЫЕ КОМАНДЫ ====================
void printHelp() {
  Serial.println(F("\n=== КОМАНДЫ ==="));
  Serial.println(F("d   - вкл/выкл подробные логи"));
  Serial.println(F("q   - выход из отладочного режима (в сон)"));
  Serial.println(F("r   - Reset"));
  Serial.println(F("?   - эта справка"));
  Serial.println(F("i   - текущие данные (без отправки)"));
  Serial.println(F("tN  - интервал эмуляции сна (t5, t60)"));
  Serial.println(F("===============\n"));
}

void handleSerialCommands() {
  if (!Serial.available()) return;

  char cmd[32];
  size_t len = Serial.readBytesUntil('\n', cmd, sizeof(cmd) - 1);
  if (len == 0) return;
  cmd[len] = '\0';

  // trim: убрать \r и пробелы в конце
  while (len > 0 && (cmd[len - 1] == '\r' || cmd[len - 1] == ' ' || cmd[len - 1] == '\t')) {
    cmd[--len] = '\0';
  }
  if (len == 0) return;

  if (strcmp(cmd, "?") == 0) { printHelp(); return; }
  if (strcmp(cmd, "d") == 0) {
    debugVerbose = !debugVerbose;
    Serial.print(F("Подробные логи: "));
    Serial.println(debugVerbose ? F("ВКЛ") : F("ВЫКЛ"));
    return;
  }
  if (strcmp(cmd, "q") == 0) {
    Serial.println(F("Выход из отладочного режима..."));
    debugMode = false;
    return;
  }
  if (strcmp(cmd, "r") == 0) {
    Serial.println(F("Reset..."));
    delay(100);
    void (*resetFunc)(void) = 0;
    resetFunc();
    return;
  }
  if (strcmp(cmd, "i") == 0) { logData(); return; }
  if (cmd[0] == 't' && len > 1) {
    int val = atoi(cmd + 1);
    if (val >= 1 && val <= 600) {
      sleepIntervalMs = (unsigned long)val * 1000UL;
      Serial.print(F("Интервал эмуляции сна: "));
      Serial.print(val);
      Serial.println(F(" сек"));
    } else {
      Serial.println(F("Неверный интервал (1..600)"));
    }
    return;
  }

  Serial.print(F("Неизвестная команда: "));
  Serial.println(cmd);
  Serial.println(F("Введите '?' для справки"));
}

// ==================== ОДИН ЦИКЛ: ИЗМЕРЕНИЕ + ОТПРАВКА ====================
bool doMeasurementAndSend() {
  // ===== ПИТАНИЕ BME280 =====
  digitalWrite(BME_POWER_PIN, HIGH);
  delay(PRE_POWER_DELAY);
  enableADC();

  if (debugVerbose) Serial.println(F("[D] BME_POWER_PIN: HIGH, ожидание 150 мс"));

  // ===== ИНИЦИАЛИЗАЦИЯ BME280 (с повтором) =====
  if (!bme.begin(0x76)) {
    delay(50);
    if (!bme.begin(0x76)) {
      if (debugMode) Serial.println(F("[E] ❌ BME280 not found"));
      ledFlashColor(true, true, 50, 2);  // 2 вспышки жёлтым
      digitalWrite(BME_POWER_PIN, LOW);
      disableADC();
      return false;
    }
  }
  if (debugVerbose) Serial.println(F("[D] bme.begin(0x76): OK"));

  bme.setSampling(Adafruit_BME280::MODE_FORCED,
                  Adafruit_BME280::SAMPLING_X1,
                  Adafruit_BME280::SAMPLING_X1,
                  Adafruit_BME280::SAMPLING_X1,
                  Adafruit_BME280::FILTER_OFF);

  // ===== ИЗМЕРЕНИЕ BME280 =====
  if (!bme.takeForcedMeasurement()) {
    if (debugMode) Serial.println(F("[E] ❌ takeForcedMeasurement() FAIL"));
    ledFlashColor(true, true, 50, 2);  // 2 вспышки жёлтым
    digitalWrite(BME_POWER_PIN, LOW);
    disableADC();
    return false;
  }
  if (debugVerbose) Serial.println(F("[D] takeForcedMeasurement(): OK"));

  data.temperature = bme.readTemperature();
  data.humidity = bme.readHumidity();
  data.pressure = bme.readPressure() / 100.0F;

  if (isnan(data.temperature) || isnan(data.humidity) || isnan(data.pressure)) {
    if (debugMode) Serial.println(F("[E] ❌ BME280 returned NaN"));
    ledFlashColor(true, true, 50, 2);  // 2 вспышки жёлтым
    digitalWrite(BME_POWER_PIN, LOW);
    disableADC();
    return false;
  }

  // ===== ИЗМЕРЕНИЕ БАТАРЕИ =====
  float rawBat = readBatteryVoltage();
  if (rawBat < BATTERY_MIN_VALID || rawBat > BATTERY_MAX_VALID) {
    data.battery_voltage = 0.0;
    if (debugMode) { Serial.print(F("[W] Battery invalid: ")); Serial.println(rawBat); }
  } else {
    data.battery_voltage = rawBat;
  }

  digitalWrite(BME_POWER_PIN, LOW);
  if (debugVerbose) Serial.println(F("[D] BME_POWER_PIN: LOW"));

  // ===== ОТПРАВКА =====
  enableRadio();
  bool sent = radio.write(&data, sizeof(data));
  if (!sent) {
    delay(10);
    sent = radio.write(&data, sizeof(data));
  }
  disableRadio();
  disableADC();

  if (sent) {
    packetsSent++;
    ledFlashColor(false, true, 50, 1);  // 1 вспышка зелёным
  } else {
    packetsFailed++;
    ledFlashColor(true, false, 50, 1);  // 1 вспышка красным
  }

  if (debugMode) {
    logData();
    logSend(sent);
  }
  return sent;
}

// ==================== SETUP ====================
void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  bool buttonPressed = (digitalRead(BUTTON_PIN) == LOW);

  pinMode(LED_RED_PIN, OUTPUT);
  pinMode(LED_GREEN_PIN, OUTPUT);
  ledOff();

  debugMode = buttonPressed;

  if (debugMode) {
    ledFlashColor(true, true, 100, 3);  // 3 вспышки жёлтым (отладочный режим)
    Serial.begin(9600);
    delay(100);
    logHeader();
  } else {
    ledFlashColor(false, true, 100, 1); // 1 вспышка зелёным (штатный режим)
  }

  pinMode(BME_POWER_PIN, OUTPUT);
  digitalWrite(BME_POWER_PIN, LOW);

  enableADC();

  // ===== ПРОВЕРКА РАДИО =====
  if (!radio.begin()) {
    if (debugMode) Serial.println(F("[E] ❌ radio.begin() FAIL"));
    ledFlashColor(true, false, 500, 3);  // 3 длинные вспышки красным
    if (!debugMode) {
      enterDeepSleep(sleepIntervalMs);
    }
    return;
  }

  radio.setChannel(0x7A);
  radio.setDataRate(RF24_250KBPS);
  radio.setPALevel(RF24_PA_LOW);
  radio.openWritingPipe(pipe);
  radio.powerDown();
  logRadioInit();

  if (!debugMode) {
    Serial.end();
    disableADC();
  }
}

// ==================== LOOP ====================
void loop() {
  if (debugMode) {
    // ===== ОТЛАДОЧНЫЙ РЕЖИМ: не спим, loop() крутится =====
    handleSerialCommands();

    cycleCount++;
    doMeasurementAndSend();
    logSummary();

    if (debugVerbose) {
      Serial.print(F("[D] 💤 Пауза "));
      Serial.print(sleepIntervalMs / 1000);
      Serial.println(F(" сек (эмуляция сна)..."));
    }

    delay(sleepIntervalMs);

    if (debugVerbose) Serial.println(F("[D] ⏰ Проснулся"));
    return;
  }

  // ===== ШТАТНЫЙ РЕЖИМ: измерение → отправка → сон =====
  doMeasurementAndSend();
  enterDeepSleep(sleepIntervalMs);
}